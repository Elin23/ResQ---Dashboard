import { Badge, StatusBadge } from '@/components/ui';
import type { SemanticStatus } from '@/lib/statuses';
import type { AdoptionRequestStatus, ContactStatus, ReviewCheckStatus } from '../types';
import { contactStatusLabels, reviewStatusLabels } from '../constants';
const semantic:Record<AdoptionRequestStatus,SemanticStatus>={PENDING:'adoption:PENDING',UNDER_REVIEW:'adoption:UNDER_REVIEW',APPROVED:'adoption:APPROVED',REJECTED:'adoption:REJECTED',CANCELLED:'adoption:CANCELLED',COMPLETED:'adoption:COMPLETED'};
export const AdoptionStatusBadge=({status}:{status:AdoptionRequestStatus})=><StatusBadge status={semantic[status]}/>;
export const ReviewCheckBadge=({status}:{status:ReviewCheckStatus})=><Badge tone={status==='PASSED'?'success':status==='CONCERN'?'critical':'pending'}>{reviewStatusLabels[status]}</Badge>;
export const ContactStatusBadge=({status}:{status:ContactStatus})=><Badge tone={status==='INTERVIEW_COMPLETED'?'success':status==='NOT_CONTACTED'?'neutral':'info'}>{contactStatusLabels[status]}</Badge>;
