import type { ColumnDef } from '@tanstack/react-table';
import { ExternalLink, MoreHorizontal } from 'lucide-react';
import { useMemo, type ReactNode } from 'react';
import { useNavigate } from 'react-router';
import { Avatar, DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, IconButton } from '@/components/ui';
import { DataTable, type DataTableQueryState } from '@/components/ui/data-table';
import { speciesLabels } from '@/features/animals/constants';
import type { AdoptionRequest, AdoptionRequestFilters } from '../types';
type AdoptionCell={row:{original:AdoptionRequest}};
import { formatAdoptionRelative } from '../utils';
import { AdoptionStatusBadge } from './adoption-badges';
export function AdoptionRequestsTable({items,total,pageCount,filters,loading,error,onRetry,onQueryChange,emptyState}:{items:AdoptionRequest[];total:number;pageCount:number;filters:AdoptionRequestFilters;loading:boolean;error?:string;onRetry:()=>void;onQueryChange:(state:DataTableQueryState)=>void;emptyState:ReactNode}){const navigate=useNavigate();const columns=useMemo<Array<ColumnDef<AdoptionRequest,unknown>>>(()=>[
 {accessorKey:'id',header:'رقم الطلب',cell:({row}:AdoptionCell)=><span dir="ltr" className="font-bold text-primary">{row.original.id}</span>},
 {id:'animal',header:'الحيوان',cell:({row}:AdoptionCell)=><div className="flex min-w-44 items-center gap-3">{row.original.animal.imageUrl?<img src={row.original.animal.imageUrl} alt={`صورة ${row.original.animal.name??row.original.animal.id}`} className="size-10 rounded-md object-cover"/>:<Avatar name={row.original.animal.name??row.original.animal.id}/>}<div><p className="font-semibold">{row.original.animal.name??'بدون اسم'}</p><p className="text-xs text-muted-foreground">{speciesLabels[row.original.animal.species]} · {row.original.animal.id}</p></div></div>},
 {id:'applicant',header:'مقدم الطلب',cell:({row}:AdoptionCell)=><div><p className="font-medium">{row.original.applicant.name}</p><p className="text-xs text-muted-foreground">{row.original.applicant.city??'المدينة غير محددة'}</p></div>},
 {id:'organization',header:'الجمعية',cell:({row}:AdoptionCell)=><span className="whitespace-nowrap">{row.original.organization.name}</span>},
 {accessorKey:'status',header:'الحالة',cell:({row}:AdoptionCell)=><AdoptionStatusBadge status={row.original.status}/>},
 {id:'submittedAt',header:'تاريخ التقديم',cell:({row}:AdoptionCell)=><span className="whitespace-nowrap text-xs">{formatAdoptionRelative(row.original.submittedAt)}</span>},
 {id:'updatedAt',header:'آخر تحديث',cell:({row}:AdoptionCell)=><span className="whitespace-nowrap text-xs">{formatAdoptionRelative(row.original.updatedAt)}</span>},
 {id:'reviewer',header:'المراجع',cell:({row}:AdoptionCell)=><span>{row.original.reviewer?.name??'غير معيّن'}</span>},
 ],[]);return <DataTable data={items} columns={columns} getRowId={r=>r.id} enableSearch={false} loading={loading} error={error} onRetry={onRetry} manualPagination manualSorting manualFiltering pageCount={pageCount} totalCount={total} state={{pageIndex:filters.page-1,pageSize:filters.pageSize,search:filters.search,sorting:filters.sortBy?[{id:filters.sortBy,desc:filters.sortDirection!=='asc'}]:[]}} onStateChange={onQueryChange} onRowClick={r=>navigate(`/adoption-requests/${r.id}`)} rowAriaLabel={r=>`فتح طلب التبني ${r.id}`} rowActions={r=><DropdownMenu><DropdownMenuTrigger asChild><IconButton label={`إجراءات طلب ${r.id}`}><MoreHorizontal className="size-4"/></IconButton></DropdownMenuTrigger><DropdownMenuContent><DropdownMenuItem onSelect={()=>navigate(`/adoption-requests/${r.id}`)}><ExternalLink className="size-4"/>عرض الطلب</DropdownMenuItem><DropdownMenuItem onSelect={()=>navigate(`/animals/${r.animal.id}`)}>فتح الحيوان</DropdownMenuItem><DropdownMenuItem onSelect={()=>navigate(`/users/${r.applicant.id}`)}>فتح المستخدم</DropdownMenuItem><DropdownMenuItem onSelect={()=>navigate(`/organizations/${r.organization.id}`)}>فتح الجمعية</DropdownMenuItem></DropdownMenuContent></DropdownMenu>} emptyState={emptyState}/>;}
