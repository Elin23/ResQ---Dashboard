import type { AdoptionRequestStatus, ContactStatus, HousingType, ReviewCheckStatus } from '../types';
export const adoptionStatusLabels:Record<AdoptionRequestStatus,string>={PENDING:'جديد',UNDER_REVIEW:'قيد المراجعة',APPROVED:'تمت الموافقة',REJECTED:'مرفوض',CANCELLED:'ملغي',COMPLETED:'مكتمل'};
export const housingLabels:Record<HousingType,string>={APARTMENT:'شقة',HOUSE:'منزل',FARM:'مزرعة',OTHER:'أخرى'};
export const ownershipLabels={OWNS:'ملك',RENTS:'إيجار'} as const;
export const contactStatusLabels:Record<ContactStatus,string>={NOT_CONTACTED:'لم يتم التواصل',CONTACTED:'تم التواصل',INTERVIEW_SCHEDULED:'تم تحديد مقابلة',INTERVIEW_COMPLETED:'اكتملت المقابلة'};
export const reviewStatusLabels:Record<ReviewCheckStatus,string>={PENDING:'بانتظار المراجعة',PASSED:'مستوفى',CONCERN:'يحتاج متابعة'};
export const allowedAdoptionTransitions:Record<AdoptionRequestStatus,readonly AdoptionRequestStatus[]>={PENDING:['UNDER_REVIEW','CANCELLED'],UNDER_REVIEW:['APPROVED','REJECTED','CANCELLED'],APPROVED:['COMPLETED','CANCELLED'],REJECTED:[],CANCELLED:[],COMPLETED:[]};
export const rejectionReasons=['بيئة السكن غير مناسبة','عدم اكتمال المعلومات','عدم ملاءمة الطلب لاحتياجات الحيوان','عدم القدرة على توفير الرعاية المطلوبة','تعذر التواصل مع مقدم الطلب','تم اختيار طلب آخر','سبب آخر'] as const;
export const reviewCheckTemplate=[
 {key:'housing',label:'بيئة السكن مناسبة'},
 {key:'landlord',label:'الموافقة من مالك العقار عند الحاجة'},
 {key:'experience',label:'وجود خبرة كافية أو استعداد للرعاية'},
 {key:'veterinary',label:'الالتزام بالرعاية البيطرية'},
 {key:'no-abandonment',label:'الالتزام بعدم التخلي عن الحيوان'},
 {key:'animal-fit',label:'لا توجد تعارضات واضحة مع احتياجات الحيوان'},
] as const;
