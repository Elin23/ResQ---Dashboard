import type { AnimalHealthStatus, AnimalLifecycleStatus, AnimalSpecies } from '@/features/animals/types';
import type { UserAccountStatus } from '@/features/users/types';

export const adoptionRequestStatuses = ['PENDING','UNDER_REVIEW','APPROVED','REJECTED','CANCELLED','COMPLETED'] as const;
export type AdoptionRequestStatus = (typeof adoptionRequestStatuses)[number];
export const housingTypes = ['APARTMENT','HOUSE','FARM','OTHER'] as const;
export type HousingType = (typeof housingTypes)[number];
export type OwnershipType = 'OWNS' | 'RENTS';
export type ReviewCheckStatus = 'PENDING' | 'PASSED' | 'CONCERN';
export type ContactStatus = 'NOT_CONTACTED' | 'CONTACTED' | 'INTERVIEW_SCHEDULED' | 'INTERVIEW_COMPLETED';
export type CancellationSource = 'APPLICANT' | 'ORGANIZATION' | 'ADMIN' | 'SYSTEM';

export interface AdoptionApplicationAnswers {
  housingType: HousingType;
  ownsOrRents: OwnershipType;
  landlordApproval?: boolean;
  householdMembersCount: number;
  hasChildren: boolean;
  childrenAges?: number[];
  hasOtherAnimals: boolean;
  otherAnimalsDescription?: string;
  previousPetExperience: boolean;
  previousPetExperienceDescription?: string;
  dailyHoursAnimalAlone?: number;
  preferredAnimalEnvironment?: string;
  reasonForAdoption: string;
  commitmentToVeterinaryCare: boolean;
  commitmentToNoAbandonment: boolean;
  additionalNotes?: string;
}

export interface AdoptionReviewCheck { key:string; label:string; status:ReviewCheckStatus; note?:string; }
export interface AdoptionReview { checks:AdoptionReviewCheck[]; summary?:string; concerns?:string; followUpNeeded?:string; interviewStatus:ContactStatus; updatedAt?:string; }
export interface AdoptionDecision { decidedAt:string; decidedBy:{id:string;name:string}; note?:string; reason?:string; }
export interface AdoptionCancellation { cancelledBy:CancellationSource; reason?:string; cancelledAt:string; }
export interface AdoptionCompletion { handoffAt:string; handoffLocation?:string; notes?:string; reference?:string; }
export interface AdoptionTimelineEvent { id:string; action:'SUBMITTED'|'REVIEW_STARTED'|'REVIEW_UPDATED'|'CONTACT_UPDATED'|'APPROVED'|'REJECTED'|'CANCELLED'|'COMPLETED'|'NOTE_ADDED'; title:string; actor?:string; timestamp:string; note?:string; tone?:'neutral'|'success'|'pending'|'critical'|'info'; }
export interface AdoptionInternalNote { id:string; adminName:string; adminRole:string; createdAt:string; note:string; }
export interface AdoptionAnimalRef { id:string; name?:string; species:AnimalSpecies; breed?:string; imageUrl?:string; estimatedAgeMonths?:number; healthStatus:AnimalHealthStatus; lifecycleStatus:AnimalLifecycleStatus; organization:{id:string;name:string}; }
export interface AdoptionApplicant { id:string; name:string; phone?:string; email?:string; city?:string; accountStatus:UserAccountStatus; memberSince:string; previousRequestsCount:number; completedAdoptionsCount:number; }
export interface AdoptionOrganizationRef { id:string; name:string; contact?:string; handlerName?:string; }
export interface AdoptionRequest {
  id:string;
  animal:AdoptionAnimalRef;
  applicant:AdoptionApplicant;
  organization:AdoptionOrganizationRef;
  status:AdoptionRequestStatus;
  submittedAt:string;
  updatedAt:string;
  reviewedAt?:string;
  approvedAt?:string;
  rejectedAt?:string;
  completedAt?:string;
  cancelledAt?:string;
  answers:AdoptionApplicationAnswers;
  reviewer?:{id:string;name:string};
  rejectionReason?:string;
  cancellation?:AdoptionCancellation;
  completion?:AdoptionCompletion;
  review:AdoptionReview;
  internalNotesCount:number;
}
export interface AdoptionRequestDetails { request:AdoptionRequest; timeline:AdoptionTimelineEvent[]; notes:AdoptionInternalNote[]; conflicts:Array<{id:string;status:AdoptionRequestStatus;applicantName:string}>; }
export interface AdoptionRequestFilters { search:string; status?:AdoptionRequestStatus; species?:AnimalSpecies; organizationId?:string; city?:string; dateFrom?:string; dateTo?:string; reviewerId?:string; animalId?:string; userId?:string; page:number; pageSize:number; sortBy?:'submittedAt'|'updatedAt'|'status'; sortDirection?:'asc'|'desc'; }
export interface AdoptionRequestListResult { items:AdoptionRequest[]; total:number; page:number; pageSize:number; pageCount:number; }
export interface AdoptionRequestSummary { pending:number; underReview:number; approvalsPending:number; approved:number; rejected:number; completedThisMonth:number; }
export interface UpdateAdoptionReviewInput { checks:AdoptionReviewCheck[]; summary?:string; concerns?:string; followUpNeeded?:string; interviewStatus:ContactStatus; }
export interface RejectAdoptionInput { reason:string; otherReason?:string; }
export interface CancelAdoptionInput { reason:string; }
export interface CompleteAdoptionInput { handoffAt:string; handoffLocation?:string; notes?:string; reference?:string; }
