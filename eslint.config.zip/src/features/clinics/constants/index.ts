import type { ClinicAnimalType,ClinicDocumentType,ClinicServiceKey,ClinicVerificationStatus } from '../types';
export const clinicServiceLabels:Record<ClinicServiceKey,string>={GENERAL_EXAM:'فحص عام',EMERGENCY:'إسعافات طارئة',SURGERY:'جراحة',VACCINATION:'تطعيمات',STERILIZATION:'تعقيم',LAB:'تحاليل مخبرية',XRAY:'تصوير شعاعي',OBSERVATION:'إقامة ومراقبة',WOUND_CARE:'علاج الجروح',RESCUE_CARE:'رعاية الحيوانات المنقذة'};
export const clinicAnimalTypeLabels:Record<ClinicAnimalType,string>={DOG:'كلاب',CAT:'قطط',BIRD:'طيور',SMALL:'حيوانات صغيرة',OTHER:'حيوانات أخرى'};
export const clinicDocumentTypeLabels:Record<ClinicDocumentType,string>={CLINIC_LICENSE:'ترخيص العيادة',VETERINARIAN_LICENSE:'ترخيص الطبيب المسؤول',REGISTRATION:'مستند التسجيل',REPRESENTATIVE_ID:'هوية الممثل',ADDRESS_PROOF:'إثبات العنوان',OTHER:'مستند آخر'};
export const clinicVerificationLabels:Record<ClinicVerificationStatus,string>={NOT_REVIEWED:'لم تُراجع',IN_REVIEW:'قيد المراجعة',VERIFIED:'تم التحقق',REJECTED:'مرفوضة',MORE_INFO_REQUIRED:'معلومات إضافية مطلوبة'};
export const dayLabels={SATURDAY:'السبت',SUNDAY:'الأحد',MONDAY:'الاثنين',TUESDAY:'الثلاثاء',WEDNESDAY:'الأربعاء',THURSDAY:'الخميس',FRIDAY:'الجمعة'} as const;
export const clinicRejectReasons=['ترخيص غير صالح','مستندات غير مكتملة','تعذر التحقق من بيانات العيادة','بيانات الطبيب غير متطابقة','العيادة خارج نطاق الخدمة','سبب آخر'] as const;
export const clinicSuspendReasons=['مخالفة سياسات المنصة','شكاوى خطرة','بيانات تشغيلية غير صحيحة','ترخيص منتهي','طلب من العيادة','سبب آخر'] as const;
