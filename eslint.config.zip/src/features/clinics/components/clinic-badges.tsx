import { Badge,StatusBadge } from '@/components/ui';import { clinicVerificationLabels } from '../constants';import type { ClinicStatus,ClinicVerificationStatus } from '../types';
export function ClinicStatusBadge({status}:{status:ClinicStatus}){return <StatusBadge status={`clinic:${status}`}/>}
export function ClinicVerificationBadge({status}:{status:ClinicVerificationStatus}){const tone=status==='VERIFIED'?'success':status==='REJECTED'?'critical':status==='IN_REVIEW'||status==='MORE_INFO_REQUIRED'?'pending':'neutral';return <Badge tone={tone}>{clinicVerificationLabels[status]}</Badge>}
