import { z } from 'zod';
export const clinicNoteSchema=z.object({note:z.string().trim().min(3,'اكتب ملاحظة واضحة.').max(800,'الملاحظة طويلة جداً.')});
export const clinicRequestInfoSchema=z.object({requestedItems:z.array(z.string()).min(1,'حدد عنصراً واحداً على الأقل.'),message:z.string().trim().min(10,'اكتب رسالة أوضح.')});
export const clinicRejectSchema=z.object({reason:z.string().min(1,'اختر سبب الرفض.'),otherReason:z.string().optional()}).superRefine((v,c)=>{if(v.reason==='سبب آخر'&&(!v.otherReason||v.otherReason.trim().length<5))c.addIssue({code:z.ZodIssueCode.custom,path:['otherReason'],message:'اكتب سبباً واضحاً.'})});
export const clinicSuspendSchema=z.object({reason:z.string().min(1,'اختر سبب التعليق.'),otherReason:z.string().optional(),note:z.string().optional()}).superRefine((v,c)=>{if(v.reason==='سبب آخر'&&(!v.otherReason||v.otherReason.trim().length<5))c.addIssue({code:z.ZodIssueCode.custom,path:['otherReason'],message:'اكتب سبباً واضحاً.'})});
