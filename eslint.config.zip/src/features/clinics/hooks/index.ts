import { keepPreviousData,useMutation,useQuery,useQueryClient } from '@tanstack/react-query';
import { useSession } from '@/features/auth/session';
import { dashboardKeys } from '@/features/dashboard/hooks';
import { animalKeys } from '@/features/animals/hooks';
import { missionKeys } from '@/features/rescue-missions/hooks';
import type { ClinicFilters,ClinicRejectInput,ClinicRequestInfoInput,ClinicReviewDocumentInput,ClinicSuspendInput } from '../types';
import { addClinicNote,approveClinic,getClinicById,getClinics,getClinicSummary,reactivateClinic,rejectClinic,requestClinicInfo,reviewClinicDocument,startClinicReview,suspendClinic } from '../services/clinics.mock';
export const clinicKeys={all:['clinics'] as const,lists:()=>['clinics','list'] as const,list:(filters:ClinicFilters)=>['clinics','list',filters] as const,summary:()=>['clinics','summary'] as const,detail:(id:string)=>['clinics','detail',id] as const};
export const useClinics=(filters:ClinicFilters)=>useQuery({queryKey:clinicKeys.list(filters),queryFn:()=>getClinics(filters),placeholderData:keepPreviousData});
export const useClinicSummary=()=>useQuery({queryKey:clinicKeys.summary(),queryFn:getClinicSummary});
export const useClinic=(id:string)=>useQuery({queryKey:clinicKeys.detail(id),queryFn:()=>getClinicById(id),enabled:Boolean(id)});
function useActor(){const{session}=useSession();if(!session)throw new Error('SESSION_REQUIRED');return session}
function useInvalidate(id?:string){const client=useQueryClient();return async()=>{await Promise.all([client.invalidateQueries({queryKey:clinicKeys.all}),client.invalidateQueries({queryKey:dashboardKeys.all}),client.invalidateQueries({queryKey:animalKeys.all}),client.invalidateQueries({queryKey:missionKeys.all}),...(id?[client.invalidateQueries({queryKey:clinicKeys.detail(id)})]:[])])}}
export function useStartClinicReview(id:string){const actor=useActor(),invalidate=useInvalidate(id);return useMutation({mutationFn:()=>startClinicReview(id,actor),onSuccess:invalidate})}
export function useApproveClinic(id:string){const actor=useActor(),invalidate=useInvalidate(id);return useMutation({mutationFn:()=>approveClinic(id,actor),onSuccess:invalidate})}
export function useRejectClinic(id:string){const actor=useActor(),invalidate=useInvalidate(id);return useMutation({mutationFn:(input:ClinicRejectInput)=>rejectClinic(id,input,actor),onSuccess:invalidate})}
export function useRequestClinicInfo(id:string){const actor=useActor(),invalidate=useInvalidate(id);return useMutation({mutationFn:(input:ClinicRequestInfoInput)=>requestClinicInfo(id,input,actor),onSuccess:invalidate})}
export function useSuspendClinic(id:string){const actor=useActor(),invalidate=useInvalidate(id);return useMutation({mutationFn:(input:ClinicSuspendInput)=>suspendClinic(id,input,actor),onSuccess:invalidate})}
export function useReactivateClinic(id:string){const actor=useActor(),invalidate=useInvalidate(id);return useMutation({mutationFn:(note?:string)=>reactivateClinic(id,note,actor),onSuccess:invalidate})}
export function useReviewClinicDocument(id:string){const actor=useActor(),invalidate=useInvalidate(id);return useMutation({mutationFn:({documentId,input}:{documentId:string;input:ClinicReviewDocumentInput})=>reviewClinicDocument(id,documentId,input,actor),onSuccess:invalidate})}
export function useAddClinicNote(id:string){const actor=useActor(),invalidate=useInvalidate(id);return useMutation({mutationFn:(note:string)=>addClinicNote(id,note,actor),onSuccess:invalidate})}
