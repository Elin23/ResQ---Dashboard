import { format,formatDistanceToNowStrict } from 'date-fns';import { ar } from 'date-fns/locale';import type { ClinicFilters } from '../types';
import { safeDate } from '@/lib/runtime-safety';
export const formatClinicDate=(value:string)=>{const date=safeDate(value);return date?format(date,'d MMM yyyy، HH:mm',{locale:ar}):'—';};
export const formatClinicRelative=(value:string)=>{const date=safeDate(value);return date?formatDistanceToNowStrict(date,{addSuffix:true,locale:ar}):'—';};
export const hasClinicFilters=(f:ClinicFilters)=>Boolean(f.search||f.status||f.verificationStatus||f.governorate||f.service||f.animalType||f.emergency||f.open24Hours||f.dateFrom||f.dateTo);
