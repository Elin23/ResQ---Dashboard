export const clinicStatuses=['PENDING_VERIFICATION','ACTIVE','SUSPENDED','REJECTED'] as const;
export type ClinicStatus=(typeof clinicStatuses)[number];
export const clinicVerificationStatuses=['NOT_REVIEWED','IN_REVIEW','VERIFIED','REJECTED','MORE_INFO_REQUIRED'] as const;
export type ClinicVerificationStatus=(typeof clinicVerificationStatuses)[number];
export const clinicServiceKeys=['GENERAL_EXAM','EMERGENCY','SURGERY','VACCINATION','STERILIZATION','LAB','XRAY','OBSERVATION','WOUND_CARE','RESCUE_CARE'] as const;
export type ClinicServiceKey=(typeof clinicServiceKeys)[number];
export const clinicAnimalTypes=['DOG','CAT','BIRD','SMALL','OTHER'] as const;
export type ClinicAnimalType=(typeof clinicAnimalTypes)[number];
export interface ClinicService{key:ClinicServiceKey}
export interface ClinicOperatingHours{day:'SATURDAY'|'SUNDAY'|'MONDAY'|'TUESDAY'|'WEDNESDAY'|'THURSDAY'|'FRIDAY';closed:boolean;open24Hours?:boolean;opensAt?:string;closesAt?:string}
export type ClinicDocumentType='CLINIC_LICENSE'|'VETERINARIAN_LICENSE'|'REGISTRATION'|'REPRESENTATIVE_ID'|'ADDRESS_PROOF'|'OTHER';
export type ClinicDocumentStatus='PENDING'|'VERIFIED'|'REJECTED';
export interface ClinicDocument{id:string;type:ClinicDocumentType;name:string;url:string;status:ClinicDocumentStatus;uploadedAt:string;reviewedAt?:string;rejectionReason?:string;required:boolean}
export interface ClinicVeterinarian{id:string;name:string;specialization?:string;licenseNumber?:string;licenseExpiresAt?:string;yearsOfExperience?:number;isPrimary:boolean;mockValidationState?:'VERIFIED'|'PENDING'}
export interface ClinicStatistics{animalsTreated:number;treatmentsThisMonth:number;activeFollowUps:number;rescueMissionArrivals?:number;rating?:number;reviewsCount?:number;activeAdvertisements:number;pendingAdvertisements:number}
export interface ClinicVerificationReview{reviewer?:{id:string;name:string};startedAt?:string;checklist:Array<{key:string;label:string;passed:boolean}>;requestedItems?:string[];adminMessage?:string;rejectionReason?:string}
export interface ClinicTimelineEvent{id:string;action:string;actor?:string;timestamp:string;details?:string;tone?:'neutral'|'success'|'pending'|'critical'|'info'}
export interface ClinicInternalNote{id:string;adminName:string;adminRole:string;createdAt:string;note:string}
export interface Clinic{id:string;name:string;shortName?:string;description?:string;logoUrl?:string;coverImageUrl?:string;status:ClinicStatus;verificationStatus:ClinicVerificationStatus;licenseNumber?:string;registrationNumber?:string;governorate:string;city?:string;address:string;latitude?:number;longitude?:number;phone:string;secondaryPhone?:string;email:string;website?:string;emergencyAvailable:boolean;open24Hours:boolean;primaryVeterinarian?:ClinicVeterinarian;veterinarians:ClinicVeterinarian[];services:ClinicService[];supportedAnimalTypes:ClinicAnimalType[];operatingHours:ClinicOperatingHours[];documents:ClinicDocument[];statistics?:ClinicStatistics;createdAt:string;updatedAt:string}
export interface ClinicTreatmentActivity{animalId:string;animalName?:string;recordId?:string;title:string;performedAt:string;followUp:boolean}
export interface ClinicDetails{clinic:Clinic;review:ClinicVerificationReview;timeline:ClinicTimelineEvent[];notes:ClinicInternalNote[];recentTreatments:ClinicTreatmentActivity[];rescueArrivals:Array<{missionId:string;reportId:string;completedAt:string}>}
export interface ClinicFilters{search:string;status?:ClinicStatus;verificationStatus?:ClinicVerificationStatus;governorate?:string;service?:ClinicServiceKey;animalType?:ClinicAnimalType;emergency?:'YES'|'NO';open24Hours?:'YES'|'NO';dateFrom?:string;dateTo?:string;page:number;pageSize:number;sortBy?:'createdAt'|'updatedAt'|'name'|'status';sortDirection?:'asc'|'desc'}
export interface ClinicListResult{items:Clinic[];total:number;page:number;pageSize:number;pageCount:number}
export interface ClinicSummary{total:number;pendingVerification:number;active:number;suspended:number;emergencyAvailable:number;open24Hours:number}
export interface ClinicRequestInfoInput{requestedItems:string[];message:string}
export interface ClinicRejectInput{reason:string;otherReason?:string}
export interface ClinicSuspendInput{reason:string;otherReason?:string;note?:string}
export interface ClinicReviewDocumentInput{decision:'APPROVE'|'REJECT';reason?:string}
