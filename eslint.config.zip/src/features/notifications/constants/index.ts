import type { NotificationChannel,NotificationDeliveryStatus,NotificationAudienceUserType } from '../types';
export const notificationStatusLabels:Record<NotificationDeliveryStatus,string>={DRAFT:'مسودة',SCHEDULED:'مجدول',SENDING:'قيد الإرسال',SENT:'تم الإرسال',PARTIALLY_SENT:'إرسال جزئي',FAILED:'فشل',CANCELLED:'ملغي'};
export const notificationChannelLabels:Record<NotificationChannel,string>={IN_APP:'داخل التطبيق',PUSH:'Push'};
export const notificationAudienceTypeLabels:Record<NotificationAudienceUserType,string>={USER:'المستخدمون',ORGANIZATION:'الجمعيات',CLINIC:'العيادات'};
export const governorates=['دمشق','ريف دمشق','حلب','حمص','حماة','اللاذقية','طرطوس','درعا'] as const;
export const deepLinkPatterns=[
 {label:'بلاغ',pattern:/^\/reports\/[A-Za-z0-9-]+$/},
 {label:'حيوان',pattern:/^\/animals\/[A-Za-z0-9-]+$/},
 {label:'طلب تبني',pattern:/^\/adoption-requests\/[A-Za-z0-9-]+$/},
 {label:'جمعية',pattern:/^\/organizations\/[A-Za-z0-9-]+$/},
 {label:'عيادة',pattern:/^\/clinics\/[A-Za-z0-9-]+$/},
 {label:'مقال منشور',pattern:/^\/content\/articles\/[A-Za-z0-9-]+$/},
] as const;
export const notificationTimezone='Asia/Damascus';
export const titleMaxLength=90;
export const bodyMaxLength=420;
