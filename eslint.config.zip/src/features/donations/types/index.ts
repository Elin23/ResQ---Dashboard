export const donationStatuses=['PENDING','COMPLETED','FAILED','REFUNDED','CANCELLED'] as const;
export type DonationStatus=(typeof donationStatuses)[number];
export const donationPurposes=['GENERAL','MEDICAL','FOOD','SHELTER','SPECIFIC_CASE','SPECIFIC_ORGANIZATION','OTHER'] as const;
export type DonationPurpose=(typeof donationPurposes)[number];
export const donationBeneficiaryTypes=['RESQ','ORGANIZATION','ANIMAL','RESCUE_CASE'] as const;
export type DonationBeneficiaryType=(typeof donationBeneficiaryTypes)[number];
export const donationCurrencies=['SYP'] as const;
export type DonationCurrency=(typeof donationCurrencies)[number];
export interface DonationRefund{refundedAt:string;amountMinor:number;reason:string;actorId:string;actorName:string;externalReference?:string;}
export interface DonationTimelineEvent{id:string;title:string;actor?:string;timestamp:string;details?:string;tone?:'neutral'|'success'|'pending'|'critical'|'info';}
export interface DonationInternalNote{id:string;adminName:string;adminRole:string;createdAt:string;note:string;}
export interface Donation{ id:string;amountMinor:number;currency:DonationCurrency;status:DonationStatus;purpose:DonationPurpose;customPurpose?:string;donor?:{id?:string;name?:string;email?:string;phone?:string;anonymous:boolean};beneficiary:{type:DonationBeneficiaryType;id?:string;name:string};organization?:{id:string;name:string};animal?:{id:string;name?:string};report?:{id:string};paymentReference?:string;receiptNumber?:string;createdAt:string;completedAt?:string;refundedAt?:string;failureReason?:string;note?:string;refund?:DonationRefund;}
export interface DonationDetails{donation:Donation;timeline:DonationTimelineEvent[];notes:DonationInternalNote[];}
export interface DonationFilters{search:string;status?:DonationStatus;purpose?:DonationPurpose;beneficiaryType?:DonationBeneficiaryType;organizationId?:string;animalId?:string;reportId?:string;currency?:DonationCurrency;anonymous?:'YES'|'NO';dateFrom?:string;dateTo?:string;amountMin?:number;amountMax?:number;page:number;pageSize:number;sortBy?:'createdAt'|'amountMinor'|'status';sortDirection?:'asc'|'desc';}
export interface DonationListResult{items:Donation[];total:number;page:number;pageSize:number;pageCount:number;}
export interface MoneyTotal{currency:DonationCurrency;amountMinor:number;}
export interface DonationSummary{total:MoneyTotal[];thisMonth:MoneyTotal[];completed:number;pending:number;organizationDonations:number;medicalDonations:number;}
export interface DonationAnalyticsPoint{label:string;SYP:number;}
