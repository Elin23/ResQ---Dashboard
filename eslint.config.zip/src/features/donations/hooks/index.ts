import { keepPreviousData,useMutation,useQuery,useQueryClient } from '@tanstack/react-query';
import { useSession } from '@/features/auth/session';
import { dashboardKeys } from '@/features/dashboard/hooks';
import { organizationKeys } from '@/features/organizations/hooks';
import type { DonationFilters } from '../types';
import { addDonationNote,getDonationAnalytics,getDonationById,getDonations,getDonationSummary,refundDonation } from '../services/donations.mock';
export const donationKeys={all:['donations'] as const,list:(f:DonationFilters)=>['donations','list',f] as const,summary:(f?:Partial<DonationFilters>)=>['donations','summary',f??{}] as const,detail:(id:string)=>['donations','detail',id] as const,analytics:['donations','analytics'] as const};
export const useDonations=(f:DonationFilters)=>useQuery({queryKey:donationKeys.list(f),queryFn:()=>getDonations(f),placeholderData:keepPreviousData});
export const useDonationSummary=(f?:Partial<DonationFilters>)=>useQuery({queryKey:donationKeys.summary(f),queryFn:()=>getDonationSummary(f)});
export const useDonation=(id:string)=>useQuery({queryKey:donationKeys.detail(id),queryFn:()=>getDonationById(id),enabled:Boolean(id)});
export const useDonationAnalytics=()=>useQuery({queryKey:donationKeys.analytics,queryFn:getDonationAnalytics});
function actor(){const{session}=useSession();if(!session)throw new Error('SESSION_REQUIRED');return session;}
function invalidate(id:string){const c=useQueryClient();return async()=>{await Promise.all([c.invalidateQueries({queryKey:donationKeys.all}),c.invalidateQueries({queryKey:donationKeys.detail(id)}),c.invalidateQueries({queryKey:dashboardKeys.all}),c.invalidateQueries({queryKey:organizationKeys.all})]);};}
export function useRefundDonation(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:(reason:string)=>refundDonation(id,reason,a),onSuccess:done});}
export function useAddDonationNote(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:(note:string)=>addDonationNote(id,note,a),onSuccess:done});}
