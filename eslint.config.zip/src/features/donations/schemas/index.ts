import { z } from 'zod';
export const refundDonationSchema=z.object({reason:z.string().trim().min(5,'يرجى توضيح سبب الاسترداد.')});
export const donationNoteSchema=z.object({note:z.string().trim().min(3,'اكتب ملاحظة واضحة.').max(1000,'الملاحظة طويلة جدًا.')});
