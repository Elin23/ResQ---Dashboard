import { StatusBadge } from '@/components/ui';
import type { DonationStatus } from '../types';
export function DonationStatusBadge({status}:{status:DonationStatus}){return <StatusBadge status={`donation:${status}`}/>;}
