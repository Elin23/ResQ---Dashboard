import { memo } from 'react';
import { ResponsiveContainer, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';
import { Card, SectionHeader, Skeleton } from '@/components/ui';
import type { DonationAnalyticsPoint } from '../types';

const currencyFormatter = new Intl.NumberFormat('en-US');

function DonationAnalyticsComponent({ data, loading }: { data?: DonationAnalyticsPoint[]; loading: boolean }) {
  return <Card><SectionHeader title="اتجاه التبرعات" description="اتجاه إجمالي التبرعات بالليرة السورية." />{loading ? <Skeleton className="mt-4 h-64" /> : <div className="mt-4 h-64" role="img" aria-label="مخطط اتجاه التبرعات بالليرة السورية"><ResponsiveContainer width="100%" height="100%" debounce={120}><LineChart data={data ?? []}><CartesianGrid stroke="var(--border)" strokeDasharray="3 3" /><XAxis dataKey="label" /><YAxis /><Tooltip formatter={(value: unknown) => [`${currencyFormatter.format(Number(value ?? 0))} ل.س`, 'التبرعات']} /><Line type="monotone" dataKey="SYP" name="ل.س" stroke="var(--primary)" strokeWidth={2} dot={false} /></LineChart></ResponsiveContainer></div>}</Card>;
}

export const DonationAnalytics = memo(DonationAnalyticsComponent);
