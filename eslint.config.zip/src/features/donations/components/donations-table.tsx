import type { ReactNode } from 'react';
import { useMemo } from 'react';
import { useNavigate } from 'react-router';
import type { ColumnDef } from '@tanstack/react-table';
import { DataTable,type DataTableQueryState } from '@/components/ui/data-table';
import { Badge,Button } from '@/components/ui';
import type { Donation,DonationFilters } from '../types';
import { donationPurposeLabels } from '../constants';
import { formatDonationDate,formatMoney } from '../utils';
import { DonationStatusBadge } from './donation-badges';
export function DonationsTable({items,total,pageCount,filters,loading,onQueryChange,emptyState}:{items:Donation[];total:number;pageCount:number;filters:DonationFilters;loading:boolean;onQueryChange:(s:DataTableQueryState)=>void;emptyState:ReactNode}){const nav=useNavigate();const columns=useMemo<Array<ColumnDef<Donation,unknown>>>(()=>[
{accessorKey:'id',header:'رقم العملية',cell:({row})=><strong>{row.original.id}</strong>},{id:'donor',header:'المتبرع',cell:({row})=>row.original.donor?.anonymous?'متبرع مجهول':row.original.donor?.name??'غير مسجل'},{accessorKey:'amountMinor',header:'المبلغ',cell:({row})=><span className="whitespace-nowrap font-bold">{formatMoney(row.original.amountMinor,row.original.currency)}</span>},{accessorKey:'purpose',header:'الغرض',cell:({row})=>donationPurposeLabels[row.original.purpose]},{id:'beneficiary',header:'المستفيد',cell:({row})=>row.original.beneficiary.name},{accessorKey:'status',header:'الحالة',cell:({row})=><DonationStatusBadge status={row.original.status}/>},{accessorKey:'receiptNumber',header:'رقم الإيصال',cell:({row})=>row.original.receiptNumber?<Badge>{row.original.receiptNumber}</Badge>:'—'},{accessorKey:'createdAt',header:'التاريخ',cell:({row})=>formatDonationDate(row.original.createdAt)}],[]);return <DataTable data={items} columns={columns} loading={loading} enableSearch={false} manualPagination manualFiltering manualSorting pageCount={pageCount} totalCount={total} state={{pageIndex:filters.page-1,pageSize:filters.pageSize,search:filters.search,sorting:filters.sortBy?[{id:filters.sortBy,desc:filters.sortDirection!=='asc'}]:[]}} onStateChange={onQueryChange} onRowClick={d=>nav(`/donations/${d.id}`)} rowAriaLabel={d=>`فتح تفاصيل التبرع ${d.id}`} rowActions={d=><Button size="sm" variant="ghost" onClick={()=>nav(`/donations/${d.id}`)}>عرض</Button>} emptyState={emptyState}/>}
