import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'sonner';
import { Button,Modal,Textarea } from '@/components/ui';
import { refundDonationSchema } from '../schemas';
import { useRefundDonation } from '../hooks';
type Form={reason:string};
export function RefundDonationDialog({donationId,open,onOpenChange}:{donationId:string;open:boolean;onOpenChange:(v:boolean)=>void}){const mutation=useRefundDonation(donationId);const{register,handleSubmit,formState:{errors}}=useForm<Form>({resolver:zodResolver(refundDonationSchema),defaultValues:{reason:''}});return <Modal open={open} onOpenChange={onOpenChange} title="تسجيل استرداد كامل" description="هذا إجراء تجريبي يسجل الاسترداد في بيانات الواجهة فقط، ولا يتصل بمزود دفع." footer={<Button variant="danger" disabled={mutation.isPending} onClick={()=>void handleSubmit(v=>mutation.mutate(v.reason,{onSuccess:()=>{toast.success('تم تسجيل طلب الاسترداد في البيانات التجريبية.');onOpenChange(false);},onError:()=>toast.error('تعذر تسجيل الاسترداد.')}))()}>تأكيد الاسترداد الكامل</Button>}><label className="space-y-2 text-sm font-semibold">سبب الاسترداد<Textarea {...register('reason')} placeholder="اكتب سببًا واضحًا للاسترداد…"/>{errors.reason&&<span className="block text-xs text-critical">{errors.reason.message}</span>}</label></Modal>}
