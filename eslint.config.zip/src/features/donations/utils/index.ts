import type { DonationCurrency,DonationFilters } from '../types';import{safeFiniteNumber,safeFormatDate}from'@/lib/runtime-safety';
export function formatMoney(amountMinor:number,_currency:DonationCurrency='SYP'){return `${new Intl.NumberFormat('en-US',{maximumFractionDigits:0}).format(safeFiniteNumber(amountMinor))} ل.س`;}
export function hasDonationFilters(f:DonationFilters){return Boolean(f.search||f.status||f.purpose||f.beneficiaryType||f.organizationId||f.animalId||f.reportId||f.anonymous||f.dateFrom||f.dateTo||f.amountMin!==undefined||f.amountMax!==undefined);}
export function formatDonationDate(v:string){return safeFormatDate(v,{dateStyle:'medium',timeStyle:'short'});}
