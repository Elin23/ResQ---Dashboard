import type { DonationBeneficiaryType,DonationPurpose,DonationStatus } from '../types';
export const donationStatusLabels:Record<DonationStatus,string>={PENDING:'معلقة',COMPLETED:'مكتملة',FAILED:'فشلت',REFUNDED:'مستردة',CANCELLED:'ملغاة'};
export const donationPurposeLabels:Record<DonationPurpose,string>={GENERAL:'دعم عام',MEDICAL:'رعاية طبية',FOOD:'طعام ومستلزمات',SHELTER:'دعم المأوى',SPECIFIC_CASE:'حالة محددة',SPECIFIC_ORGANIZATION:'جمعية محددة',OTHER:'غرض آخر'};
export const donationBeneficiaryLabels:Record<DonationBeneficiaryType,string>={RESQ:'ResQ',ORGANIZATION:'جمعية',ANIMAL:'حيوان',RESCUE_CASE:'حالة إنقاذ'};
