import { useCallback } from 'react';
import { Printer, RefreshCw } from 'lucide-react';
import { useSearchParams } from 'react-router';
import { Button, ErrorState, PageHeader, Skeleton, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui';
import { usePermission } from '@/features/auth/rbac';
import type { AnimalSpecies } from '@/features/animals/types';
import type { AnalyticsFilters, AnalyticsRangePreset } from '../types';
import { rangeDates } from '../utils';
import { useAnalytics, useSupplementalManagementReports } from '../hooks';
import { AnalyticsFilterPanel } from '../components/analytics-filter-panel';
import { AnalyticsDashboardView } from '../components/analytics-dashboard-view';
import { ManagementReportsView, type ManagementReportKey } from '../components/management-reports-view';

const validRanges: AnalyticsRangePreset[] = ['today', '7d', '30d', 'month', '3m', 'year', 'custom'];
const validViews = ['reports', 'analytics'] as const;
type AnalyticsView = (typeof validViews)[number];
const validReportKeys: ManagementReportKey[] = ['rescue', 'donations', 'advertisements', 'organizations', 'adoption', 'support', 'users'];

function filtersFrom(params: URLSearchParams): AnalyticsFilters {
  const candidate = params.get('range') as AnalyticsRangePreset | null;
  const range = candidate && validRanges.includes(candidate) ? candidate : '30d';
  const dates = rangeDates(range, params.get('from') ?? undefined, params.get('to') ?? undefined);
  return {
    range,
    from: params.get('from') ?? dates.from,
    to: params.get('to') ?? dates.to,
    governorate: params.get('governorate') ?? undefined,
    organizationId: params.get('organizationId') ?? undefined,
    species: (params.get('species') ?? undefined) as AnimalSpecies | undefined,
    severity: (params.get('severity') ?? undefined) as AnalyticsFilters['severity'],
  };
}
function viewFrom(params: URLSearchParams): AnalyticsView {
  const candidate = params.get('view') as AnalyticsView | null;
  return candidate && validViews.includes(candidate) ? candidate : 'reports';
}
function reportFrom(params: URLSearchParams): ManagementReportKey {
  const candidate = params.get('report') as ManagementReportKey | null;
  return candidate && validReportKeys.includes(candidate) ? candidate : 'rescue';
}
function paramsFrom(filters: AnalyticsFilters, current: URLSearchParams) {
  const next = new URLSearchParams();
  next.set('view', viewFrom(current));
  if (viewFrom(current) === 'reports') next.set('report', reportFrom(current));
  next.set('range', filters.range);
  if (filters.range === 'custom') {
    next.set('from', filters.from);
    next.set('to', filters.to);
  }
  if (filters.governorate) next.set('governorate', filters.governorate);
  if (filters.organizationId) next.set('organizationId', filters.organizationId);
  if (filters.species) next.set('species', filters.species);
  if (filters.severity) next.set('severity', filters.severity);
  return next;
}

export function AnalyticsPage() {
  const [params, setParams] = useSearchParams();
  const filters = filtersFrom(params);
  const view = viewFrom(params);
  const reportKey = reportFrom(params);
  const canDonations = usePermission('donations.read');
  const canOperational = usePermission('missions:view');
  const canSupport = usePermission('support.read');
  const canAdvertisements = usePermission('advertisements.read');
  const query = useAnalytics(filters, canOperational ? 'OPERATIONS' : 'FINANCE', canSupport);
  const supplementalQuery = useSupplementalManagementReports(filters, canAdvertisements, canSupport);

  const updateFilters = useCallback((patch: Partial<AnalyticsFilters>) => {
    let next = { ...filters, ...patch };
    if (patch.range && patch.range !== 'custom') next = { ...next, ...rangeDates(patch.range) };
    setParams(paramsFrom(next, params));
  }, [filters, params, setParams]);

  const setView = (nextView: AnalyticsView) => {
    const next = new URLSearchParams(params);
    next.set('view', nextView);
    if (nextView === 'reports' && !next.get('report')) next.set('report', canOperational ? 'rescue' : 'donations');
    setParams(next);
  };
  const setReport = (key: ManagementReportKey) => {
    const next = new URLSearchParams(params);
    next.set('view', 'reports');
    next.set('report', key);
    setParams(next);
  };
  const refresh = () => {
    void query.refetch();
    if (view === 'reports') void supplementalQuery.refetch();
  };

  if (query.isError && !query.data) return <ErrorState title="تعذر تحميل التقارير والإحصائيات" description={query.error.message} onRetry={refresh} />;

  const data = query.data;
  return (
    <div className="space-y-6 print:bg-white">
      <PageHeader
        title="التقارير والإحصائيات"
        description="مساحة موحدة للتقارير الإدارية والتحليلات التشغيلية، مع فصل التقارير التفصيلية عن لوحات الإحصائيات لتبقى القراءة واضحة وغير مزدحمة."
        breadcrumbs={[{ label: 'الرئيسية', href: '/dashboard' }, { label: 'التقارير والإحصائيات' }]}
        actions={<><Button variant="secondary" onClick={refresh} disabled={query.isFetching || supplementalQuery.isFetching}><RefreshCw className="size-4" />تحديث البيانات</Button><Button variant="ghost" onClick={() => window.print()}><Printer className="size-4" />طباعة</Button></>}
      />

      <Tabs value={view} onValueChange={(value) => setView(value as AnalyticsView)} className="space-y-5">
        <TabsList className="inline-flex rounded-lg bg-muted p-1 print:hidden">
          <TabsTrigger value="reports">التقارير</TabsTrigger>
          <TabsTrigger value="analytics">الإحصائيات</TabsTrigger>
        </TabsList>

        <AnalyticsFilterPanel filters={filters} onChange={updateFilters} />

        {!data ? (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 8 }, (_, index) => <Skeleton key={index} className="h-28" />)}</div>
        ) : (
          <>
            <TabsContent value="reports" className="mt-0">
              <ManagementReportsView
                data={data}
                supplemental={supplementalQuery.data}
                filters={filters}
                reportKey={reportKey}
                onReportKeyChange={setReport}
                canDonations={canDonations}
                canAdvertisements={canAdvertisements}
                canSupport={canSupport}
                canOperational={canOperational}
              />
            </TabsContent>
            <TabsContent value="analytics" className="mt-0">
              <AnalyticsDashboardView data={data} filters={filters} canOperational={canOperational} canDonations={canDonations} canSupport={canSupport} />
            </TabsContent>
          </>
        )}
      </Tabs>

      {data && <p className="text-xs text-muted-foreground">آخر تحديث: {new Date(data.generatedAt).toLocaleString('ar-SY-u-nu-latn')} · البيانات الحالية تجريبية ومجمعة في الواجهة؛ التقارير الإنتاجية تتطلب تجميعًا من الخادم.</p>}
    </div>
  );
}
