import { Download, ExternalLink } from 'lucide-react';
import { Link } from 'react-router';
import { Button, Card, EmptyState, Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui';
import { advertisementStatusLabels } from '@/features/advertisements/constants';
import type { AdvertisementStatus } from '@/features/advertisements/types';
import type { AnalyticsFilters, AnalyticsResponse, SupplementalManagementReports } from '../types';
import { formatAnalyticsMoney, formatDuration, formatInteger, formatPercent } from '../utils';
import { SimpleMetricGrid } from './analytics-components';
import { DistributionChart, RankedBarChart, ChartCard } from './analytics-charts';

export type ManagementReportKey = 'rescue' | 'donations' | 'advertisements' | 'organizations' | 'adoption' | 'support' | 'users';

function csvCell(value: string | number) {
  return `"${String(value).replaceAll('"', '""')}"`;
}
function downloadCsv(filename: string, rows: Array<Array<string | number>>) {
  const csv = `\uFEFF${rows.map((row) => row.map(csvCell).join(',')).join('\n')}`;
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

function ReportIntro({ title, description, href, actionLabel, onExport }: { title: string; description: string; href?: string; actionLabel?: string; onExport?: () => void }) {
  return <div className="flex flex-col gap-3 border-b pb-4 sm:flex-row sm:items-start sm:justify-between"><div><h2 className="text-xl font-bold">{title}</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-muted-foreground">{description}</p></div><div className="flex shrink-0 flex-wrap gap-2">{onExport && <Button variant="secondary" onClick={onExport}><Download className="size-4" />تصدير التقرير</Button>}{href && <Link to={href}><Button variant="ghost">{actionLabel ?? 'فتح السجل'}<ExternalLink className="size-4" /></Button></Link>}</div></div>;
}

export function ManagementReportsView({ data, supplemental, filters, reportKey, onReportKeyChange, canDonations, canAdvertisements, canSupport, canOperational }: {
  data: AnalyticsResponse;
  supplemental?: SupplementalManagementReports;
  filters: AnalyticsFilters;
  reportKey: ManagementReportKey;
  onReportKeyChange: (key: ManagementReportKey) => void;
  canDonations: boolean;
  canAdvertisements: boolean;
  canSupport: boolean;
  canOperational: boolean;
}) {
  const available: Array<{ key: ManagementReportKey; label: string }> = [
    ...(canOperational ? [{ key: 'rescue' as const, label: 'حالات الإنقاذ' }, { key: 'organizations' as const, label: 'الجمعيات' }, { key: 'adoption' as const, label: 'التبني' }, { key: 'users' as const, label: 'المستخدمون' }] : []),
    ...(canDonations ? [{ key: 'donations' as const, label: 'التبرعات' }] : []),
    ...(canAdvertisements ? [{ key: 'advertisements' as const, label: 'الإعلانات' }] : []),
    ...(canSupport ? [{ key: 'support' as const, label: 'الدعم' }] : []),
  ];
  const activeKey = available.some((item) => item.key === reportKey) ? reportKey : available[0]?.key;
  if (!activeKey) return <EmptyState title="لا توجد تقارير متاحة لهذا الدور" description="صلاحيات هذا الحساب لا تتضمن مجالات تقارير يمكن عرضها هنا." />;

  return (
    <Tabs value={activeKey} onValueChange={(value) => onReportKeyChange(value as ManagementReportKey)} className="space-y-5">
      <TabsList className="flex max-w-full gap-1 overflow-x-auto rounded-lg bg-muted p-1 print:hidden">
        {available.map((item) => <TabsTrigger key={item.key} value={item.key}>{item.label}</TabsTrigger>)}
      </TabsList>

      <TabsContent value="rescue" className="space-y-5">
        <ReportIntro title="تقرير حالات الإنقاذ" description="تقرير تشغيلي يجمع حجم البلاغات، الحالات الحرجة، نتائج المهام، وأزمنة القبول والوصول خلال الفترة المحددة." href="/rescue-missions" actionLabel="فتح مهام الإنقاذ" onExport={() => downloadCsv(`resq-rescue-report-${filters.from}-${filters.to}.csv`, [['المؤشر','القيمة'],['إجمالي البلاغات',data.reports.total],['البلاغات الحرجة',data.reports.critical],['البلاغات المكتملة',data.reports.completed],['إجمالي المهام',data.rescue.total],['المهام المكتملة',data.rescue.completed],['المهام الملغاة',data.rescue.cancelled],['معدل الإكمال',formatPercent(data.rescue.completionRate)]])} />
        <SimpleMetricGrid items={[{ label: 'إجمالي البلاغات', value: data.reports.total }, { label: 'حالات حرجة', value: data.reports.critical }, { label: 'المهام المكتملة', value: data.rescue.completed }, { label: 'معدل إكمال الإنقاذ', value: formatPercent(data.rescue.completionRate) }, { label: 'متوسط القبول', value: formatDuration(data.rescue.averageAcceptanceMinutes) }, { label: 'متوسط الوصول', value: formatDuration(data.rescue.averageArrivalMinutes) }]} />
        <div className="grid gap-4 xl:grid-cols-2"><ChartCard title="البلاغات حسب المحافظة"><RankedBarChart data={data.reports.byGovernorate} /></ChartCard><ChartCard title="الحالات حسب الشدة"><DistributionChart data={data.reports.bySeverity} /></ChartCard></div>
      </TabsContent>

      <TabsContent value="donations" className="space-y-5">
        <ReportIntro title="تقرير التبرعات" description="ملخص مالي للفترة الحالية بالليرة السورية فقط، مع عدد العمليات ومتوسط قيمة التبرع وتوزيع الأغراض والمستفيدين." href="/donations" actionLabel="فتح التبرعات" onExport={data.donations ? () => downloadCsv(`resq-donations-report-${filters.from}-${filters.to}.csv`, [['المؤشر','القيمة'],['إجمالي التبرعات',formatAnalyticsMoney(data.donations!.totals[0]?.amountMinor ?? 0)],['عدد العمليات',data.donations!.totals[0]?.operations ?? 0],['متوسط التبرع',formatAnalyticsMoney(data.donations!.totals[0]?.averageMinor ?? 0)],...data.donations!.byPurpose.map((item) => [`الغرض: ${item.label}`,item.value])]) : undefined} />
        {data.donations ? <><SimpleMetricGrid items={[{ label: 'إجمالي التبرعات', value: formatAnalyticsMoney(data.donations.totals[0]?.amountMinor ?? 0) }, { label: 'عدد العمليات', value: data.donations.totals[0]?.operations ?? 0 }, { label: 'متوسط قيمة التبرع', value: formatAnalyticsMoney(data.donations.totals[0]?.averageMinor ?? 0) }]} /><div className="grid gap-4 xl:grid-cols-2"><ChartCard title="حسب الغرض"><DistributionChart data={data.donations.byPurpose} /></ChartCard><ChartCard title="حسب المستفيد"><DistributionChart data={data.donations.byBeneficiary} /></ChartCard></div></> : <EmptyState title="لا توجد بيانات تبرعات متاحة" />}
      </TabsContent>

      <TabsContent value="advertisements" className="space-y-5">
        <ReportIntro title="تقرير الإعلانات" description="حالة الحملات الإعلانية ومواقع الظهور والأداء التجريبي المتاح. أرقام الظهور والنقرات هنا Mock-ready وليست قياسًا إنتاجيًا." href="/advertisements" actionLabel="فتح الإعلانات" onExport={supplemental?.advertisements ? () => downloadCsv(`resq-advertisements-report-${filters.from}-${filters.to}.csv`, [['المعرف','الإعلان','الجهة','المكان','الحالة','الظهور','النقرات'],...supplemental.advertisements!.rows.map((row) => [row.id,row.title,row.advertiser,row.placement,advertisementStatusLabels[row.status as AdvertisementStatus],row.impressions ?? '',row.clicks ?? ''])]) : undefined} />
        {supplemental?.advertisements ? <><SimpleMetricGrid items={[{ label: 'إجمالي الحملات', value: supplemental.advertisements.total }, { label: 'بانتظار المراجعة', value: supplemental.advertisements.pendingReview }, { label: 'فعالة', value: supplemental.advertisements.active }, { label: 'مجدولة', value: supplemental.advertisements.scheduled }, { label: 'متوقفة مؤقتًا', value: supplemental.advertisements.paused }, { label: 'مرفوضة', value: supplemental.advertisements.rejected }, { label: 'مرات الظهور التجريبية', value: supplemental.advertisements.totalImpressions }, { label: 'معدل النقر التجريبي', value: supplemental.advertisements.clickThroughRate === undefined ? '—' : formatPercent(supplemental.advertisements.clickThroughRate) }]} /><div className="grid gap-4 xl:grid-cols-2"><ChartCard title="الحملات حسب موضع الظهور"><DistributionChart data={supplemental.advertisements.byPlacement} /></ChartCard><Card className="overflow-x-auto p-0"><table className="w-full min-w-[760px] text-sm"><thead><tr className="border-b text-right text-muted-foreground"><th className="p-3">الإعلان</th><th>الجهة</th><th>المكان</th><th>الحالة</th><th>الظهور</th><th>النقرات</th></tr></thead><tbody>{supplemental.advertisements.rows.map((row) => <tr key={row.id} className="border-b last:border-0"><td className="p-3"><Link to={`/advertisements/${row.id}`} className="font-semibold text-primary hover:underline">{row.title}</Link><div className="text-xs text-muted-foreground" dir="ltr">{row.id}</div></td><td>{row.advertiser}</td><td>{row.placement}</td><td>{advertisementStatusLabels[row.status as AdvertisementStatus]}</td><td>{row.impressions === undefined ? '—' : formatInteger(row.impressions)}</td><td>{row.clicks === undefined ? '—' : formatInteger(row.clicks)}</td></tr>)}</tbody></table></Card></div></> : <EmptyState title="لا توجد بيانات إعلانات متاحة" />}
      </TabsContent>

      <TabsContent value="organizations" className="space-y-5">
        <ReportIntro title="تقرير الجمعيات" description="مقارنة تشغيلية شفافة للجمعيات بحسب المهام المكتملة، الحالات النشطة، وأزمنة القبول والوصول. لا يستخدم التقرير درجة أداء غامضة." href="/organizations" actionLabel="فتح الجمعيات" onExport={() => downloadCsv(`resq-organizations-report-${filters.from}-${filters.to}.csv`, [['الجمعية','المحافظة','المهام المكتملة','المهام النشطة','متوسط القبول','متوسط الوصول','نسبة الإكمال'],...data.rescue.organizations.map((row) => [row.name,row.governorate,row.completedMissions,row.activeMissions,formatDuration(row.averageAcceptanceMinutes),formatDuration(row.averageArrivalMinutes),formatPercent(row.completionRate)])])} />
        <Card className="overflow-x-auto p-0"><table className="w-full min-w-[800px] text-sm"><thead><tr className="border-b text-right text-muted-foreground"><th className="p-3">الجمعية</th><th>المحافظة</th><th>المكتملة</th><th>النشطة</th><th>القبول</th><th>الوصول</th><th>الإكمال</th></tr></thead><tbody>{data.rescue.organizations.map((row) => <tr key={row.id} className="border-b last:border-0"><td className="p-3"><Link to={`/organizations/${row.id}`} className="font-semibold text-primary hover:underline">{row.name}</Link></td><td>{row.governorate}</td><td>{formatInteger(row.completedMissions)}</td><td>{formatInteger(row.activeMissions)}</td><td>{formatDuration(row.averageAcceptanceMinutes)}</td><td>{formatDuration(row.averageArrivalMinutes)}</td><td>{formatPercent(row.completionRate)}</td></tr>)}</tbody></table></Card>
      </TabsContent>

      <TabsContent value="adoption" className="space-y-5">
        <ReportIntro title="تقرير التبني" description="تقرير يوضح تدفق طلبات التبني من التقديم إلى الإكمال، مع الرفض والإلغاء ومدد الانتظار." href="/adoption-requests" actionLabel="فتح طلبات التبني" onExport={() => downloadCsv(`resq-adoption-report-${filters.from}-${filters.to}.csv`, [['المؤشر','القيمة'],['إجمالي الطلبات',data.adoption.total],['قيد المراجعة',data.adoption.underReview],['تمت الموافقة',data.adoption.approved],['مرفوضة',data.adoption.rejected],['مكتملة',data.adoption.completed],['ملغاة',data.adoption.cancelled],['معدل الإكمال',formatPercent(data.adoption.completionRate)]])} />
        <SimpleMetricGrid items={[{ label: 'إجمالي الطلبات', value: data.adoption.total }, { label: 'قيد المراجعة', value: data.adoption.underReview }, { label: 'تمت الموافقة', value: data.adoption.approved }, { label: 'مكتملة', value: data.adoption.completed }, { label: 'مرفوضة', value: data.adoption.rejected }, { label: 'معدل الإكمال', value: formatPercent(data.adoption.completionRate) }, { label: 'متوسط الانتظار', value: data.adoption.averageWaitingDays === undefined ? '—' : `${new Intl.NumberFormat('en-US',{maximumFractionDigits:1}).format(data.adoption.averageWaitingDays)} يوم` }]} />
        <div className="grid gap-4 xl:grid-cols-2"><ChartCard title="مسار طلب التبني"><RankedBarChart data={data.adoption.funnel} /></ChartCard><ChartCard title="التبني المكتمل حسب النوع"><DistributionChart data={data.adoption.completedBySpecies} /></ChartCard></div>
      </TabsContent>

      <TabsContent value="support" className="space-y-5">
        <ReportIntro title="تقرير مركز الدعم" description="مؤشرات تشغيلية عن حجم التذاكر، الحالات العاجلة، الانتظار، الحل، ومتوسط أول استجابة خلال الفترة." href="/support" actionLabel="فتح مركز الدعم" onExport={supplemental?.support ? () => downloadCsv(`resq-support-report-${filters.from}-${filters.to}.csv`, [['المؤشر','القيمة'],['إجمالي التذاكر',supplemental.support!.total],['جديدة',supplemental.support!.newCount],['مفتوحة',supplemental.support!.openCount],['عاجلة',supplemental.support!.urgentCount],['بانتظار المستخدم',supplemental.support!.waitingForUser],['بانتظار إجراء داخلي',supplemental.support!.waitingForInternal],['محلولة',supplemental.support!.resolved],['مغلقة',supplemental.support!.closed]]) : undefined} />
        {supplemental?.support ? <><SimpleMetricGrid items={[{ label: 'إجمالي التذاكر', value: supplemental.support.total }, { label: 'جديدة', value: supplemental.support.newCount }, { label: 'مفتوحة', value: supplemental.support.openCount }, { label: 'عاجلة', value: supplemental.support.urgentCount }, { label: 'بانتظار المستخدم', value: supplemental.support.waitingForUser }, { label: 'بانتظار إجراء داخلي', value: supplemental.support.waitingForInternal }, { label: 'تم حلها', value: supplemental.support.resolved }, { label: 'متوسط أول استجابة', value: formatDuration(supplemental.support.averageFirstResponseMinutes) }]} /><ChartCard title="تذاكر الدعم حسب التصنيف"><DistributionChart data={supplemental.support.byCategory} /></ChartCard></> : <EmptyState title="لا توجد بيانات دعم متاحة" />}
      </TabsContent>

      <TabsContent value="users" className="space-y-5">
        <ReportIntro title="تقرير المستخدمين" description="نمو الحسابات ومؤشرات المشاركة التشغيلية المباشرة مثل تقديم البلاغات وطلبات التبني، دون تتبع سلوكي خفي." href="/users" actionLabel="فتح المستخدمين" onExport={() => downloadCsv(`resq-users-report-${filters.from}-${filters.to}.csv`, [['المؤشر','القيمة'],['إجمالي المستخدمين ضمن الفترة',data.users.total],['مستخدمون جدد',data.users.newUsers],['نشطون وفق التعريف',data.users.activeUsers],['حسابات معلقة',data.users.suspended],['قدموا بلاغًا',data.users.reportedUsers],['قدموا طلب تبني',data.users.adoptionUsers],['أكملوا تبنيًا',data.users.completedAdoptionUsers]])} />
        <SimpleMetricGrid items={[{ label: 'المستخدمون ضمن الفترة', value: data.users.total }, { label: 'مستخدمون جدد', value: data.users.newUsers }, { label: 'نشطون وفق التعريف', value: data.users.activeUsers }, { label: 'حسابات معلقة', value: data.users.suspended }, { label: 'قدموا بلاغًا', value: data.users.reportedUsers }, { label: 'قدموا طلب تبني', value: data.users.adoptionUsers }, { label: 'أكملوا تبنيًا', value: data.users.completedAdoptionUsers }]} />
      </TabsContent>
    </Tabs>
  );
}
