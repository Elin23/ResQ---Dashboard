import { Map } from 'lucide-react';
import { Link } from 'react-router';
import { Button, Card } from '@/components/ui';
import { metricDefinitions } from '../constants';
import type { AnalyticsFilters, AnalyticsResponse } from '../types';
import { formatAnalyticsMoney, formatDuration, formatInteger, formatPercent } from '../utils';
import { AnalyticsMetric, AnalyticsSection, SimpleMetricGrid } from './analytics-components';
import { ChartCard, DistributionChart, DonationTrendChart, RankedBarChart, TimeSeriesChart } from './analytics-charts';

export function AnalyticsDashboardView({
  data,
  filters,
  canOperational,
  canDonations,
  canSupport,
}: {
  data: AnalyticsResponse;
  filters: AnalyticsFilters;
  canOperational: boolean;
  canDonations: boolean;
  canSupport: boolean;
}) {
  return (
    <div className="space-y-7">
      {canOperational && (
        <>
          <AnalyticsSection id="overview" title="نظرة تنفيذية" description={`الفترة: ${filters.from} — ${filters.to}. المقارنات تشغيلية مع الفترة السابقة ولا تعني دلالة إحصائية.`}>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <AnalyticsMetric label="إجمالي البلاغات" metric={data.overview.reports} />
              <AnalyticsMetric label="نسبة البلاغات المكتملة" metric={data.overview.reportCompletionRate} valueFormatter={formatPercent} helper={metricDefinitions.reportCompletionRate} />
              <AnalyticsMetric label="متوسط زمن الوصول" metric={data.overview.averageArrivalMinutes} valueFormatter={formatDuration} />
              <AnalyticsMetric label="عمليات الإنقاذ المكتملة" metric={data.overview.completedMissions} />
              <AnalyticsMetric label="حيوانات جاهزة للتبني" metric={data.overview.adoptableAnimals} />
              <AnalyticsMetric label="عمليات تبني مكتملة" metric={data.overview.completedAdoptions} />
              <AnalyticsMetric label="جمعيات نشطة" metric={data.overview.activeOrganizations} />
              <AnalyticsMetric label="مستخدمون جدد" metric={data.overview.newUsers} />
            </div>
          </AnalyticsSection>

          <AnalyticsSection id="reports" title="تحليلات البلاغات" description="حجم الحالات، المزيج التشغيلي، التحول عبر مراحل المعالجة، والتوزيع الجغرافي.">
            <SimpleMetricGrid items={[
              { label: 'إجمالي البلاغات', value: data.reports.total },
              { label: 'بلاغات حرجة', value: data.reports.critical },
              { label: 'بلاغات مكتملة', value: data.reports.completed },
              { label: 'متوسط البلاغات يوميًا', value: new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(data.reports.averagePerDay) },
            ]} />
            <div className="grid gap-4 xl:grid-cols-2">
              <ChartCard title="اتجاه البلاغات" description="المستلمة مقابل المغلقة/المنقذة"><TimeSeriesChart data={data.reports.trend} primaryLabel="البلاغات المستلمة" secondaryLabel="تم الإنقاذ/الإغلاق" /></ChartCard>
              <ChartCard title="البلاغات حسب الحالة"><DistributionChart data={data.reports.byStatus} /></ChartCard>
              <ChartCard title="حسب الشدة"><DistributionChart data={data.reports.bySeverity} /></ChartCard>
              <ChartCard title="حسب نوع الحيوان"><DistributionChart data={data.reports.bySpecies} /></ChartCard>
              <ChartCard title="البلاغات حسب المحافظة"><RankedBarChart data={data.reports.byGovernorate} /></ChartCard>
              <ChartCard title="مسار التحول التشغيلي" description="مراحل مترابطة من الاستلام حتى اكتمال مهمة الإنقاذ"><RankedBarChart data={data.reports.funnel} /></ChartCard>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link to="/reports?severity=CRITICAL"><Button variant="secondary">فتح البلاغات الحرجة</Button></Link>
              <Link to="/map"><Button variant="ghost"><Map className="size-4" />فتح الخريطة التشغيلية</Button></Link>
            </div>
          </AnalyticsSection>

          <AnalyticsSection id="rescue" title="عمليات الإنقاذ" description="القبول والوصول ومدة التنفيذ ومعدل الإكمال، بصيغ واضحة قابلة للتدقيق.">
            <SimpleMetricGrid items={[
              { label: 'إجمالي المهام', value: data.rescue.total },
              { label: 'المهام المكتملة', value: data.rescue.completed },
              { label: 'المهام الملغاة', value: data.rescue.cancelled },
              { label: 'معدل الإكمال', value: formatPercent(data.rescue.completionRate), helper: metricDefinitions.rescueCompletionRate },
              { label: 'متوسط القبول', value: formatDuration(data.rescue.averageAcceptanceMinutes), helper: metricDefinitions.missionAcceptance },
              { label: 'متوسط الوصول', value: formatDuration(data.rescue.averageArrivalMinutes), helper: metricDefinitions.missionArrival },
              { label: 'متوسط مدة الإنقاذ', value: formatDuration(data.rescue.averageDurationMinutes) },
            ]} />
            <ChartCard title="ضغط مهام الإنقاذ عبر الوقت"><TimeSeriesChart data={data.rescue.trend} primaryLabel="مهام نشطة بدأت" secondaryLabel="مهام مكتملة" /></ChartCard>
          </AnalyticsSection>

          <AnalyticsSection id="organizations" title="أداء الجمعيات" description="مقارنة شفافة حسب المهام المكتملة وأزمنة الاستجابة؛ لا توجد درجة أداء غامضة.">
            <Card className="overflow-x-auto p-0">
              <table className="w-full min-w-[760px] text-sm">
                <thead><tr className="border-b text-right text-muted-foreground"><th className="p-3">الجمعية</th><th>المكتملة</th><th>القبول</th><th>الوصول</th><th>نسبة الإكمال</th><th>نشطة</th></tr></thead>
                <tbody>{data.rescue.organizations.map((organization) => <tr key={organization.id} className="border-b last:border-0"><td className="p-3"><Link className="font-semibold text-primary hover:underline" to={`/organizations/${organization.id}`}>{organization.name}</Link><div className="text-xs text-muted-foreground">{organization.governorate}</div></td><td>{formatInteger(organization.completedMissions)}</td><td>{formatDuration(organization.averageAcceptanceMinutes)}</td><td>{formatDuration(organization.averageArrivalMinutes)}</td><td>{formatPercent(organization.completionRate)}</td><td>{formatInteger(organization.activeMissions)}</td></tr>)}</tbody>
              </table>
            </Card>
          </AnalyticsSection>

          <AnalyticsSection id="animals" title="الحيوانات والرعاية" description="حالة دورة الرعاية والصحة التشغيلية دون استنتاجات طبية تتجاوز السجل.">
            <SimpleMetricGrid items={[
              { label: 'إجمالي الحيوانات', value: data.animals.total },
              { label: 'تحت العلاج', value: data.animals.underTreatment },
              { label: 'في التعافي', value: data.animals.recovering },
              { label: 'جاهزة للتبني', value: data.animals.adoptable },
              { label: 'تم تبنيها', value: data.animals.adopted },
              { label: 'متوسط الأيام حتى التبني', value: data.animals.averageDaysToAdoption === undefined ? '—' : new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(data.animals.averageDaysToAdoption) },
            ]} />
            <div className="grid gap-4 xl:grid-cols-2">
              <ChartCard title="دورة حياة الحيوانات"><DistributionChart data={data.animals.byLifecycle} /></ChartCard>
              <ChartCard title="الحالة الصحية المسجلة"><DistributionChart data={data.animals.byHealth} /></ChartCard>
            </div>
          </AnalyticsSection>

          <AnalyticsSection id="adoption" title="تحليلات التبني" description="من تقديم الطلب حتى إكمال التبني مع فصل الرفض والإلغاء عن مسار التحول.">
            <SimpleMetricGrid items={[
              { label: 'طلبات التبني', value: data.adoption.total },
              { label: 'قيد المراجعة', value: data.adoption.underReview },
              { label: 'تمت الموافقة', value: data.adoption.approved },
              { label: 'مرفوضة', value: data.adoption.rejected },
              { label: 'مكتملة', value: data.adoption.completed },
              { label: 'معدل الإكمال', value: formatPercent(data.adoption.completionRate), helper: metricDefinitions.adoptionCompletionRate },
              { label: 'متوسط الانتظار', value: data.adoption.averageWaitingDays === undefined ? '—' : `${new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(data.adoption.averageWaitingDays)} يوم` },
              { label: 'وسيط الانتظار', value: data.adoption.medianWaitingDays === undefined ? '—' : `${new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(data.adoption.medianWaitingDays)} يوم` },
            ]} />
            <div className="grid gap-4 xl:grid-cols-2"><ChartCard title="مسار طلب التبني"><RankedBarChart data={data.adoption.funnel} /></ChartCard><ChartCard title="التبني المكتمل حسب النوع"><DistributionChart data={data.adoption.completedBySpecies} /></ChartCard></div>
            <Link to="/adoption-requests?status=REJECTED"><Button variant="secondary">فتح الطلبات المرفوضة</Button></Link>
          </AnalyticsSection>

          <AnalyticsSection id="users" title="المستخدمون" description="النمو والنشاط التشغيلي اعتمادًا على الحسابات والسجل الموجود، دون افتراض DAU/MAU غير متاح.">
            <SimpleMetricGrid items={[
              { label: 'المستخدمون ضمن الفترة', value: data.users.total },
              { label: 'مستخدمون جدد', value: data.users.newUsers },
              { label: 'نشطون وفق التعريف', value: data.users.activeUsers, helper: metricDefinitions.activeUser },
              { label: 'حسابات معلقة', value: data.users.suspended },
              { label: 'قدموا بلاغًا', value: data.users.reportedUsers },
              { label: 'قدموا طلب تبني', value: data.users.adoptionUsers },
              { label: 'أكملوا تبنيًا', value: data.users.completedAdoptionUsers },
            ]} />
            <ChartCard title="تسجيل المستخدمين عبر الوقت"><TimeSeriesChart data={data.users.growth} primaryLabel="تسجيلات جديدة" /></ChartCard>
          </AnalyticsSection>
        </>
      )}

      {canDonations && data.donations && (
        <AnalyticsSection id="donations" title="تحليلات التبرعات" description="جميع القيم المالية معروضة بالليرة السورية.">
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{data.donations.totals.map((total) => <Card key={total.currency}><p className="text-sm text-muted-foreground">إجمالي التبرعات</p><p className="mt-2 text-2xl font-bold">{formatAnalyticsMoney(total.amountMinor)}</p><p className="mt-1 text-xs text-muted-foreground">{formatInteger(total.operations)} عملية · متوسط {formatAnalyticsMoney(total.averageMinor)}</p></Card>)}</div>
          <div className="grid gap-4 xl:grid-cols-2"><ChartCard title="قيمة التبرعات عبر الوقت" description="الإجمالي بالليرة السورية"><DonationTrendChart data={data.donations.trend} /></ChartCard><ChartCard title="العمليات حسب الغرض"><DistributionChart data={data.donations.byPurpose} /></ChartCard></div>
        </AnalyticsSection>
      )}

      {canOperational && (
        <>
          <AnalyticsSection id="geography" title="التحليل الجغرافي" description="ترتيب مجمع للمحافظات مع إحالة للخريطة التشغيلية عند الحاجة لتفاصيل مكانية.">
            <div className="grid gap-4 xl:grid-cols-2"><ChartCard title="البلاغات حسب المحافظة"><RankedBarChart data={data.geography.reports} /></ChartCard><ChartCard title="المهام حسب المحافظة"><RankedBarChart data={data.geography.missions} /></ChartCard><ChartCard title="الجمعيات حسب المحافظة"><RankedBarChart data={data.geography.organizations} /></ChartCard><ChartCard title="العيادات حسب المحافظة"><RankedBarChart data={data.geography.clinics} /></ChartCard></div>
            {data.geography.gaps.length > 0 && <Card><h3 className="font-bold">فجوات تشغيلية شفافة</h3><div className="mt-3 space-y-2">{data.geography.gaps.map((gap) => <div key={gap.governorate} className="rounded-md bg-muted p-3 text-sm"><strong>{gap.governorate}:</strong> {gap.note} · {formatInteger(gap.reports)} بلاغات · {formatInteger(gap.activeOrganizations)} جمعيات نشطة{gap.averageArrivalMinutes !== undefined ? ` · وصول تقريبي ${formatDuration(gap.averageArrivalMinutes)}` : ''}</div>)}</div></Card>}
            <Link to="/map"><Button variant="secondary"><Map className="size-4" />فتح الخريطة التشغيلية</Button></Link>
          </AnalyticsSection>
          <AnalyticsSection id="quality" title="الجودة التشغيلية" description="مؤشرات تعتمد أهدافًا تشغيلية داخلية مركزية وليست اتفاقيات SLA تعاقدية.">
            <SimpleMetricGrid items={[
              { label: 'بلاغات تجاوزت هدف المراجعة', value: data.quality.reportReviewOverTarget },
              { label: 'مهام تجاوزت هدف القبول', value: data.quality.missionAcceptanceOverTarget },
              { label: 'مهام تجاوزت هدف الوصول', value: data.quality.missionArrivalOverTarget },
              { label: 'طلبات تبني طويلة المراجعة', value: data.quality.adoptionReviewOverTarget },
              ...(canSupport ? [{ label: 'تذاكر دعم تجاوزت هدف أول استجابة', value: data.quality.supportFirstResponseOverTarget }] : []),
            ]} />
          </AnalyticsSection>
        </>
      )}
    </div>
  );
}
