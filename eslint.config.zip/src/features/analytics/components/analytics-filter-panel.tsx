import { Card, Input, Select } from '@/components/ui';
import { governorates, reportSeverityLabels } from '@/features/reports/constants';
import { reportSeverities } from '@/features/reports/types';
import { animalSpecies, type AnimalSpecies } from '@/features/animals/types';
import { speciesLabels } from '@/features/animals/constants';
import { organizationFixtures } from '@/features/organizations/services/organization-fixtures';
import { analyticsRangeOptions } from '../constants';
import type { AnalyticsFilters, AnalyticsRangePreset } from '../types';

export function AnalyticsFilterPanel({
  filters,
  onChange,
}: {
  filters: AnalyticsFilters;
  onChange: (patch: Partial<AnalyticsFilters>) => void;
}) {
  return (
    <Card className="print:hidden">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6">
        <div>
          <label className="mb-1 block text-xs text-muted-foreground">الفترة</label>
          <Select value={filters.range} onValueChange={(value) => onChange({ range: value as AnalyticsRangePreset })} options={analyticsRangeOptions} />
        </div>
        {filters.range === 'custom' && (
          <>
            <label className="text-xs text-muted-foreground">من<Input type="date" value={filters.from} onChange={(event) => onChange({ from: event.target.value })} /></label>
            <label className="text-xs text-muted-foreground">إلى<Input type="date" value={filters.to} onChange={(event) => onChange({ to: event.target.value })} /></label>
          </>
        )}
        <div>
          <label className="mb-1 block text-xs text-muted-foreground">المحافظة</label>
          <Select value={filters.governorate ?? 'ALL'} onValueChange={(value) => onChange({ governorate: value === 'ALL' ? undefined : value })} options={[{ value: 'ALL', label: 'كل المحافظات' }, ...governorates.map((value) => ({ value, label: value }))]} />
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted-foreground">الجمعية</label>
          <Select value={filters.organizationId ?? 'ALL'} onValueChange={(value) => onChange({ organizationId: value === 'ALL' ? undefined : value })} options={[{ value: 'ALL', label: 'كل الجمعيات' }, ...organizationFixtures.filter((item) => item.status === 'ACTIVE').map((item) => ({ value: item.id, label: item.name }))]} />
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted-foreground">نوع الحيوان</label>
          <Select value={filters.species ?? 'ALL'} onValueChange={(value) => onChange({ species: value === 'ALL' ? undefined : value as AnimalSpecies })} options={[{ value: 'ALL', label: 'كل الأنواع' }, ...animalSpecies.map((value) => ({ value, label: speciesLabels[value] }))]} />
        </div>
        <div>
          <label className="mb-1 block text-xs text-muted-foreground">شدة البلاغ</label>
          <Select value={filters.severity ?? 'ALL'} onValueChange={(value) => onChange({ severity: value === 'ALL' ? undefined : value as AnalyticsFilters['severity'] })} options={[{ value: 'ALL', label: 'كل الدرجات' }, ...reportSeverities.map((value) => ({ value, label: reportSeverityLabels[value] }))]} />
        </div>
      </div>
    </Card>
  );
}
