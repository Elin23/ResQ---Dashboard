import type { RescueMissionPriority, RescueMissionStatus } from '../types';

export const missionStatusLabels: Record<RescueMissionStatus, string> = {
  ASSIGNED:'تم الإسناد', ACCEPTED:'تم قبول المهمة', ON_THE_WAY:'في الطريق', ARRIVED:'وصلت الجمعية', RESCUING:'جاري الإنقاذ', TRANSPORTING:'نقل الحيوان', COMPLETED:'مكتملة', CANCELLED:'ملغاة',
};
export const missionPriorityLabels: Record<RescueMissionPriority, string> = { LOW:'منخفضة', MEDIUM:'متوسطة', HIGH:'عالية', CRITICAL:'حرجة' };
export const missionStageOrder: RescueMissionStatus[] = ['ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','RESCUING','TRANSPORTING','COMPLETED'];
export const missionSlaConfig = { acceptanceTargetMinutes: 15, arrivalTargetMinutes: 45 } as const;
export const missionCancellationReasons = ['تم حل الحالة قبل الوصول','تعذر الوصول إلى الموقع','بلاغ غير صحيح','حالة خارجة عن نطاق الإنقاذ','طلبت الجمعية إلغاء المهمة','سبب آخر'] as const;
export const missionGovernates = ['دمشق','ريف دمشق','حلب','حمص','اللاذقية','طرطوس','درعا'] as const;
