import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { dashboardKeys } from '@/features/dashboard/hooks';
import { useSession } from '@/features/auth/session';
import { reportKeys } from '@/features/reports/hooks';
import type { CancelMissionInput, ReassignMissionInput, RescueMissionFilters } from '../types';
import { addMissionNote, cancelMission, getLinkedReport, getMissionByReportId, getMissionOrganizations, getRescueMissionById, getRescueMissions, getRescueMissionSummary, reassignMission } from '../services/rescue-missions.mock';

export const missionKeys={
 all:['rescue-missions'] as const,
 lists:()=>['rescue-missions','list'] as const,
 list:(filters:RescueMissionFilters)=>['rescue-missions','list',filters] as const,
 summary:()=>['rescue-missions','summary'] as const,
 details:()=>['rescue-missions','detail'] as const,
 detail:(id:string)=>['rescue-missions','detail',id] as const,
 byReport:(reportId:string)=>['rescue-missions','by-report',reportId] as const,
 organizations:(search:string)=>['rescue-missions','organizations',search] as const,
 linkedReport:(reportId:string)=>['rescue-missions','linked-report',reportId] as const,
};
export function useRescueMissions(filters:RescueMissionFilters){return useQuery({queryKey:missionKeys.list(filters),queryFn:()=>getRescueMissions(filters),placeholderData:(previous)=>previous});}
export function useRescueMissionSummary(){return useQuery({queryKey:missionKeys.summary(),queryFn:getRescueMissionSummary});}
export function useRescueMission(id:string){return useQuery({queryKey:missionKeys.detail(id),queryFn:()=>getRescueMissionById(id),enabled:Boolean(id)});}
export function useMissionByReport(reportId:string){return useQuery({queryKey:missionKeys.byReport(reportId),queryFn:()=>getMissionByReportId(reportId),enabled:Boolean(reportId)});}
export function useMissionOrganizations(search:string){return useQuery({queryKey:missionKeys.organizations(search),queryFn:()=>getMissionOrganizations(search)});}
export function useLinkedMissionReport(reportId:string){return useQuery({queryKey:missionKeys.linkedReport(reportId),queryFn:()=>getLinkedReport(reportId),enabled:Boolean(reportId)});}
function useMissionInvalidation(id?:string,reportId?:string){const queryClient=useQueryClient();return async()=>{await Promise.all([queryClient.invalidateQueries({queryKey:missionKeys.lists()}),queryClient.invalidateQueries({queryKey:missionKeys.summary()}),queryClient.invalidateQueries({queryKey:dashboardKeys.all}),queryClient.invalidateQueries({queryKey:reportKeys.all}),...(id?[queryClient.invalidateQueries({queryKey:missionKeys.detail(id)})]:[]),...(reportId?[queryClient.invalidateQueries({queryKey:missionKeys.byReport(reportId)})]:[])]);};}
export function useReassignMission(id:string,reportId:string){const {session}=useSession();const invalidate=useMissionInvalidation(id,reportId);return useMutation({mutationFn:(input:ReassignMissionInput)=>{if(!session)throw new Error('SESSION_REQUIRED');return reassignMission(id,input,session);},onSuccess:invalidate});}
export function useCancelMission(id:string,reportId:string){const {session}=useSession();const invalidate=useMissionInvalidation(id,reportId);return useMutation({mutationFn:(input:CancelMissionInput)=>{if(!session)throw new Error('SESSION_REQUIRED');return cancelMission(id,input,session);},onSuccess:invalidate});}
export function useAddMissionNote(id:string){const {session}=useSession();const invalidate=useMissionInvalidation(id);return useMutation({mutationFn:(note:string)=>{if(!session)throw new Error('SESSION_REQUIRED');return addMissionNote(id,note,session);},onSuccess:invalidate});}
