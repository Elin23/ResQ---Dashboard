import { format, formatDistanceToNowStrict, isToday } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { missionSlaConfig, missionStageOrder } from '../constants';
import type { RescueMission, RescueMissionFilters, RescueMissionPriority, RescueMissionStatus, MissionSlaSnapshot } from '../types';
import { safeDate, safeFiniteNumber } from '@/lib/runtime-safety';

export function formatMissionDate(value: string): string { const date=safeDate(value); return date?format(date, 'd MMM yyyy، h:mm a', { locale: arSA }):'—'; }
export function formatMissionRelative(value: string): string { const date=safeDate(value); return date?`منذ ${formatDistanceToNowStrict(date, { locale: arSA })}`:'—'; }
export function missionPriorityRank(priority: RescueMissionPriority): number { return { LOW:1, MEDIUM:2, HIGH:3, CRITICAL:4 }[priority]; }
export function missionStatusIndex(status: RescueMissionStatus): number { return missionStageOrder.indexOf(status); }
export function isMissionTerminal(status: RescueMissionStatus): boolean { return status === 'COMPLETED' || status === 'CANCELLED'; }
export function missionElapsedMinutes(mission: RescueMission): number { const end = mission.completedAt ?? mission.cancelledAt ?? new Date().toISOString(); return Math.max(0, Math.round((new Date(end).getTime() - new Date(mission.assignedAt).getTime()) / 60_000)); }
export function formatDuration(minutes: number): string { minutes=Math.max(0,Math.round(safeFiniteNumber(minutes))); if (minutes < 60) return `${minutes.toLocaleString('ar-SA-u-nu-latn')} دقيقة`; const hours=Math.floor(minutes/60); const rest=minutes%60; return rest ? `${hours.toLocaleString('ar-SA-u-nu-latn')} س ${rest.toLocaleString('ar-SA-u-nu-latn')} د` : `${hours.toLocaleString('ar-SA-u-nu-latn')} س`; }
export function hasMissionFilters(filters: RescueMissionFilters): boolean { return Boolean(filters.search || filters.status || filters.priority || filters.organizationId || filters.governorate || filters.dateFrom || filters.dateTo || filters.sla); }
export function missionSlaSnapshot(mission: RescueMission): MissionSlaSnapshot {
  const assigned = new Date(mission.assignedAt).getTime();
  const accepted = mission.acceptedAt ? new Date(mission.acceptedAt).getTime() : undefined;
  const arrived = mission.arrivedAt ? new Date(mission.arrivedAt).getTime() : undefined;
  const now = Date.now();
  const acceptanceMinutes = accepted ? Math.round((accepted-assigned)/60_000) : undefined;
  const arrivalMinutes = arrived ? Math.round((arrived-assigned)/60_000) : undefined;
  const arrivalElapsed = arrivalMinutes ?? (mission.status !== 'COMPLETED' && mission.status !== 'CANCELLED' ? Math.round((now-assigned)/60_000) : undefined);
  const overdueByMinutes = arrivalElapsed && arrivalElapsed > missionSlaConfig.arrivalTargetMinutes ? arrivalElapsed-missionSlaConfig.arrivalTargetMinutes : undefined;
  return { acceptanceMinutes, arrivalMinutes, totalMinutes: mission.status === 'COMPLETED' ? missionElapsedMinutes(mission) : undefined, ...missionSlaConfig, overdueByMinutes };
}
export function isMissionOverdue(mission: RescueMission): boolean { return Boolean(missionSlaSnapshot(mission).overdueByMinutes); }
export function completedToday(mission: RescueMission): boolean { const date=safeDate(mission.completedAt); return Boolean(date && isToday(date)); }
