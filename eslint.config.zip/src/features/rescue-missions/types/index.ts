export const rescueMissionStatuses = ['ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','RESCUING','TRANSPORTING','COMPLETED','CANCELLED'] as const;
export type RescueMissionStatus = (typeof rescueMissionStatuses)[number];
export const rescueMissionPriorities = ['LOW','MEDIUM','HIGH','CRITICAL'] as const;
export type RescueMissionPriority = (typeof rescueMissionPriorities)[number];
export type MissionMediaType = 'IMAGE' | 'VIDEO';
export type MissionMediaKind = 'ARRIVAL' | 'RESCUE' | 'TRANSPORT' | 'COMPLETION';
export type MissionTimelineAction = 'ASSIGNED' | 'ACCEPTED' | 'DEPARTED' | 'ARRIVED' | 'RESCUE_STARTED' | 'TRANSPORTING' | 'COMPLETED' | 'REASSIGNED' | 'CANCELLED' | 'NOTE_ADDED';

export interface MissionResponder { id: string; name: string; role: string; phone?: string; }
export interface RescueMissionMedia { id: string; type: MissionMediaType; kind: MissionMediaKind; url: string; thumbnailUrl?: string; createdAt: string; }
export interface MissionCompletionSummary { outcome: string; destinationType: 'CLINIC' | 'ORGANIZATION' | 'RELEASED' | 'OTHER'; destinationId?: string; destinationName?: string; completedAt: string; durationMinutes: number; notes?: string; mediaIds: string[]; }
export interface MissionCancellation { reason: string; details?: string; cancelledAt: string; cancelledBy: string; }
export interface MissionTimelineEvent { id: string; action: MissionTimelineAction; title: string; actor?: string; timestamp: string; details?: string; tone?: 'neutral' | 'success' | 'pending' | 'critical' | 'info'; }
export interface MissionInternalNote { id: string; adminName: string; adminRole: string; createdAt: string; note: string; }
export interface MissionOrganization { id: string; name: string; logoUrl?: string; governorate: string; verified: boolean; phone?: string; activeMissions: number; performanceLabel?: string; availability: 'AVAILABLE' | 'LIMITED' | 'UNAVAILABLE'; distanceKm?: number; }

export interface RescueMission {
  id: string;
  reportId: string;
  status: RescueMissionStatus;
  priority: RescueMissionPriority;
  organization: MissionOrganization;
  animal: { type: string; description?: string };
  location: { governorate: string; city?: string; address: string; latitude: number; longitude: number };
  assignedAt: string;
  acceptedAt?: string;
  departedAt?: string;
  arrivedAt?: string;
  rescueStartedAt?: string;
  transportingAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  updatedAt: string;
  responders: MissionResponder[];
  media: RescueMissionMedia[];
  notes?: string;
  completion?: MissionCompletionSummary;
  cancellation?: MissionCancellation;
}

export interface RescueMissionFilters {
  search: string;
  status?: RescueMissionStatus;
  priority?: RescueMissionPriority;
  organizationId?: string;
  governorate?: string;
  dateFrom?: string;
  dateTo?: string;
  sla?: 'OVERDUE';
  page: number;
  pageSize: number;
  sortBy?: 'assignedAt' | 'updatedAt' | 'priority' | 'status';
  sortDirection?: 'asc' | 'desc';
}
export interface RescueMissionListResult { items: RescueMission[]; total: number; page: number; pageSize: number; pageCount: number; }
export interface RescueMissionSummary { activeCount: number; onTheWayCount: number; arrivedCount: number; rescuingCount: number; completedTodayCount: number; overdueCount: number; }
export interface RescueMissionDetails { mission: RescueMission; timeline: MissionTimelineEvent[]; notes: MissionInternalNote[]; }
export interface MissionSlaSnapshot { acceptanceMinutes?: number; arrivalMinutes?: number; totalMinutes?: number; acceptanceTargetMinutes: number; arrivalTargetMinutes: number; overdueByMinutes?: number; }
export interface ReassignMissionInput { organizationId: string; reason: string; }
export interface CancelMissionInput { reason: string; details?: string; }
