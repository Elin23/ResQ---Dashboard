import { z } from 'zod';
export const missionNoteSchema = z.object({ note:z.string().trim().min(3,'اكتب ملاحظة واضحة من 3 أحرف على الأقل.').max(800,'الملاحظة طويلة جداً.') });
export type MissionNoteFormValues = z.infer<typeof missionNoteSchema>;
export const reassignMissionSchema = z.object({ organizationId:z.string().min(1,'اختر جمعية.'), reason:z.string().trim().min(8,'اذكر سبب إعادة الإسناد بوضوح.').max(500) });
export type ReassignMissionFormValues = z.infer<typeof reassignMissionSchema>;
export const cancelMissionSchema = z.object({ reason:z.string().min(1,'اختر سبب الإلغاء.'), details:z.string().trim().max(500).optional() }).superRefine((value,ctx)=>{ if(value.reason==='سبب آخر' && !value.details){ctx.addIssue({code:'custom',path:['details'],message:'اكتب تفاصيل سبب الإلغاء.'});} });
export type CancelMissionFormValues = z.infer<typeof cancelMissionSchema>;
