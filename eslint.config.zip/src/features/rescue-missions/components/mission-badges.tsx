import { Badge, StatusBadge } from '@/components/ui';
import type { RescueMissionPriority, RescueMissionStatus } from '../types';
import { missionPriorityLabels } from '../constants';
export function MissionStatusBadge({status}:{status:RescueMissionStatus}){return <StatusBadge status={`mission:${status}`}/>;}
export function MissionPriorityBadge({priority}:{priority:RescueMissionPriority}){const tone=priority==='CRITICAL'?'critical':priority==='HIGH'?'pending':priority==='MEDIUM'?'info':'neutral';return <Badge tone={tone}>{missionPriorityLabels[priority]}</Badge>;}
