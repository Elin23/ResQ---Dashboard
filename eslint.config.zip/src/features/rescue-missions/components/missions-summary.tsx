import { AlertTriangle, CheckCircle2, Clock3, MapPin, Navigation, Radio } from 'lucide-react';
import { MetricCard, Skeleton } from '@/components/ui';
import type { RescueMissionFilters, RescueMissionSummary } from '../types';
const cards=[
 {key:'activeCount',label:'مهام نشطة',icon:Radio,patch:{status:undefined}},
 {key:'onTheWayCount',label:'في الطريق',icon:Navigation,patch:{status:'ON_THE_WAY'}},
 {key:'arrivedCount',label:'وصلت للموقع',icon:MapPin,patch:{status:'ARRIVED'}},
 {key:'rescuingCount',label:'عمليات إنقاذ جارية',icon:Clock3,patch:{status:'RESCUING'}},
 {key:'completedTodayCount',label:'مكتملة اليوم',icon:CheckCircle2,patch:{status:'COMPLETED',dateFrom:new Date().toISOString().slice(0,10),dateTo:new Date().toISOString().slice(0,10)}},
 {key:'overdueCount',label:'تجاوزت زمن الاستجابة',icon:AlertTriangle,patch:{sla:'OVERDUE'}},
] as const;
export function MissionsSummaryCards({summary,loading,onFilter}:{summary?:RescueMissionSummary;loading:boolean;onFilter:(patch:Partial<RescueMissionFilters>)=>void}){return <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">{cards.map((card)=>loading?<Skeleton key={card.key} className="h-32"/>:<button key={card.key} type="button" className="text-start focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" onClick={()=>onFilter({...card.patch,page:1})}><MetricCard label={card.label} value={summary?.[card.key]??0} icon={card.icon} helper={card.key==='overdueCount'?'وفق أهداف زمنية تجريبية':'اضغط للتصفية'}/></button>)}</div>;}
