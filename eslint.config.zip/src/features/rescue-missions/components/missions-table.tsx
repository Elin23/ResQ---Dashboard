import type { ColumnDef, SortingState } from '@tanstack/react-table';
import { Clipboard, MoreHorizontal } from 'lucide-react';
import { useMemo, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router';
import { toast } from 'sonner';
import { Badge, DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, IconButton } from '@/components/ui';
import { DataTable, type DataTableQueryState } from '@/components/ui/data-table';
import type { RescueMission, RescueMissionFilters } from '../types';
import { formatDuration, formatMissionRelative, isMissionOverdue, missionElapsedMinutes } from '../utils';
import { MissionPriorityBadge, MissionStatusBadge } from './mission-badges';
function RowActions({mission}:{mission:RescueMission}){const navigate=useNavigate();const copy=async()=>{await navigator.clipboard.writeText(mission.id);toast.success('تم نسخ رقم المهمة');};return <DropdownMenu><DropdownMenuTrigger asChild><IconButton label={`إجراءات ${mission.id}`}><MoreHorizontal className="size-5"/></IconButton></DropdownMenuTrigger><DropdownMenuContent><DropdownMenuItem onSelect={()=>navigate(`/rescue-missions/${mission.id}`)}>عرض تفاصيل المهمة</DropdownMenuItem><DropdownMenuItem onSelect={()=>void copy()}><Clipboard className="size-4"/>نسخ رقم المهمة</DropdownMenuItem><DropdownMenuItem onSelect={()=>navigate(`/reports/${mission.reportId}`)}>فتح البلاغ المرتبط</DropdownMenuItem></DropdownMenuContent></DropdownMenu>;}
export function MissionsTable({missions,total,pageCount,filters,loading,error,onRetry,onQueryChange,emptyState}:{missions:RescueMission[];total:number;pageCount:number;filters:RescueMissionFilters;loading:boolean;error?:string;onRetry:()=>void;onQueryChange:(state:DataTableQueryState)=>void;emptyState:ReactNode}){const navigate=useNavigate();const columns=useMemo<Array<ColumnDef<RescueMission,unknown>>>(()=>[
 {accessorKey:'id',header:'رقم المهمة',cell:({row})=><span dir="ltr" className="font-semibold">{row.original.id}</span>},
 {id:'reportId',header:'رقم البلاغ',enableSorting:false,cell:({row})=><Link to={`/reports/${row.original.reportId}`} onClick={(e)=>e.stopPropagation()} dir="ltr" className="font-semibold text-primary hover:underline">{row.original.reportId}</Link>},
 {accessorKey:'status',header:'الحالة',cell:({row})=><MissionStatusBadge status={row.original.status}/>},
 {accessorKey:'priority',header:'الأولوية',cell:({row})=><MissionPriorityBadge priority={row.original.priority}/>},
 {id:'organization',header:'الجمعية',enableSorting:false,cell:({row})=><span className="font-medium">{row.original.organization.name}</span>},
 {id:'location',header:'الموقع',enableSorting:false,cell:({row})=><span>{row.original.location.governorate}{row.original.location.city?` — ${row.original.location.city}`:''}</span>},
 {id:'duration',header:'مدة المهمة',enableSorting:false,cell:({row})=><div><span className="whitespace-nowrap">{formatDuration(missionElapsedMinutes(row.original))}</span>{isMissionOverdue(row.original)&&<Badge tone="pending" className="mt-1 block w-fit">متأخرة</Badge>}</div>},
 {accessorKey:'updatedAt',header:'آخر تحديث',cell:({row})=><span className="whitespace-nowrap text-muted-foreground">{formatMissionRelative(row.original.updatedAt)}</span>},
 ],[]);const sorting:SortingState=filters.sortBy?[{id:filters.sortBy,desc:filters.sortDirection!=='asc'}]:[];return <DataTable data={missions} columns={columns} getRowId={(item)=>item.id} loading={loading} error={error} onRetry={onRetry} enableSearch={false} manualPagination manualFiltering manualSorting pageCount={pageCount} totalCount={total} state={{pageIndex:filters.page-1,pageSize:filters.pageSize,search:'',sorting}} onStateChange={onQueryChange} onRowClick={(mission)=>navigate(`/rescue-missions/${mission.id}`)} rowAriaLabel={(mission)=>`فتح تفاصيل مهمة الإنقاذ ${mission.id}`} rowActions={(mission)=><RowActions mission={mission}/>} emptyState={emptyState}/>;}
