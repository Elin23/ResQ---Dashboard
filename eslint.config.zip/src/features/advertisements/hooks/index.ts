import { keepPreviousData,useMutation,useQuery,useQueryClient } from '@tanstack/react-query';
import { useSession } from '@/features/auth/session';
import { dashboardKeys } from '@/features/dashboard/hooks';
import { organizationKeys } from '@/features/organizations/hooks';
import { clinicKeys } from '@/features/clinics/hooks';
import type { AdvertisementFilters,ScheduleAdvertisementInput } from '../types';
import { activateAdvertisement,addAdvertisementNote,approveAdvertisement,getAdvertisementById,getAdvertisements,getAdvertisementSummary,getAdvertiserAdvertisementSummary,pauseAdvertisement,rejectAdvertisement,resumeAdvertisement,scheduleAdvertisement,startAdvertisementReview } from '../services/advertisements.mock';
export const advertisementKeys={all:['advertisements'] as const,list:(f:AdvertisementFilters)=>['advertisements','list',f] as const,summary:['advertisements','summary'] as const,detail:(id:string)=>['advertisements','detail',id] as const,advertiser:(type:'ORGANIZATION'|'CLINIC',id:string)=>['advertisements','advertiser',type,id] as const};
export const useAdvertisements=(f:AdvertisementFilters)=>useQuery({queryKey:advertisementKeys.list(f),queryFn:()=>getAdvertisements(f),placeholderData:keepPreviousData});
export const useAdvertisementSummary=()=>useQuery({queryKey:advertisementKeys.summary,queryFn:getAdvertisementSummary});
export const useAdvertisement=(id:string)=>useQuery({queryKey:advertisementKeys.detail(id),queryFn:()=>getAdvertisementById(id),enabled:Boolean(id)});
export const useAdvertiserAdvertisementSummary=(type:'ORGANIZATION'|'CLINIC',id:string)=>useQuery({queryKey:advertisementKeys.advertiser(type,id),queryFn:()=>getAdvertiserAdvertisementSummary(type,id),enabled:Boolean(id)});
function actor(){const{session}=useSession();if(!session)throw new Error('SESSION_REQUIRED');return session;}
function invalidate(id:string){const c=useQueryClient();return async()=>{await Promise.all([c.invalidateQueries({queryKey:advertisementKeys.all}),c.invalidateQueries({queryKey:advertisementKeys.detail(id)}),c.invalidateQueries({queryKey:dashboardKeys.all}),c.invalidateQueries({queryKey:organizationKeys.all}),c.invalidateQueries({queryKey:clinicKeys.all})]);};}
export function useStartAdvertisementReview(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:()=>startAdvertisementReview(id,a),onSuccess:done});}
export function useApproveAdvertisement(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:()=>approveAdvertisement(id,a),onSuccess:done});}
export function useRejectAdvertisement(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:(reason:string)=>rejectAdvertisement(id,reason,a),onSuccess:done});}
export function useScheduleAdvertisement(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:(input:ScheduleAdvertisementInput)=>scheduleAdvertisement(id,input,a),onSuccess:done});}
export function useActivateAdvertisement(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:()=>activateAdvertisement(id,a),onSuccess:done});}
export function usePauseAdvertisement(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:(reason:string)=>pauseAdvertisement(id,reason,a),onSuccess:done});}
export function useResumeAdvertisement(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:()=>resumeAdvertisement(id,a),onSuccess:done});}
export function useAddAdvertisementNote(id:string){const a=actor(),done=invalidate(id);return useMutation({mutationFn:(note:string)=>addAdvertisementNote(id,note,a),onSuccess:done});}
