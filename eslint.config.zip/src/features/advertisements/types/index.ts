export const advertisementStatuses=['DRAFT','PENDING_REVIEW','SCHEDULED','ACTIVE','PAUSED','EXPIRED','REJECTED'] as const;
export type AdvertisementStatus=(typeof advertisementStatuses)[number];
export const advertiserTypes=['ORGANIZATION','CLINIC','RESQ'] as const;
export type AdvertiserType=(typeof advertiserTypes)[number];
export const advertisementPlacements=['HOME_BANNER','ADOPTION','ORGANIZATIONS','CLINICS','MAP','SEARCH'] as const;
export type AdvertisementPlacement=(typeof advertisementPlacements)[number];
export type AdvertisementCreativeType='IMAGE'|'BANNER';
export interface AdvertisementCreative{type:AdvertisementCreativeType;imageUrl:string;altText:string;mobileImageUrl?:string;backgroundColor?:string;callToActionLabel?:string;}
export interface AdvertisementAudience{allUsers:boolean;userTypes?:Array<'USER'|'ORGANIZATION'|'CLINIC'>;governorates?:string[];animalInterests?:string[];}
export interface AdvertisementPerformance{impressions?:number;clicks?:number;clickThroughRate?:number;mockData:boolean;}
export interface AdvertisementReview{reviewerId?:string;reviewerName?:string;startedAt?:string;approvedAt?:string;warnings:string[];note?:string;}
export interface AdvertisementTimelineEvent{id:string;title:string;actor?:string;timestamp:string;details?:string;tone?:'neutral'|'success'|'pending'|'critical'|'info';}
export interface AdvertisementInternalNote{id:string;adminName:string;adminRole:string;createdAt:string;note:string;}
export interface Advertisement{ id:string;advertiser:{type:AdvertiserType;id?:string;name:string};title:string;description?:string;creative:AdvertisementCreative;placement:AdvertisementPlacement;audience:AdvertisementAudience;startAt?:string;endAt?:string;priority:number;status:AdvertisementStatus;targetUrl?:string;submittedAt?:string;reviewedAt?:string;activatedAt?:string;pausedAt?:string;expiredAt?:string;rejectionReason?:string;pauseReason?:string;createdAt:string;updatedAt:string;performance?:AdvertisementPerformance;}
export interface AdvertisementDetails{advertisement:Advertisement;review:AdvertisementReview;timeline:AdvertisementTimelineEvent[];notes:AdvertisementInternalNote[];advertiserEligible:boolean;advertiserWarning?:string;}
export interface AdvertisementFilters{search:string;status?:AdvertisementStatus;advertiserType?:AdvertiserType;advertiserId?:string;organizationId?:string;clinicId?:string;placement?:AdvertisementPlacement;governorate?:string;dateFrom?:string;dateTo?:string;activePeriod?:'CURRENT'|'FUTURE'|'PAST';page:number;pageSize:number;sortBy?:'updatedAt'|'startAt'|'priority'|'status';sortDirection?:'asc'|'desc';}
export interface AdvertisementListResult{items:Advertisement[];total:number;page:number;pageSize:number;pageCount:number;}
export interface AdvertisementSummary{pendingReview:number;scheduled:number;active:number;paused:number;expired:number;rejected:number;}
export interface AdvertisementAdvertiserSummary{active:number;pending:number;paused:number;recent:Advertisement[];}
export interface ScheduleAdvertisementInput{startAt:string;endAt:string;priority:number;}
