import { Badge,StatusBadge } from '@/components/ui';
import type { SemanticStatus } from '@/lib/statuses';
import type { AdvertisementStatus,AdvertiserType } from '../types';
import { advertiserTypeLabels } from '../constants';
const statusMap:Record<AdvertisementStatus,SemanticStatus>={DRAFT:'advertisement:DRAFT',PENDING_REVIEW:'advertisement:PENDING_REVIEW',SCHEDULED:'advertisement:SCHEDULED',ACTIVE:'advertisement:ACTIVE',PAUSED:'advertisement:PAUSED',EXPIRED:'advertisement:EXPIRED',REJECTED:'advertisement:REJECTED'};
export function AdvertisementStatusBadge({status}:{status:AdvertisementStatus}){return <StatusBadge status={statusMap[status]}/>;}
export function AdvertiserTypeBadge({type}:{type:AdvertiserType}){return <Badge tone={type==='RESQ'?'info':'neutral'}>{advertiserTypeLabels[type]}</Badge>;}
