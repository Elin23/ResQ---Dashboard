import { z } from 'zod';
export const noteSchema=z.object({note:z.string().trim().min(3,'أدخل ملاحظة واضحة').max(1000,'الملاحظة طويلة جدًا')});
export const reasonSchema=z.object({reason:z.string().min(1,'اختر السبب'),otherReason:z.string().trim().max(500).optional()}).superRefine((v,ctx)=>{if(v.reason==='سبب آخر'&&!v.otherReason){ctx.addIssue({code:'custom',path:['otherReason'],message:'اكتب السبب'});}});
export const assignSchema=z.object({organizationId:z.string().min(1,'اختر الجمعية'),note:z.string().trim().max(500).optional()});
export const resolveIssueSchema=z.object({resolutionNote:z.string().trim().min(5,'اكتب ملاحظة الحل').max(800)});
export const refillSchema=z.object({foodLevel:z.enum(['FULL','MEDIUM','LOW','EMPTY']),waterAvailable:z.boolean(),note:z.string().trim().max(500).optional()});
