import { Badge,StatusBadge } from '@/components/ui';
import { conditionLabels,foodLevelLabels,issueStatusLabels } from '../constants';
import type { FeedingPointCondition,FeedingPointFoodLevel,FeedingPointIssueStatus,FeedingPointStatus } from '../types';
export const FeedingPointStatusBadge=({status}:{status:FeedingPointStatus})=><StatusBadge status={`feeding-point:${status}`}/>;
export function FoodLevelBadge({level}:{level?:FeedingPointFoodLevel}){const value=level??'UNKNOWN';const tone=value==='FULL'?'success':value==='MEDIUM'?'info':value==='LOW'?'pending':value==='EMPTY'?'critical':'neutral';return <Badge tone={tone}>{foodLevelLabels[value]}</Badge>}
export function ConditionBadge({condition}:{condition?:FeedingPointCondition}){const value=condition??'UNKNOWN';const tone=value==='GOOD'?'success':value==='NEEDS_CLEANING'?'pending':value==='DAMAGED'||value==='MISSING'?'critical':'neutral';return <Badge tone={tone}>{conditionLabels[value]}</Badge>}
export function IssueStatusBadge({status}:{status:FeedingPointIssueStatus}){const tone=status==='RESOLVED'?'success':status==='UNDER_REVIEW'?'pending':status==='OPEN'?'critical':'neutral';return <Badge tone={tone}>{issueStatusLabels[status]}</Badge>}
