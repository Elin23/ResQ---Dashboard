import { getReports } from '@/features/reports/services/reports.mock';
import { getRescueMissions } from '@/features/rescue-missions/services/rescue-missions.mock';
import { getOrganizations } from '@/features/organizations/services/organizations.mock';
import { organizationServiceLabels } from '@/features/organizations/constants';
import { getClinics } from '@/features/clinics/services/clinics.mock';
import { clinicServiceLabels } from '@/features/clinics/constants';
import { getFeedingPoints } from '@/features/feeding-points/services/feeding-points.mock';
import type { MapEntity, OperationalMapData } from '../types';

const activeMissionStatuses=['ASSIGNED','ACCEPTED','ON_THE_WAY','ARRIVED','RESCUING','TRANSPORTING'] as const;
export async function getOperationalMapData():Promise<OperationalMapData>{
 const errors:OperationalMapData['errors']=[]; const entities:MapEntity[]=[];
 const settled=await Promise.allSettled([
  getReports({search:'',page:1,pageSize:250,sortBy:'updatedAt',sortDirection:'desc'}),
  getRescueMissions({search:'',page:1,pageSize:250,sortBy:'updatedAt',sortDirection:'desc'}),
  getOrganizations({search:'',page:1,pageSize:250,sortBy:'updatedAt',sortDirection:'desc'}),
  getClinics({search:'',page:1,pageSize:250,sortBy:'updatedAt',sortDirection:'desc'}),
  getFeedingPoints({search:'',page:1,pageSize:250,sortBy:'updatedAt',sortDirection:'desc'}),
 ]);
 const [reports,missions,organizations,clinics,feeding]=settled;
 if(reports.status==='fulfilled')for(const r of reports.value.items){if(['CLOSED','REJECTED'].includes(r.status))continue;entities.push({id:`REPORT:${r.id}`,sourceId:r.id,type:'REPORT',coordinates:{latitude:r.latitude,longitude:r.longitude},title:r.title,subtitle:r.id,governorate:r.governorate,city:r.city,address:r.address,updatedAt:r.updatedAt,metadata:{severity:r.severity,status:r.status,animalType:r.animalType,createdAt:r.createdAt,assignedOrganizationId:r.assignedOrganization?.id,assignedOrganizationName:r.assignedOrganization?.name}})} else errors.push({layer:'REPORTS',message:'تعذر تحميل بيانات البلاغات.'});
 if(missions.status==='fulfilled')for(const m of missions.value.items){if(!activeMissionStatuses.includes(m.status as (typeof activeMissionStatuses)[number]))continue;entities.push({id:`MISSION:${m.id}`,sourceId:m.id,type:'MISSION',coordinates:{latitude:m.location.latitude,longitude:m.location.longitude},title:m.id,subtitle:m.animal.description??m.reportId,governorate:m.location.governorate,city:m.location.city,address:m.location.address,updatedAt:m.updatedAt,metadata:{status:m.status,priority:m.priority,reportId:m.reportId,organizationId:m.organization.id,organizationName:m.organization.name,assignedAt:m.assignedAt}})} else errors.push({layer:'ACTIVE_MISSIONS',message:'تعذر تحميل بيانات عمليات الإنقاذ.'});
 if(organizations.status==='fulfilled')for(const o of organizations.value.items){if(o.status!=='ACTIVE'||o.verificationStatus!=='VERIFIED'||o.latitude===undefined||o.longitude===undefined)continue;entities.push({id:`ORGANIZATION:${o.id}`,sourceId:o.id,type:'ORGANIZATION',coordinates:{latitude:o.latitude,longitude:o.longitude},title:o.name,subtitle:o.id,governorate:o.governorate,city:o.city,address:o.address,updatedAt:o.updatedAt,metadata:{status:o.status,verificationStatus:o.verificationStatus,services:o.services.map(s=>organizationServiceLabels[s.key]),activeMissions:o.statistics?.activeMissions??0}})} else errors.push({layer:'ORGANIZATIONS',message:'تعذر تحميل بيانات الجمعيات.'});
 if(clinics.status==='fulfilled')for(const c of clinics.value.items){if(c.status!=='ACTIVE'||c.verificationStatus!=='VERIFIED'||c.latitude===undefined||c.longitude===undefined)continue;entities.push({id:`CLINIC:${c.id}`,sourceId:c.id,type:'CLINIC',coordinates:{latitude:c.latitude,longitude:c.longitude},title:c.name,subtitle:c.id,governorate:c.governorate,city:c.city,address:c.address,updatedAt:c.updatedAt,metadata:{status:c.status,verificationStatus:c.verificationStatus,emergencyAvailable:c.emergencyAvailable,open24Hours:c.open24Hours,services:c.services.map(s=>clinicServiceLabels[s.key])}})} else errors.push({layer:'CLINICS',message:'تعذر تحميل بيانات العيادات.'});
 if(feeding.status==='fulfilled')for(const p of feeding.value.items){if(p.status==='REJECTED')continue;entities.push({id:`FEEDING_POINT:${p.id}`,sourceId:p.id,type:'FEEDING_POINT',coordinates:{latitude:p.location.latitude,longitude:p.location.longitude},title:p.name??p.id,subtitle:p.id,governorate:p.location.governorate,city:p.location.city,address:p.location.address,updatedAt:p.updatedAt,metadata:{status:p.status,foodLevel:p.foodLevel,condition:p.condition,openIssuesCount:p.openIssuesCount,latestUpdateAt:p.latestUpdateAt}})} else errors.push({layer:'FEEDING_POINTS',message:'تعذر تحميل بيانات نقاط الإطعام.'});
 return {entities,generatedAt:new Date().toISOString(),errors};
}
