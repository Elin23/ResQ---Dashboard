import { useQuery } from '@tanstack/react-query';
import { getOperationalMapData } from '../services/operational-map.service';
export const operationalMapKeys={all:['operational-map'] as const,data:()=>['operational-map','data'] as const};
export function useOperationalMapData(enabled=true){return useQuery({queryKey:operationalMapKeys.data(),queryFn:getOperationalMapData,enabled,refetchInterval:enabled?60_000:false,refetchIntervalInBackground:false});}
