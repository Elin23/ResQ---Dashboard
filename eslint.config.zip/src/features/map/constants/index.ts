import { Building2, HeartHandshake, ShieldAlert, ShieldCheck, Stethoscope, Utensils, type LucideIcon } from 'lucide-react';
import type { MapEntityType, MapLayerKey } from '../types';

export type MapLayerConfig={key:MapLayerKey;label:string;description:string;icon:LucideIcon;defaultVisible:boolean;requiredPermission:'reports:view'|'missions:view'|'organizations:read'|'clinics:read'|'feeding_points.read'};
export const mapLayerConfigs:MapLayerConfig[]=[
 {key:'CRITICAL_REPORTS',label:'البلاغات الحرجة',description:'بلاغات حرجة غير مغلقة أو مرفوضة',icon:ShieldAlert,defaultVisible:true,requiredPermission:'reports:view'},
 {key:'REPORTS',label:'البلاغات',description:'البلاغات التشغيلية غير الحرجة',icon:ShieldCheck,defaultVisible:true,requiredPermission:'reports:view'},
 {key:'ACTIVE_MISSIONS',label:'عمليات الإنقاذ النشطة',description:'المهام الجارية فقط',icon:HeartHandshake,defaultVisible:true,requiredPermission:'missions:view'},
 {key:'ORGANIZATIONS',label:'الجمعيات',description:'الجمعيات الفعالة والموثقة',icon:Building2,defaultVisible:true,requiredPermission:'organizations:read'},
 {key:'CLINICS',label:'العيادات',description:'العيادات الفعالة والموثقة',icon:Stethoscope,defaultVisible:true,requiredPermission:'clinics:read'},
 {key:'FEEDING_POINTS',label:'نقاط الإطعام',description:'النقاط غير المرفوضة',icon:Utensils,defaultVisible:true,requiredPermission:'feeding_points.read'},
];
export const entityTypeLabels:Record<MapEntityType,string>={REPORT:'بلاغ',MISSION:'مهمة إنقاذ',ORGANIZATION:'جمعية',CLINIC:'عيادة',FEEDING_POINT:'نقطة إطعام'};
export const syrianGovernorates=['دمشق','ريف دمشق','حلب','حمص','حماة','اللاذقية','طرطوس','إدلب','درعا','السويداء','القنيطرة','دير الزور','الرقة','الحسكة'] as const;
