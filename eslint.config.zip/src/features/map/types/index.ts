import type { ReportSeverity, ReportStatus } from '@/features/reports/types';
import type { RescueMissionPriority, RescueMissionStatus } from '@/features/rescue-missions/types';
import type { FeedingPointCondition, FeedingPointFoodLevel, FeedingPointStatus } from '@/features/feeding-points/types';

export const mapLayerKeys = ['REPORTS','CRITICAL_REPORTS','ACTIVE_MISSIONS','ORGANIZATIONS','CLINICS','FEEDING_POINTS'] as const;
export type MapLayerKey = (typeof mapLayerKeys)[number];
export type MapEntityType = 'REPORT'|'MISSION'|'ORGANIZATION'|'CLINIC'|'FEEDING_POINT';
export type MapCoordinates = { latitude:number; longitude:number };

type BaseMapEntity = { id:string; sourceId:string; coordinates:MapCoordinates; title:string; subtitle?:string; governorate:string; city?:string; address:string; updatedAt:string };
export type ReportMapEntity = BaseMapEntity & { type:'REPORT'; metadata:{ severity:ReportSeverity; status:ReportStatus; animalType:string; createdAt:string; assignedOrganizationId?:string; assignedOrganizationName?:string } };
export type MissionMapEntity = BaseMapEntity & { type:'MISSION'; metadata:{ status:RescueMissionStatus; priority:RescueMissionPriority; reportId:string; organizationId:string; organizationName:string; assignedAt:string } };
export type OrganizationMapEntity = BaseMapEntity & { type:'ORGANIZATION'; metadata:{ status:string; verificationStatus:string; services:string[]; activeMissions:number } };
export type ClinicMapEntity = BaseMapEntity & { type:'CLINIC'; metadata:{ status:string; verificationStatus:string; emergencyAvailable:boolean; open24Hours:boolean; services:string[] } };
export type FeedingPointMapEntity = BaseMapEntity & { type:'FEEDING_POINT'; metadata:{ status:FeedingPointStatus; foodLevel?:FeedingPointFoodLevel; condition?:FeedingPointCondition; openIssuesCount:number; latestUpdateAt?:string } };
export type MapEntity = ReportMapEntity|MissionMapEntity|OrganizationMapEntity|ClinicMapEntity|FeedingPointMapEntity;

export type MapFilters = { search:string; governorate?:string; type?:MapEntityType; criticalOnly?:boolean; clinicEmergencyOnly?:boolean; clinic24HoursOnly?:boolean; feedingNeedsRefillOnly?:boolean; feedingDamagedOnly?:boolean; feedingOpenIssuesOnly?:boolean };
export type OperationalMapData = { entities:MapEntity[]; generatedAt:string; errors:Array<{layer:MapLayerKey;message:string}> };
