import { z } from 'zod';

export const noteSchema = z.object({ note: z.string().trim().min(3, 'أدخل ملاحظة واضحة من 3 أحرف على الأقل.').max(1000, 'الملاحظة طويلة جدًا.') });
export type NoteFormValues = z.infer<typeof noteSchema>;

export const severitySchema = z.object({ severity: z.enum(['LOW','MEDIUM','HIGH','CRITICAL']), reason: z.string().trim().min(3, 'اذكر سبب تغيير الخطورة.').max(500) });
export type SeverityFormValues = z.infer<typeof severitySchema>;

export const assignmentSchema = z.object({ organizationId: z.string().min(1, 'اختر جمعية للإسناد.') });
export type AssignmentFormValues = z.infer<typeof assignmentSchema>;

export const rejectionSchema = z.object({ reason: z.string().min(1, 'اختر سبب الرفض.'), details: z.string().trim().max(500).optional() }).superRefine((value, ctx) => {
  if (value.reason === 'سبب آخر' && !value.details?.trim()) ctx.addIssue({ code: 'custom', path: ['details'], message: 'اكتب سبب الرفض.' });
});
export type RejectionFormValues = z.infer<typeof rejectionSchema>;

export const closeSchema = z.object({ note: z.string().trim().max(500, 'ملاحظة الإغلاق طويلة جدًا.').optional() });
export type CloseFormValues = z.infer<typeof closeSchema>;
