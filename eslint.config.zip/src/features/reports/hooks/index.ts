import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { dashboardKeys } from '@/features/dashboard/hooks';
import { useSession } from '@/features/auth/session';
import type { RejectReportInput, ReportFilters, ReportSeverity } from '../types';
import { addReportNote, assignReport, changeReportSeverity, changeReportsSeverity, closeReport, getEligibleOrganizations, getReportById, getReportSummary, getReports, rejectReport, verifyReport } from '../services/reports.mock';

export const reportKeys = {
  all: ['reports'] as const,
  lists: () => [...reportKeys.all, 'list'] as const,
  list: (filters: ReportFilters) => [...reportKeys.lists(), filters] as const,
  summary: () => [...reportKeys.all, 'summary'] as const,
  details: () => [...reportKeys.all, 'detail'] as const,
  detail: (reportId: string) => [...reportKeys.details(), reportId] as const,
  organizations: (search: string) => [...reportKeys.all, 'eligible-organizations', search] as const,
};

export function useReports(filters: ReportFilters) {
  return useQuery({ queryKey: reportKeys.list(filters), queryFn: () => getReports(filters), placeholderData: (previous) => previous });
}
export function useReportsSummary() { return useQuery({ queryKey: reportKeys.summary(), queryFn: getReportSummary }); }
export function useReport(reportId: string) { return useQuery({ queryKey: reportKeys.detail(reportId), queryFn: () => getReportById(reportId), enabled: Boolean(reportId) }); }
export function useEligibleOrganizations(search: string) { return useQuery({ queryKey: reportKeys.organizations(search), queryFn: () => getEligibleOrganizations(search) }); }

function useReportMutationInvalidation(reportId?: string) {
  const queryClient = useQueryClient();
  return async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: reportKeys.lists() }),
      queryClient.invalidateQueries({ queryKey: reportKeys.summary() }),
      queryClient.invalidateQueries({ queryKey: dashboardKeys.all }),
      ...(reportId ? [queryClient.invalidateQueries({ queryKey: reportKeys.detail(reportId) })] : []),
    ]);
  };
}

export function useVerifyReport(reportId: string) {
  const { session } = useSession();
  const invalidate = useReportMutationInvalidation(reportId);
  return useMutation({ mutationFn: () => { if (!session) throw new Error('SESSION_REQUIRED'); return verifyReport(reportId, session); }, onSuccess: invalidate });
}
export function useChangeReportSeverity(reportId: string) {
  const { session } = useSession();
  const invalidate = useReportMutationInvalidation(reportId);
  return useMutation({ mutationFn: (input: { severity: ReportSeverity; reason: string }) => { if (!session) throw new Error('SESSION_REQUIRED'); return changeReportSeverity(reportId, input.severity, input.reason, session); }, onSuccess: invalidate });
}
export function useAssignReport(reportId: string) {
  const { session } = useSession();
  const invalidate = useReportMutationInvalidation(reportId);
  return useMutation({ mutationFn: (organizationId: string) => { if (!session) throw new Error('SESSION_REQUIRED'); return assignReport(reportId, organizationId, session); }, onSuccess: invalidate });
}
export function useRejectReport(reportId: string) {
  const { session } = useSession();
  const invalidate = useReportMutationInvalidation(reportId);
  return useMutation({ mutationFn: (input: RejectReportInput) => { if (!session) throw new Error('SESSION_REQUIRED'); return rejectReport(reportId, input, session); }, onSuccess: invalidate });
}
export function useCloseReport(reportId: string) {
  const { session } = useSession();
  const invalidate = useReportMutationInvalidation(reportId);
  return useMutation({ mutationFn: (note?: string) => { if (!session) throw new Error('SESSION_REQUIRED'); return closeReport(reportId, note, session); }, onSuccess: invalidate });
}
export function useAddReportNote(reportId: string) {
  const { session } = useSession();
  const invalidate = useReportMutationInvalidation(reportId);
  return useMutation({ mutationFn: (note: string) => { if (!session) throw new Error('SESSION_REQUIRED'); return addReportNote(reportId, note, session); }, onSuccess: invalidate });
}

export function useBulkChangeReportSeverity() {
  const { session } = useSession();
  const invalidate = useReportMutationInvalidation();
  return useMutation({ mutationFn: (input: { reportIds: string[]; severity: ReportSeverity; reason: string }) => { if (!session) throw new Error('SESSION_REQUIRED'); return changeReportsSeverity(input.reportIds, input.severity, input.reason, session); }, onSuccess: invalidate });
}
