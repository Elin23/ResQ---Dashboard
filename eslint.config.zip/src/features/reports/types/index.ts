export const reportStatuses = ['NEW','UNDER_REVIEW','VERIFIED','WAITING_FOR_ORGANIZATION','ASSIGNED','IN_PROGRESS','RESCUED','CLOSED','REJECTED'] as const;
export type ReportStatus = (typeof reportStatuses)[number];
export const reportSeverities = ['LOW','MEDIUM','HIGH','CRITICAL'] as const;
export type ReportSeverity = (typeof reportSeverities)[number];
export const animalTypes = ['DOG','CAT','BIRD','OTHER'] as const;
export type AnimalType = (typeof animalTypes)[number];
export type ReportMediaType = 'IMAGE' | 'VIDEO';

export interface ReportMedia { id: string; type: ReportMediaType; url: string; thumbnailUrl?: string; createdAt: string; }
export interface Reporter { id: string; name: string; phone?: string; email?: string; isGuest: boolean; }
export interface AssignedOrganization { id: string; name: string; }
export interface Report {
  id: string;
  status: ReportStatus;
  severity: ReportSeverity;
  animalType: AnimalType;
  animalDescription?: string;
  title: string;
  description: string;
  governorate: string;
  city?: string;
  address: string;
  latitude: number;
  longitude: number;
  reporter: Reporter;
  assignedOrganization?: AssignedOrganization;
  media: ReportMedia[];
  createdAt: string;
  updatedAt: string;
  verifiedAt?: string;
  assignedAt?: string;
  closedAt?: string;
  internalNotesCount?: number;
  rejectionReason?: string;
}

export interface ReportFilters {
  search: string;
  status?: ReportStatus;
  severity?: ReportSeverity;
  animalType?: AnimalType;
  governorate?: string;
  organizationId?: string;
  userId?: string;
  dateFrom?: string;
  dateTo?: string;
  sla?: 'BREACHED';
  page: number;
  pageSize: number;
  sortBy?: 'createdAt' | 'updatedAt' | 'severity' | 'status';
  sortDirection?: 'asc' | 'desc';
}

export interface ReportListResult { items: Report[]; total: number; page: number; pageSize: number; pageCount: number; }
export interface ReportSummary { newCount: number; criticalCount: number; waitingOrganizationCount: number; activeRescueCount: number; rescuedTodayCount: number; }
export interface ReportTimelineEvent { id: string; action: string; actor?: string; timestamp: string; details?: string; tone?: 'neutral' | 'success' | 'pending' | 'critical' | 'info'; }
export interface ReportNote { id: string; adminName: string; adminRole: string; createdAt: string; note: string; }
export interface ReportDetails { report: Report; timeline: ReportTimelineEvent[]; notes: ReportNote[]; }
export interface EligibleOrganization { id: string; name: string; governorate: string; distanceKm?: number; activeMissions: number; availability: 'AVAILABLE' | 'LIMITED' | 'UNAVAILABLE'; }
export interface RejectReportInput { reason: string; details?: string; }
