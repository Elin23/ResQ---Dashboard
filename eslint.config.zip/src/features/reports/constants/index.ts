import type { AnimalType, ReportSeverity, ReportStatus } from '../types';

export const reportStatusLabels: Record<ReportStatus, string> = {
  NEW: 'جديد', UNDER_REVIEW: 'قيد المراجعة', VERIFIED: 'تم التحقق', WAITING_FOR_ORGANIZATION: 'بانتظار جمعية', ASSIGNED: 'تم الإسناد', IN_PROGRESS: 'الإنقاذ جارٍ', RESCUED: 'تم الإنقاذ', CLOSED: 'مغلق', REJECTED: 'مرفوض',
};
export const reportSeverityLabels: Record<ReportSeverity, string> = { LOW: 'منخفضة', MEDIUM: 'متوسطة', HIGH: 'عالية', CRITICAL: 'حرجة' };
export const animalTypeLabels: Record<AnimalType, string> = { DOG: 'كلب', CAT: 'قطة', BIRD: 'طائر', OTHER: 'حيوان آخر' };
export const governorates = ['دمشق','ريف دمشق','حلب','حمص','حماة','اللاذقية','طرطوس','درعا'] as const;
export const rejectionReasons = ['بلاغ مكرر','معلومات غير كافية','خارج نطاق الخدمة','لا توجد حالة إنقاذ','محتوى غير مناسب','سبب آخر'] as const;
