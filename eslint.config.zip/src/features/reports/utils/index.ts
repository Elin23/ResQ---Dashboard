import { format, formatDistanceToNowStrict, isToday } from 'date-fns';
import { arSA } from 'date-fns/locale';
import type { ReportFilters, ReportSeverity } from '../types';
import { safeDate, isValidCoordinate } from '@/lib/runtime-safety';

export function formatReportDate(value: string): string { const date=safeDate(value); return date?format(date, 'd MMM yyyy، h:mm a', { locale: arSA }):'—'; }
export function formatRelativeTime(value: string): string { const date=safeDate(value); return date?`منذ ${formatDistanceToNowStrict(date, { locale: arSA })}`:'—'; }
export function isTodayIso(value: string): boolean { const date=safeDate(value); return date?isToday(date):false; }
export function severityRank(severity: ReportSeverity): number { return { LOW: 1, MEDIUM: 2, HIGH: 3, CRITICAL: 4 }[severity]; }
export function hasActiveFilters(filters: ReportFilters): boolean {
  return Boolean(filters.search || filters.status || filters.severity || filters.animalType || filters.governorate || filters.organizationId || filters.userId || filters.dateFrom || filters.dateTo || filters.sla);
}
export function coordinatesText(latitude: number, longitude: number): string { return isValidCoordinate(latitude,longitude)?`${latitude.toFixed(5)}, ${longitude.toFixed(5)}`:'إحداثيات غير صالحة'; }
