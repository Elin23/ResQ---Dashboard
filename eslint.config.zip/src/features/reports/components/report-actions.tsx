import { useState } from 'react';
import { toast } from 'sonner';
import { Button, ConfirmDialog } from '@/components/ui';
import { PermissionGuard, usePermission } from '@/features/auth/rbac';
import { useVerifyReport } from '../hooks';
import type { Report } from '../types';
import { ReportWorkflowDialog, type ReportWorkflow } from './report-workflow-dialogs';

export function ReportActions({ report }: { report:Report }) {
  const [verifyOpen,setVerifyOpen]=useState(false);
  const [workflow,setWorkflow]=useState<ReportWorkflow|null>(null);
  const verify=useVerifyReport(report.id);
  const canVerify=usePermission('reports:verify');
  const verifyAllowed=canVerify&&['NEW','UNDER_REVIEW'].includes(report.status);
  const primary = verifyAllowed ? <Button onClick={()=>setVerifyOpen(true)}>اعتماد البلاغ</Button> : <PermissionGuard permission="reports:assign"><Button onClick={()=>setWorkflow('assign')} disabled={['CLOSED','REJECTED','RESCUED'].includes(report.status)}>إسناد لجمعية</Button></PermissionGuard>;
  return <div className="flex flex-wrap gap-2">{primary}<PermissionGuard permission="reports:update"><Button variant="secondary" onClick={()=>setWorkflow('severity')}>تغيير الخطورة</Button></PermissionGuard><PermissionGuard permission="reports:close"><Button variant="secondary" onClick={()=>setWorkflow('close')}>إغلاق البلاغ</Button></PermissionGuard><PermissionGuard permission="reports:reject">{!['CLOSED','REJECTED','RESCUED','IN_PROGRESS'].includes(report.status)&&<Button variant="ghost" className="text-critical" onClick={()=>setWorkflow('reject')}>رفض البلاغ</Button>}</PermissionGuard><ConfirmDialog open={verifyOpen} onOpenChange={setVerifyOpen} title="اعتماد البلاغ" description="سيتم اعتبار البلاغ متحققًا وتحويله إلى مرحلة البحث عن جمعية مناسبة للاستلام." confirmLabel="اعتماد البلاغ" onConfirm={()=>verify.mutate(undefined,{onSuccess:()=>toast.success('تم اعتماد البلاغ'),onError:()=>toast.error('تعذر اعتماد البلاغ')})} />{workflow&&<ReportWorkflowDialog report={report} workflow={workflow} open onOpenChange={(open)=>{if(!open)setWorkflow(null);}} />}</div>;
}
