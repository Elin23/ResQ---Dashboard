import { Activity, Ambulance, CircleAlert, CircleCheck, Inbox } from 'lucide-react';
import { MetricCard, Skeleton } from '@/components/ui';
import type { ReportFilters, ReportSummary } from '../types';

const items = [
  { key:'newCount' as const, label:'البلاغات الجديدة', icon:Inbox, patch:{ status:'NEW' } satisfies Partial<ReportFilters> },
  { key:'criticalCount' as const, label:'الحالات الحرجة', icon:CircleAlert, patch:{ severity:'CRITICAL' } satisfies Partial<ReportFilters> },
  { key:'waitingOrganizationCount' as const, label:'بانتظار جمعية', icon:Ambulance, patch:{ status:'WAITING_FOR_ORGANIZATION' } satisfies Partial<ReportFilters> },
  { key:'activeRescueCount' as const, label:'عمليات الإنقاذ الجارية', icon:Activity, patch:{ status:'IN_PROGRESS' } satisfies Partial<ReportFilters> },
  { key:'rescuedTodayCount' as const, label:'تم إنقاذها اليوم', icon:CircleCheck, patch:{ status:'RESCUED' } satisfies Partial<ReportFilters> },
];
export function ReportsSummaryCards({ summary, loading, onFilter }: { summary?: ReportSummary; loading: boolean; onFilter: (patch: Partial<ReportFilters>) => void }) {
  if (loading) return <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">{items.map((item) => <Skeleton key={item.key} className="h-28" />)}</div>;
  if (!summary) return null;
  return <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">{items.map((item) => <button key={item.key} type="button" className="text-start" onClick={() => onFilter({ ...item.patch, page:1 })}><MetricCard label={item.label} value={summary[item.key]} icon={item.icon} helper="اضغط لعرض الحالات" /></button>)}</div>;
}
