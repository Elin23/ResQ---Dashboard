import { zodResolver } from '@hookform/resolvers/zod';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { toast } from 'sonner';
import { Button, Input, Modal, Select, Textarea } from '@/components/ui';
import { assignmentSchema, closeSchema, rejectionSchema, severitySchema, type AssignmentFormValues, type CloseFormValues, type RejectionFormValues, type SeverityFormValues } from '../schemas';
import { reportSeverityLabels } from '../constants';
import { useLookupValues } from '@/features/settings/hooks';
import { useAssignReport, useChangeReportSeverity, useCloseReport, useEligibleOrganizations, useRejectReport } from '../hooks';
import type { Report } from '../types';

export type ReportWorkflow = 'severity' | 'assign' | 'reject' | 'close';

function mutationMessage(error: Error): string {
  if (error.message === 'INVALID_REPORT_STATE') return 'حالة البلاغ الحالية لا تسمح بهذا الإجراء.';
  if (error.message === 'ORGANIZATION_NOT_AVAILABLE') return 'الجمعية المحددة غير متاحة حاليًا.';
  return 'تعذر تنفيذ الإجراء. حاول مرة أخرى.';
}

export function ReportWorkflowDialog({ report, workflow, open, onOpenChange }: { report: Report; workflow: ReportWorkflow; open: boolean; onOpenChange: (open: boolean) => void }) {
  if (workflow === 'severity') return <SeverityDialog report={report} open={open} onOpenChange={onOpenChange} />;
  if (workflow === 'assign') return <AssignmentDialog report={report} open={open} onOpenChange={onOpenChange} />;
  if (workflow === 'reject') return <RejectDialog report={report} open={open} onOpenChange={onOpenChange} />;
  return <CloseDialog report={report} open={open} onOpenChange={onOpenChange} />;
}

function SeverityDialog({ report, open, onOpenChange }: { report:Report; open:boolean; onOpenChange:(open:boolean)=>void }) {
  const mutation = useChangeReportSeverity(report.id);
  const { register, handleSubmit, setValue, watch, formState:{ errors } } = useForm<SeverityFormValues>({ resolver:zodResolver(severitySchema), defaultValues:{ severity:report.severity, reason:'' } });
  const submit = handleSubmit((values) => mutation.mutate(values, { onSuccess:() => { toast.success('تم تحديث درجة الخطورة'); onOpenChange(false); }, onError:(error) => toast.error(mutationMessage(error)) }));
  return <Modal open={open} onOpenChange={onOpenChange} title="تغيير درجة الخطورة" description={`البلاغ ${report.id}`} footer={<><Button variant="secondary" onClick={() => onOpenChange(false)}>إلغاء</Button><Button onClick={() => void submit()} disabled={mutation.isPending}>حفظ التغيير</Button></>}>
    <form className="space-y-4" onSubmit={(event) => { event.preventDefault(); void submit(); }}><label className="block text-sm font-semibold">درجة الخطورة<Select value={watch('severity')} onValueChange={(value) => setValue('severity', value as SeverityFormValues['severity'])} options={Object.entries(reportSeverityLabels).map(([value,label]) => ({ value,label }))} /></label><label className="block text-sm font-semibold">سبب التغيير<Textarea {...register('reason')} className="mt-1" placeholder="اذكر السياق التشغيلي الذي يبرر التغيير…" />{errors.reason && <span className="mt-1 block text-xs text-critical">{errors.reason.message}</span>}</label></form>
  </Modal>;
}

function AssignmentDialog({ report, open, onOpenChange }: { report:Report; open:boolean; onOpenChange:(open:boolean)=>void }) {
  const [search, setSearch] = useState('');
  const organizations = useEligibleOrganizations(search);
  const mutation = useAssignReport(report.id);
  const { handleSubmit, setValue, watch, formState:{ errors } } = useForm<AssignmentFormValues>({ resolver:zodResolver(assignmentSchema), defaultValues:{ organizationId:report.assignedOrganization?.id ?? '' } });
  const submit = handleSubmit((values) => mutation.mutate(values.organizationId, { onSuccess:() => { toast.success('تم إسناد البلاغ إلى الجمعية'); onOpenChange(false); }, onError:(error) => toast.error(mutationMessage(error)) }));
  return <Modal open={open} onOpenChange={onOpenChange} title="إسناد البلاغ لجمعية" description="اختر جهة متاحة وقريبة قدر الإمكان من موقع البلاغ." footer={<><Button variant="secondary" onClick={() => onOpenChange(false)}>إلغاء</Button><Button onClick={() => void submit()} disabled={mutation.isPending}>تأكيد الإسناد</Button></>}>
    <form className="space-y-4" onSubmit={(event) => { event.preventDefault(); void submit(); }}><label className="block text-sm font-semibold">البحث عن جمعية<Input className="mt-1" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="اسم الجمعية…" /></label><div className="max-h-72 space-y-2 overflow-y-auto">{organizations.data?.map((organization) => <button key={organization.id} type="button" onClick={() => setValue('organizationId', organization.id, { shouldValidate:true })} className={`w-full rounded-lg border p-3 text-start ${watch('organizationId') === organization.id ? 'border-primary bg-primary/5' : 'hover:bg-muted/40'}`}><div className="flex items-start justify-between gap-3"><div><p className="font-semibold">{organization.name}</p><p className="mt-1 text-xs text-muted-foreground">{organization.governorate}{organization.distanceKm ? ` · ${organization.distanceKm} كم تقريبًا` : ''}</p></div><span className="text-xs text-muted-foreground">{organization.activeMissions} مهام نشطة</span></div><p className="mt-2 text-xs font-semibold">{organization.availability === 'AVAILABLE' ? 'متاحة للاستلام' : organization.availability === 'LIMITED' ? 'قدرة محدودة' : 'غير متاحة'}</p></button>)}</div>{errors.organizationId && <p className="text-xs text-critical">{errors.organizationId.message}</p>}</form>
  </Modal>;
}

function RejectDialog({ report, open, onOpenChange }: { report:Report; open:boolean; onOpenChange:(open:boolean)=>void }) {
  const rejectionLookup=useLookupValues('REPORT_REJECTION_REASONS');
  const rejectionReasons=(rejectionLookup.data??[]).map((item)=>item.label);
  const mutation = useRejectReport(report.id);
  const { register, handleSubmit, setValue, watch, formState:{ errors } } = useForm<RejectionFormValues>({ resolver:zodResolver(rejectionSchema), defaultValues:{ reason:'معلومات غير كافية', details:'' } });
  const submit = handleSubmit((values) => mutation.mutate(values, { onSuccess:() => { toast.success('تم رفض البلاغ'); onOpenChange(false); }, onError:(error) => toast.error(mutationMessage(error)) }));
  return <Modal open={open} onOpenChange={onOpenChange} title="رفض البلاغ" description="سبب الرفض سيبقى مسجلاً في السجل التشغيلي للمراجعين المصرح لهم." footer={<><Button variant="secondary" onClick={() => onOpenChange(false)}>إلغاء</Button><Button variant="danger" onClick={() => void submit()} disabled={mutation.isPending}>رفض البلاغ</Button></>}><form className="space-y-4" onSubmit={(event) => { event.preventDefault(); void submit(); }}><label className="block text-sm font-semibold">سبب الرفض<Select value={watch('reason')} onValueChange={(value) => setValue('reason', value as RejectionFormValues['reason'])} options={rejectionReasons.map((value) => ({ value,label:value }))} /></label>{watch('reason') === 'سبب آخر' && <label className="block text-sm font-semibold">التفاصيل<Textarea className="mt-1" {...register('details')} />{errors.details && <span className="mt-1 block text-xs text-critical">{errors.details.message}</span>}</label>}<div className="rounded-md border border-critical/20 bg-critical/5 p-3 text-sm text-critical">هذا الإجراء يوقف معالجة البلاغ. استخدمه فقط بعد التحقق من سبب الرفض.</div></form></Modal>;
}

function CloseDialog({ report, open, onOpenChange }: { report:Report; open:boolean; onOpenChange:(open:boolean)=>void }) {
  const mutation = useCloseReport(report.id);
  const { register, handleSubmit, formState:{ errors } } = useForm<CloseFormValues>({ resolver:zodResolver(closeSchema), defaultValues:{ note:'' } });
  const compatible = ['VERIFIED','ASSIGNED','IN_PROGRESS','RESCUED'].includes(report.status);
  const submit = handleSubmit((values) => mutation.mutate(values.note, { onSuccess:() => { toast.success('تم إغلاق البلاغ'); onOpenChange(false); }, onError:(error) => toast.error(mutationMessage(error)) }));
  return <Modal open={open} onOpenChange={onOpenChange} title="إغلاق البلاغ" description="أغلق البلاغ فقط عندما لا يعود هناك إجراء تشغيلي مطلوب." footer={<><Button variant="secondary" onClick={() => onOpenChange(false)}>إلغاء</Button><Button variant="danger" onClick={() => void submit()} disabled={!compatible || mutation.isPending}>تأكيد الإغلاق</Button></>}><form className="space-y-4" onSubmit={(event) => { event.preventDefault(); void submit(); }}>{!compatible && <div role="alert" className="rounded-md border border-pending/30 bg-pending/10 p-3 text-sm">الحالة الحالية غير متوافقة مع الإغلاق المباشر. أكمل المراجعة أو الإسناد أولاً.</div>}<label className="block text-sm font-semibold">ملاحظة الإغلاق <span className="font-normal text-muted-foreground">(اختيارية)</span><Textarea className="mt-1" {...register('note')} placeholder="سجل أي سياق يحتاجه الفريق لاحقًا…" />{errors.note && <span className="mt-1 block text-xs text-critical">{errors.note.message}</span>}</label></form></Modal>;
}
