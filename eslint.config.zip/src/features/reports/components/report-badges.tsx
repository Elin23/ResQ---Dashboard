import { Badge, StatusBadge } from '@/components/ui';
import type { ReportSeverity, ReportStatus } from '../types';
import { reportSeverityLabels } from '../constants';

export function ReportStatusBadge({ status }: { status: ReportStatus }) { return <StatusBadge status={`report:${status}`} />; }
export function SeverityBadge({ severity }: { severity: ReportSeverity }) {
  const tone = severity === 'CRITICAL' ? 'critical' : severity === 'HIGH' ? 'pending' : severity === 'MEDIUM' ? 'info' : 'neutral';
  return <Badge tone={tone}>{reportSeverityLabels[severity]}</Badge>;
}
