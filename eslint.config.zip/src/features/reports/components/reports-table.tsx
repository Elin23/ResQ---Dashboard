import type { ColumnDef, SortingState } from '@tanstack/react-table';
import { Clipboard, MoreHorizontal } from 'lucide-react';
import { useCallback, useMemo, useState, type ReactNode } from 'react';
import { useNavigate } from 'react-router';
import { toast } from 'sonner';
import { Avatar, DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, IconButton } from '@/components/ui';
import { DataTable, type DataTableQueryState } from '@/components/ui/data-table';
import { animalTypeLabels } from '../constants';
import type { Report, ReportFilters } from '../types';
import { formatRelativeTime } from '../utils';
import { ReportStatusBadge, SeverityBadge } from './report-badges';
import { ReportWorkflowDialog, type ReportWorkflow } from './report-workflow-dialogs';

export interface ReportActionPermissions { update:boolean; assign:boolean; reject:boolean; close:boolean; }

function RowActions({ report, permissions }: { report:Report; permissions:ReportActionPermissions }) {
  const navigate = useNavigate();
  const [workflow, setWorkflow] = useState<ReportWorkflow | null>(null);
  const copyId = async () => { await navigator.clipboard.writeText(report.id); toast.success('تم نسخ رقم البلاغ'); };
  return <><DropdownMenu><DropdownMenuTrigger asChild><IconButton label={`إجراءات ${report.id}`}><MoreHorizontal className="size-5" /></IconButton></DropdownMenuTrigger><DropdownMenuContent>
    <DropdownMenuItem onSelect={() => navigate(`/reports/${report.id}`)}>عرض التفاصيل</DropdownMenuItem>
    <DropdownMenuItem onSelect={() => void copyId()}><Clipboard className="size-4" />نسخ رقم البلاغ</DropdownMenuItem>
    {permissions.update && <DropdownMenuItem onSelect={() => setWorkflow('severity')}>تغيير الخطورة</DropdownMenuItem>}
    {permissions.assign && !['CLOSED','REJECTED','RESCUED'].includes(report.status) && <DropdownMenuItem onSelect={() => setWorkflow('assign')}>إسناد لجمعية</DropdownMenuItem>}
    {permissions.close && <DropdownMenuItem onSelect={() => setWorkflow('close')}>إغلاق البلاغ</DropdownMenuItem>}
    {permissions.reject && !['CLOSED','REJECTED','RESCUED','IN_PROGRESS'].includes(report.status) && <DropdownMenuItem className="text-critical" onSelect={() => setWorkflow('reject')}>رفض البلاغ</DropdownMenuItem>}
  </DropdownMenuContent></DropdownMenu>{workflow && <ReportWorkflowDialog report={report} workflow={workflow} open onOpenChange={(open) => { if (!open) setWorkflow(null); }} />}</>;
}

export function ReportsTable({ reports, total, pageCount, filters, loading, error, onRetry, onQueryChange, onSelectionChange, selectionActions, permissions, emptyState }: {
  reports:Report[]; total:number; pageCount:number; filters:ReportFilters; loading:boolean; error?:string; onRetry:()=>void; onQueryChange:(state:DataTableQueryState)=>void; onSelectionChange:(reports:Report[])=>void; selectionActions:(reports:Report[])=>ReactNode; permissions:ReportActionPermissions; emptyState:ReactNode;
}) {
  const navigate = useNavigate();
  const columns = useMemo<Array<ColumnDef<Report, unknown>>>(() => [
    { accessorKey:'id', header:'رقم البلاغ', cell:({row}) => <div className="font-semibold text-foreground" dir="ltr">{row.original.id}</div> },
    { id:'animal', header:'الحيوان', enableSorting:false, cell:({row}) => <div className="flex min-w-44 items-center gap-3">{row.original.media[0]?.type === 'IMAGE' ? <img src={row.original.media[0].thumbnailUrl ?? row.original.media[0].url} alt="" className="size-10 rounded-md object-cover" loading="lazy" /> : <Avatar name={animalTypeLabels[row.original.animalType]} size="sm" />}<div><p className="font-semibold">{animalTypeLabels[row.original.animalType]}</p><p className="max-w-44 truncate text-xs text-muted-foreground">{row.original.animalDescription ?? row.original.title}</p></div></div> },
    { accessorKey:'status', header:'الحالة', cell:({row}) => <ReportStatusBadge status={row.original.status} /> },
    { accessorKey:'severity', header:'الخطورة', cell:({row}) => <SeverityBadge severity={row.original.severity} /> },
    { id:'location', header:'الموقع', enableSorting:false, cell:({row}) => <div><p className="font-medium">{row.original.governorate}{row.original.city ? ` — ${row.original.city}` : ''}</p></div> },
    { id:'reporter', header:'المبلّغ', enableSorting:false, cell:({row}) => <div><p className="font-medium">{row.original.reporter.name}</p><p className="text-xs text-muted-foreground">{row.original.reporter.isGuest ? 'ضيف' : 'عضو'}</p></div> },
    { id:'organization', header:'الجمعية', enableSorting:false, cell:({row}) => row.original.assignedOrganization ? <span>{row.original.assignedOrganization.name}</span> : <span className="text-muted-foreground">غير مسند</span> },
    { accessorKey:'createdAt', header:'وقت البلاغ', cell:({row}) => <span className="whitespace-nowrap text-muted-foreground">{formatRelativeTime(row.original.createdAt)}</span> },
    { accessorKey:'updatedAt', header:'آخر تحديث', cell:({row}) => <span className="whitespace-nowrap text-muted-foreground">{formatRelativeTime(row.original.updatedAt)}</span> },
  ], []);
  const sorting: SortingState = filters.sortBy ? [{ id:filters.sortBy, desc:filters.sortDirection !== 'asc' }] : [];
  const getReportRowId = useCallback((report: Report) => report.id, []);
  return <DataTable
    data={reports}
    columns={columns}
    getRowId={getReportRowId}
    loading={loading}
    error={error}
    onRetry={onRetry}
    enableSearch={false}
    enableRowSelection
    manualPagination
    manualFiltering
    manualSorting
    pageCount={pageCount}
    totalCount={total}
    state={{ pageIndex:filters.page - 1, pageSize:filters.pageSize, search:'', sorting }}
    onStateChange={onQueryChange}
    onRowClick={(report) => navigate(`/reports/${report.id}`)}
    rowAriaLabel={(report) => `فتح تفاصيل البلاغ ${report.id}`}
    onSelectionChange={onSelectionChange}
    selectionActions={selectionActions}
    rowActions={(report) => <RowActions report={report} permissions={permissions} />}
    emptyState={emptyState}
  />;
}
