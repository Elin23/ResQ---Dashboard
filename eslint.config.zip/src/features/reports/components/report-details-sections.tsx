import type { ReactNode } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { CheckCircle2, Clipboard, Mail, Phone, UserRound } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { Link } from 'react-router';
import { toast } from 'sonner';
import { Badge, Button, Card, SectionHeader, Textarea } from '@/components/ui';
import { MediaGallery } from '@/components/ui/media-gallery';
import { LocationPreview } from '@/components/ui/location-preview';
import { OperationalTimeline } from '@/components/ui/operational-timeline';
import { PermissionGuard } from '@/features/auth/rbac';
import { animalTypeLabels } from '../constants';
import { useAddReportNote } from '../hooks';
import { noteSchema, type NoteFormValues } from '../schemas';
import type { ReportDetails } from '../types';
import { formatReportDate, formatRelativeTime } from '../utils';
import { ReportStatusBadge, SeverityBadge } from './report-badges';

export function ReportOverview({ details }: { details:ReportDetails }) {
  const { report } = details;
  return <Card><SectionHeader title="نظرة عامة على الحالة" description="المعلومات الأساسية التي يحتاجها فريق العمليات لاتخاذ القرار." /><dl className="mt-5 grid gap-4 sm:grid-cols-2"><Info label="نوع الحيوان" value={animalTypeLabels[report.animalType]} /><Info label="الوصف" value={report.animalDescription ?? 'غير محدد'} /><Info label="الحالة" value={<ReportStatusBadge status={report.status} />} /><Info label="الخطورة" value={<SeverityBadge severity={report.severity} />} /><Info label="وقت الإرسال" value={formatReportDate(report.createdAt)} /><Info label="الجمعية الحالية" value={report.assignedOrganization?.name ?? 'غير مسند'} /></dl><div className="mt-5 rounded-lg bg-muted/50 p-4"><p className="text-sm font-semibold">وصف البلاغ</p><p className="mt-2 text-sm leading-7 text-muted-foreground">{report.description}</p></div>{report.rejectionReason && <div className="mt-4 rounded-lg border border-critical/20 bg-critical/5 p-4"><p className="text-sm font-semibold text-critical">سبب الرفض</p><p className="mt-1 text-sm">{report.rejectionReason}</p></div>}</Card>;
}
function Info({ label, value }: { label:string; value:ReactNode }) { return <div><dt className="text-xs text-muted-foreground">{label}</dt><dd className="mt-1 text-sm font-semibold">{value}</dd></div>; }

export function ReportMediaSection({ details }: { details:ReportDetails }) { return <Card><SectionHeader title="الوسائط المرفقة" description={`${details.report.media.length} ملفات مرتبطة بالبلاغ`} /><div className="mt-5"><MediaGallery items={details.report.media.map((item,index) => ({ ...item, alt:`صورة البلاغ ${details.report.id} — ${index + 1}` }))} /></div></Card>; }

export function ReporterCard({ details }: { details:ReportDetails }) {
  const reporter=details.report.reporter;
  const copyPhone = async () => { if (!reporter.phone) return; await navigator.clipboard.writeText(reporter.phone); toast.success('تم نسخ رقم الهاتف'); };
  return <Card><SectionHeader title="بيانات المبلّغ" /><div className="mt-4 flex items-center gap-3"><span className="rounded-full bg-muted p-3"><UserRound className="size-5" /></span><div><p className="font-bold">{reporter.name}</p><Badge tone={reporter.isGuest ? 'neutral' : 'info'}>{reporter.isGuest ? 'مبلّغ ضيف' : 'عضو مسجل'}</Badge></div></div><div className="mt-4 space-y-3 text-sm">{reporter.phone && <div className="flex items-center justify-between gap-3"><span className="flex items-center gap-2 text-muted-foreground"><Phone className="size-4" />رقم الهاتف</span><span dir="ltr" className="font-medium">{reporter.phone}</span></div>}{reporter.email && <div className="flex items-center justify-between gap-3"><span className="flex items-center gap-2 text-muted-foreground"><Mail className="size-4" />البريد الإلكتروني</span><span dir="ltr" className="truncate font-medium">{reporter.email}</span></div>}</div><div className="mt-5 flex flex-wrap gap-2">{reporter.phone && <Button size="sm" variant="secondary" onClick={() => void copyPhone()}><Clipboard className="size-4" />نسخ رقم الهاتف</Button>}{!reporter.isGuest && <Link to={`/users/${reporter.id}`}><Button size="sm" variant="ghost">فتح ملف المستخدم</Button></Link>}</div></Card>;
}

export function ReportLocationSection({ details }: { details:ReportDetails }) { const report=details.report; return <Card><SectionHeader title="الموقع" description={`${report.governorate}${report.city ? ` — ${report.city}` : ''}`} /><div className="mt-4"><LocationPreview title={`${report.governorate}${report.city ? ` — ${report.city}` : ''}`} address={report.address} latitude={report.latitude} longitude={report.longitude} mapHref={`/map?entityType=REPORT&entityId=${report.id}`} /></div></Card>; }

export function ReportTimelineSection({ details }: { details:ReportDetails }) { return <Card><SectionHeader title="السجل التشغيلي" description="تسلسل الإجراءات والتغييرات على هذا البلاغ." /><div className="mt-5"><OperationalTimeline items={details.timeline.map((event) => ({ id:event.id,title:event.action,actor:event.actor,timestampLabel:formatReportDate(event.timestamp),details:event.details,tone:event.tone }))} /></div></Card>; }

export function InternalNotesPanel({ details }: { details:ReportDetails }) {
  const mutation=useAddReportNote(details.report.id);
  const { register,handleSubmit,reset,formState:{errors} }=useForm<NoteFormValues>({ resolver:zodResolver(noteSchema), defaultValues:{note:''} });
  const submit=handleSubmit((values)=>mutation.mutate(values.note,{onSuccess:()=>{toast.success('تمت إضافة الملاحظة الداخلية');reset();},onError:()=>toast.error('تعذر إضافة الملاحظة')}));
  return <Card><SectionHeader title="ملاحظات داخلية" description="مرئية لفريق الإدارة فقط ولا تظهر للمبلّغ." /><div className="mt-4 rounded-md border border-info/20 bg-info/5 p-3 text-xs text-muted-foreground"><CheckCircle2 className="me-1 inline size-4 text-info" />هذه المساحة مخصصة للسياق الداخلي والتسليم بين فرق العمليات.</div><PermissionGuard permission="reports:update"><form className="mt-4" onSubmit={(event)=>{event.preventDefault();void submit();}}><label className="sr-only" htmlFor="internal-note">إضافة ملاحظة داخلية</label><Textarea id="internal-note" {...register('note')} placeholder="أضف ملاحظة تشغيلية…" />{errors.note&&<p className="mt-1 text-xs text-critical">{errors.note.message}</p>}<Button size="sm" className="mt-2" type="submit" disabled={mutation.isPending}>إضافة الملاحظة</Button></form></PermissionGuard><div className="mt-5 space-y-3">{details.notes.length===0?<p className="text-sm text-muted-foreground">لا توجد ملاحظات داخلية بعد.</p>:details.notes.map((note)=><div key={note.id} className="rounded-lg border p-3"><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-semibold">{note.adminName}</p><p className="text-xs text-muted-foreground">{note.adminRole}</p></div><span className="text-xs text-muted-foreground">{formatRelativeTime(note.createdAt)}</span></div><p className="mt-2 text-sm leading-6">{note.note}</p></div>)}</div></Card>;
}
