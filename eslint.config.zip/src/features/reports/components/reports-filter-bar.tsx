import { RotateCcw, SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';
import { Button, FilterBar, Input, DebouncedSearchInput, Select } from '@/components/ui';
import type { AnimalType, ReportFilters, ReportSeverity, ReportStatus } from '../types';
import { animalTypeLabels, governorates, reportSeverityLabels, reportStatusLabels } from '../constants';

const statusOptions = [{ value:'ALL', label:'كل الحالات' }, ...Object.entries(reportStatusLabels).map(([value,label]) => ({ value, label }))];
const severityOptions = [{ value:'ALL', label:'كل درجات الخطورة' }, ...Object.entries(reportSeverityLabels).map(([value,label]) => ({ value, label }))];
const animalOptions = [{ value:'ALL', label:'كل الحيوانات' }, ...Object.entries(animalTypeLabels).map(([value,label]) => ({ value, label }))];
const governorateOptions = [{ value:'ALL', label:'كل المحافظات' }, ...governorates.map((value) => ({ value, label:value }))];

export function ReportsFilterBar({ filters, organizations, onChange, onClear, active }: { filters: ReportFilters; organizations: Array<{ id:string; name:string }>; onChange: (patch: Partial<ReportFilters>) => void; onClear: () => void; active: boolean }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  return <div className="space-y-2"><Button className="md:hidden" variant="secondary" size="sm" onClick={() => setMobileOpen((current) => !current)} aria-expanded={mobileOpen}><SlidersHorizontal className="size-4" />{mobileOpen ? 'إخفاء الفلاتر' : 'إظهار الفلاتر'}</Button><div className={mobileOpen ? 'block' : 'hidden md:block'}><FilterBar>
    <label className="min-w-56 flex-1"><span className="sr-only">البحث في البلاغات</span><DebouncedSearchInput value={filters.search} onValueChange={(value) => onChange({ search:value, page:1 })} placeholder="رقم البلاغ، الحيوان، المبلّغ، الموقع…" /></label>
    <label><span className="sr-only">الحالة</span><Select value={filters.status ?? 'ALL'} onValueChange={(value) => onChange({ status:value === 'ALL' ? undefined : value as ReportStatus, page:1 })} options={statusOptions} /></label>
    <label><span className="sr-only">الخطورة</span><Select value={filters.severity ?? 'ALL'} onValueChange={(value) => onChange({ severity:value === 'ALL' ? undefined : value as ReportSeverity, page:1 })} options={severityOptions} /></label>
    <label><span className="sr-only">نوع الحيوان</span><Select value={filters.animalType ?? 'ALL'} onValueChange={(value) => onChange({ animalType:value === 'ALL' ? undefined : value as AnimalType, page:1 })} options={animalOptions} /></label>
    <label><span className="sr-only">المحافظة</span><Select value={filters.governorate ?? 'ALL'} onValueChange={(value) => onChange({ governorate:value === 'ALL' ? undefined : value, page:1 })} options={governorateOptions} /></label>
    <label><span className="sr-only">الجمعية المسندة</span><Select value={filters.organizationId ?? 'ALL'} onValueChange={(value) => onChange({ organizationId:value === 'ALL' ? undefined : value, page:1 })} options={[{value:'ALL',label:'كل الجمعيات'},...organizations.map((organization) => ({ value:organization.id, label:organization.name }))]} /></label>
    <label className="flex items-center gap-2 text-xs text-muted-foreground"><span>من</span><Input type="date" value={filters.dateFrom ?? ''} onChange={(event) => onChange({ dateFrom:event.target.value || undefined, page:1 })} aria-label="من تاريخ" className="w-auto" /></label>
    <label className="flex items-center gap-2 text-xs text-muted-foreground"><span>إلى</span><Input type="date" value={filters.dateTo ?? ''} onChange={(event) => onChange({ dateTo:event.target.value || undefined, page:1 })} aria-label="إلى تاريخ" className="w-auto" /></label>
    {active && <Button variant="ghost" size="sm" onClick={onClear}><RotateCcw className="size-4" />مسح الفلاتر</Button>}
  </FilterBar></div></div>;
}
