import { commitSearchParams } from '@/lib/search-params';
import { Download, SlidersHorizontal } from 'lucide-react';
import { useCallback, useState } from 'react';
import { useSearchParams } from 'react-router';
import { toast } from 'sonner';
import { Button, EmptyState, ErrorState, PageHeader, Select } from '@/components/ui';
import type { DataTableQueryState } from '@/components/ui/data-table';
import { usePermission } from '@/features/auth/rbac';
import { animalTypes, reportSeverities, reportStatuses, type Report, type ReportFilters, type ReportSeverity } from '../types';
import { hasActiveFilters } from '../utils';
import { useBulkChangeReportSeverity, useEligibleOrganizations, useReports, useReportsSummary } from '../hooks';
import { ReportsFilterBar } from '../components/reports-filter-bar';
import { ReportsSummaryCards } from '../components/reports-summary';
import { ReportsTable } from '../components/reports-table';
import { Modal, Textarea } from '@/components/ui';
import { reportSeverityLabels } from '../constants';

const valid = <T extends string>(value: string | null, options: readonly T[]): T | undefined => value && options.includes(value as T) ? value as T : undefined;
function filtersFromParams(params: URLSearchParams): ReportFilters {
  const today = new Date().toISOString().slice(0,10);
  const todayRange = ['today','TODAY'].includes(params.get('range') ?? '');
  return { search:params.get('q') ?? '', status:valid(params.get('status'), reportStatuses), severity:valid(params.get('severity'), reportSeverities), animalType:valid(params.get('animal'), animalTypes), governorate:params.get('governorate') ?? undefined, organizationId:params.get('organization') ?? undefined, userId:params.get('userId') ?? undefined, dateFrom:params.get('from') ?? (todayRange ? today : undefined), dateTo:params.get('to') ?? (todayRange ? today : undefined), sla:params.get('sla') === 'BREACHED' ? 'BREACHED' : undefined, page:Math.max(1, Number(params.get('page') ?? 1) || 1), pageSize:[10,20,50].includes(Number(params.get('pageSize'))) ? Number(params.get('pageSize')) : 10, sortBy:valid(params.get('sort'), ['createdAt','updatedAt','severity','status'] as const), sortDirection:params.get('direction') === 'asc' ? 'asc' : 'desc' };
}
function paramsFromFilters(filters: ReportFilters): URLSearchParams {
  const params = new URLSearchParams();
  const entries: Array<[string, string | number | undefined]> = [['q',filters.search || undefined],['status',filters.status],['severity',filters.severity],['animal',filters.animalType],['governorate',filters.governorate],['organization',filters.organizationId],['userId',filters.userId],['from',filters.dateFrom],['to',filters.dateTo],['sla',filters.sla],['page',filters.page > 1 ? filters.page : undefined],['pageSize',filters.pageSize !== 10 ? filters.pageSize : undefined],['sort',filters.sortBy],['direction',filters.sortBy && filters.sortDirection ? filters.sortDirection : undefined]];
  for (const [key,value] of entries) if (value !== undefined) params.set(key,String(value));
  return params;
}
function downloadSelected(reports: Report[]) {
  const rows = [['id','status','severity','animal','governorate','city','organization'], ...reports.map((report) => [report.id,report.status,report.severity,report.animalType,report.governorate,report.city ?? '',report.assignedOrganization?.name ?? ''])];
  const csv = `\uFEFF${rows.map((row) => row.map((cell) => `"${cell.replaceAll('"','""')}"`).join(',')).join('\n')}`;
  const url = URL.createObjectURL(new Blob([csv], { type:'text/csv;charset=utf-8' }));
  const anchor = document.createElement('a'); anchor.href=url; anchor.download='resq-selected-reports.csv'; anchor.click(); URL.revokeObjectURL(url);
  toast.success('تم تصدير البلاغات المحددة');
}

export function ReportsPage() {
  const [params, setParams] = useSearchParams();
  const filters = filtersFromParams(params);
  const reportsQuery = useReports(filters);
  const summaryQuery = useReportsSummary();
  const organizationsQuery = useEligibleOrganizations('');
  const [selected, setSelected] = useState<Report[]>([]);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkSeverity, setBulkSeverity] = useState<ReportSeverity>('HIGH');
  const [bulkReason, setBulkReason] = useState('مراجعة جماعية للأولوية التشغيلية');
  const bulkMutation = useBulkChangeReportSeverity();
  const canUpdate = usePermission('reports:update');
  const canAssign = usePermission('reports:assign');
  const canReject = usePermission('reports:reject');
  const canClose = usePermission('reports:close');

  const updateFilters = useCallback((patch: Partial<ReportFilters>) => commitSearchParams(params,paramsFromFilters({ ...filters, ...patch }),setParams), [filters, params, setParams]);
  const clearFilters = () => setParams(new URLSearchParams());
  const onQueryChange = useCallback((state: DataTableQueryState) => {
    const sort = state.sorting[0];
    const nextSort = sort && ['createdAt','updatedAt','severity','status'].includes(sort.id) ? sort.id as ReportFilters['sortBy'] : undefined;
    if (state.pageIndex + 1 !== filters.page || state.pageSize !== filters.pageSize || nextSort !== filters.sortBy || (nextSort && (sort?.desc ? 'desc' : 'asc')) !== filters.sortDirection) updateFilters({ page:state.pageIndex + 1, pageSize:state.pageSize, sortBy:nextSort, sortDirection:nextSort ? sort?.desc ? 'desc' : 'asc' : undefined });
  }, [filters.page, filters.pageSize, filters.sortBy, filters.sortDirection, updateFilters]);
  const onSelectionChange = useCallback((rows: Report[]) => setSelected(rows), []);

  if (reportsQuery.isError && !reportsQuery.data) return <ErrorState title="تعذر تحميل البلاغات" description={reportsQuery.error.message} onRetry={() => void reportsQuery.refetch()} />;
  const data = reportsQuery.data;
  const active = hasActiveFilters(filters);
  const empty = <EmptyState title={active ? 'لا توجد بلاغات تطابق عوامل التصفية الحالية.' : 'لا توجد بلاغات مسجلة حتى الآن.'} description={active ? 'جرّب تعديل الفلاتر أو مسحها للوصول إلى نتائج أخرى.' : 'ستظهر البلاغات الواردة هنا عند تسجيلها.'} action={active ? <Button variant="secondary" onClick={clearFilters}>مسح الفلاتر</Button> : undefined} />;

  return <div className="space-y-6">
    <PageHeader title="إدارة البلاغات" description="مراجعة البلاغات الواردة ومتابعة حالاتها وإسنادها لفرق الإنقاذ." breadcrumbs={[{label:'الرئيسية',href:'/dashboard'},{label:'البلاغات'}]} />
    <ReportsSummaryCards summary={summaryQuery.data} loading={summaryQuery.isLoading} onFilter={updateFilters} />
    <ReportsFilterBar filters={filters} organizations={organizationsQuery.data ?? []} onChange={updateFilters} onClear={clearFilters} active={active} />
    <ReportsTable reports={data?.items ?? []} total={data?.total ?? 0} pageCount={data?.pageCount ?? 1} filters={filters} loading={reportsQuery.isLoading || reportsQuery.isFetching && !data} error={reportsQuery.isError ? reportsQuery.error.message : undefined} onRetry={() => void reportsQuery.refetch()} onQueryChange={onQueryChange} onSelectionChange={onSelectionChange} permissions={{update:canUpdate,assign:canAssign,reject:canReject,close:canClose}} emptyState={empty} selectionActions={(rows) => <><Button size="sm" variant="secondary" onClick={() => downloadSelected(rows)}><Download className="size-4" />تصدير المحدد</Button>{canUpdate && <Button size="sm" variant="secondary" onClick={() => setBulkOpen(true)}><SlidersHorizontal className="size-4" />تغيير الأولوية</Button>}</>} />
    <Modal open={bulkOpen} onOpenChange={setBulkOpen} title="تغيير أولوية البلاغات المحددة" description={`سيتم تطبيق التغيير على ${selected.length} بلاغات فقط.`} footer={<><Button variant="secondary" onClick={() => setBulkOpen(false)}>إلغاء</Button><Button disabled={bulkMutation.isPending || selected.length === 0 || bulkReason.trim().length < 3} onClick={() => bulkMutation.mutate({ reportIds:selected.map((report) => report.id), severity:bulkSeverity, reason:bulkReason }, { onSuccess:() => { toast.success('تم تحديث أولوية البلاغات المحددة'); setBulkOpen(false); }, onError:() => toast.error('تعذر تحديث الأولوية') })}>تطبيق</Button></>}><div className="space-y-4"><label className="block text-sm font-semibold">الأولوية<Select value={bulkSeverity} onValueChange={(value) => setBulkSeverity(value as ReportSeverity)} options={Object.entries(reportSeverityLabels).map(([value,label]) => ({value,label}))} /></label><label className="block text-sm font-semibold">سبب التغيير<Textarea className="mt-1" value={bulkReason} onChange={(event) => setBulkReason(event.target.value)} /></label></div></Modal>
  </div>;
}
