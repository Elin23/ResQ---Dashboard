import { ArrowRight } from 'lucide-react';
import { Link, useParams } from 'react-router';
import { Badge, Button, Card, ErrorState, PageHeader, Skeleton } from '@/components/ui';
import { useReport } from '../hooks';
import { formatReportDate } from '../utils';
import { ReportStatusBadge, SeverityBadge } from '../components/report-badges';
import { ReportActions } from '../components/report-actions';
import { InternalNotesPanel, ReportLocationSection, ReportMediaSection, ReporterCard, ReportOverview, ReportTimelineSection } from '../components/report-details-sections';
import { ReportMissionLinkCard } from '@/features/rescue-missions/components/report-mission-link-card';
import { EntityDonationSupportCard } from '@/features/donations/components/entity-donation-support-card';
import { ReportResultAnimalCard } from '@/features/animals/components/animal-result-link-card';

function DetailsSkeleton(){return <div className="space-y-6"><Skeleton className="h-28"/><div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]"><div className="space-y-6"><Skeleton className="h-80"/><Skeleton className="h-96"/><Skeleton className="h-80"/></div><div className="space-y-6"><Skeleton className="h-64"/><Skeleton className="h-80"/></div></div></div>}
export function ReportDetailsPage(){
  const {reportId=''}=useParams();
  const query=useReport(reportId);
  if(query.isLoading)return <DetailsSkeleton/>;
  if(query.isError)return <ErrorState title="تعذر تحميل البلاغ" description={query.error.message} onRetry={()=>void query.refetch()}/>;
  if(!query.data)return <div className="space-y-5"><Link to="/reports"><Button variant="ghost"><ArrowRight className="size-4"/>العودة إلى البلاغات</Button></Link><ErrorState title="البلاغ غير موجود" description="تعذر العثور على رقم البلاغ المطلوب. تحقق من الرابط أو ارجع إلى قائمة البلاغات."/></div>;
  const details=query.data; const report=details.report;
  return <div className="space-y-6"><PageHeader title={report.title} description={`${report.id} · أُرسل ${formatReportDate(report.createdAt)} · آخر تحديث ${formatReportDate(report.updatedAt)}`} breadcrumbs={[{label:'الرئيسية',href:'/dashboard'},{label:'البلاغات',href:'/reports'},{label:report.id}]} actions={<ReportActions report={report}/>}/><div className="flex flex-wrap items-center gap-2"><ReportStatusBadge status={report.status}/><SeverityBadge severity={report.severity}/>{report.assignedOrganization&&<Badge tone="info">{report.assignedOrganization.name}</Badge>}</div><div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]"><main className="space-y-6"><ReportOverview details={details}/><ReportMediaSection details={details}/><ReportLocationSection details={details}/><ReportTimelineSection details={details}/></main><aside className="space-y-6 xl:sticky xl:top-24"><ReportResultAnimalCard reportId={report.id}/><ReportMissionLinkCard reportId={report.id}/><ReporterCard details={details}/><EntityDonationSupportCard title="الدعم المالي للحالة" reportId={report.id}/><InternalNotesPanel details={details}/><Card><p className="text-sm font-semibold">رقم البلاغ</p><p dir="ltr" className="mt-2 font-mono text-lg font-bold">{report.id}</p><p className="mt-1 text-xs text-muted-foreground">استخدم هذا الرقم عند التنسيق مع الفرق والجمعيات.</p></Card></aside></div></div>;
}
