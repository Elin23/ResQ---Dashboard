import { format } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { BellPlus, Building2, HeartHandshake, RefreshCw, ShieldAlert } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router';
import { Button, Card, ErrorState, PageHeader, Select } from '@/components/ui';
import { PermissionGuard } from '@/features/auth/rbac';
import { useSession } from '@/features/auth/session';
import {
  ActiveMissions,
  AttentionQueue,
  CriticalReports,
  DashboardMetrics,
  DashboardSectionSkeleton,
  GeographicPreview,
  OperationalSummaryChart,
  RecentActivityList,
  WeeklyReportsChart,
} from './components/dashboard-sections';
import { useAttentionQueue, useDashboardSummary, useGeographicSnapshot, useRecentActivity } from './hooks';
import type { DashboardRange } from './types';

const rangeOptions = [
  { value: 'TODAY', label: 'اليوم' },
  { value: '7D', label: 'آخر 7 أيام' },
  { value: '30D', label: 'آخر 30 يومًا' },
];

function greeting(name: string): string {
  const hour = new Date().getHours();
  const firstName = name.trim().split(/\s+/)[0] ?? name;
  if (hour < 12) return `صباح الخير، ${firstName}`;
  if (hour < 18) return `مساء الخير، ${firstName}`;
  return `مساء الخير، ${firstName}`;
}

function queryErrorMessage(error: Error | null): string | undefined {
  return error?.message || undefined;
}

export function DashboardPage() {
  const { session } = useSession();
  const [range, setRange] = useState<DashboardRange>('TODAY');
  const summary = useDashboardSummary(range);
  const attention = useAttentionQueue();
  const activity = useRecentActivity();
  const geography = useGeographicSnapshot();
  const refreshing = summary.isFetching || attention.isFetching || activity.isFetching || geography.isFetching;

  const refreshAll = () => {
    void Promise.all([summary.refetch(), attention.refetch(), activity.refetch(), geography.refetch()]);
  };

  const updatedAt = summary.data?.generatedAt ? format(new Date(summary.data.generatedAt), 'h:mm a', { locale: arSA }) : '—';

  return (
    <div className="space-y-7">
      <PageHeader
        title={greeting(session?.name ?? 'أحمد')}
        description="إليك ملخص عمليات ResQ اليوم وما يحتاج إلى تدخل فريقك."
        breadcrumbs={[{ label: 'الرئيسية' }]}
        actions={<div className="flex flex-wrap items-center gap-2"><Select value={range} onValueChange={(value) => setRange(value as DashboardRange)} options={rangeOptions} /><Button variant="secondary" onClick={refreshAll} disabled={refreshing}><RefreshCw className={`size-4 ${refreshing ? 'animate-spin' : ''}`} />تحديث</Button></div>}
      />

      <div className="flex flex-col justify-between gap-2 rounded-xl border border-border/80 bg-surface/90 px-4 py-3 text-sm shadow-sm sm:flex-row sm:items-center">
        <span className="font-medium">{format(new Date(), 'EEEE، d MMMM yyyy', { locale: arSA })}</span>
        <span className="text-muted-foreground">آخر تحديث: <span className="font-semibold text-foreground">{updatedAt}</span></span>
      </div>

      {summary.isLoading ? <DashboardSectionSkeleton /> : summary.isError ? <ErrorState description={summary.error.message} onRetry={() => void summary.refetch()} /> : summary.data ? <>
        <DashboardMetrics metrics={summary.data.metrics} />

        <div className="grid grid-cols-1 gap-5 xl:grid-cols-12">
          <div className="xl:col-span-8"><AttentionQueue items={attention.data} loading={attention.isLoading} error={queryErrorMessage(attention.error)} onRetry={() => void attention.refetch()} /></div>
          <Card className="xl:col-span-4">
            <h2 className="text-lg font-extrabold tracking-tight text-brown">إجراءات سريعة</h2>
            <p className="mt-1 text-sm text-muted-foreground">اختصارات تظهر وفق صلاحيات الدور الحالي.</p>
            <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-1">
              <PermissionGuard permission="reports:view"><Link to="/reports?severity=CRITICAL" className="resq-card-interactive flex items-center gap-3 rounded-xl border border-border/80 bg-surface-subtle p-3 hover:border-primary/25 hover:bg-surface"><span className="rounded-lg bg-critical/10 p-2 text-critical"><ShieldAlert className="size-5" /></span><div><p className="font-semibold">مراجعة البلاغات الحرجة</p><p className="text-xs text-muted-foreground">ابدأ بالأعلى أولوية</p></div></Link></PermissionGuard>
              <PermissionGuard permission="reports:assign"><Link to="/reports?status=WAITING_FOR_ORGANIZATION" className="resq-card-interactive flex items-center gap-3 rounded-xl border border-border/80 bg-surface-subtle p-3 hover:border-primary/25 hover:bg-surface"><span className="rounded-lg bg-info/10 p-2 text-info"><HeartHandshake className="size-5" /></span><div><p className="font-semibold">إسناد بلاغ</p><p className="text-xs text-muted-foreground">ربط حالة بجهة إنقاذ</p></div></Link></PermissionGuard>
              <PermissionGuard permission="organizations:review"><Link to="/organizations?status=PENDING_VERIFICATION" className="resq-card-interactive flex items-center gap-3 rounded-xl border border-border/80 bg-surface-subtle p-3 hover:border-primary/25 hover:bg-surface"><span className="rounded-lg bg-pending/15 p-2 text-brown"><Building2 className="size-5" /></span><div><p className="font-semibold">مراجعة اعتماد الجمعيات</p><p className="text-xs text-muted-foreground">تحقق من الطلبات الجديدة</p></div></Link></PermissionGuard>
              <PermissionGuard permission="notifications.create"><Link to="/notifications/new" className="resq-card-interactive flex items-center gap-3 rounded-xl border border-border/80 bg-surface-subtle p-3 hover:border-primary/25 hover:bg-surface"><span className="rounded-lg bg-primary/10 p-2 text-primary"><BellPlus className="size-5" /></span><div><p className="font-semibold">إرسال إشعار</p><p className="text-xs text-muted-foreground">التواصل مع مستخدمي المنصة</p></div></Link></PermissionGuard>
            </div>
          </Card>
        </div>

        <ActiveMissions missions={summary.data.activeMissions} />
        <CriticalReports reports={summary.data.criticalReports} />

        <div className="grid gap-5 2xl:grid-cols-2">
          <WeeklyReportsChart data={summary.data.weeklyReports} />
          <OperationalSummaryChart data={summary.data.operationalSummary} />
        </div>

        <div className="grid gap-5 xl:grid-cols-12">
          <div className="xl:col-span-5"><RecentActivityList items={activity.data} loading={activity.isLoading} error={queryErrorMessage(activity.error)} onRetry={() => void activity.refetch()} /></div>
          <div className="xl:col-span-7"><GeographicPreview snapshot={geography.data} loading={geography.isLoading} error={queryErrorMessage(geography.error)} onRetry={() => void geography.refetch()} /></div>
        </div>
      </> : null}
    </div>
  );
}
