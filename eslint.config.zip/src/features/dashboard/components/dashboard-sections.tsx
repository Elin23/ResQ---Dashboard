import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Building2,
  CheckCircle2,
  CircleAlert,
  CircleDollarSign,
  Clock3,
  HeartHandshake,
  MapPin,
  MegaphoneOff,
  PawPrint,
  ShieldAlert,
  Stethoscope,
  UserCheck,
  UsersRound,
} from 'lucide-react';
import { memo } from 'react';
import { Link } from 'react-router';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Badge, Card, EmptyState, ErrorState, SectionHeader, Skeleton, StatusBadge } from '@/components/ui';
import { cn } from '@/lib/cn';
import { usePermission } from '@/features/auth/rbac';
import type {
  ActiveMission,
  AttentionItem,
  CriticalReport,
  DashboardMetric,
  GeographicSnapshot,
  OperationalSummaryPoint,
  RecentActivity,
  WeeklyReportPoint,
} from '../types';

const chartPrimary = 'hsl(var(--color-primary))';
const chartInfo = 'hsl(var(--color-info))';
const chartSuccess = 'hsl(var(--color-success))';
const chartGrid = 'hsl(var(--color-border))';
const chartText = 'hsl(var(--color-muted-foreground))';

const metricIcons = {
  reports: ShieldAlert,
  critical: CircleAlert,
  waiting: Clock3,
  missions: HeartHandshake,
  animals: PawPrint,
  adoptions: UserCheck,
  organizations: Building2,
  clinics: Stethoscope,
  donations: CircleDollarSign,
};

const toneClasses = {
  neutral: 'bg-muted text-muted-foreground',
  success: 'bg-success/10 text-success',
  pending: 'bg-pending/15 text-brown',
  critical: 'bg-critical/10 text-critical',
  info: 'bg-info/10 text-info',
};

export function DashboardMetrics({ metrics }: { metrics: DashboardMetric[] }) {
  if (metrics.length === 0) return <EmptyState title="لا توجد مؤشرات" description="لم تصل مؤشرات تشغيلية للفترة المختارة." />;
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-8">
      {metrics.map((metric) => {
        const Icon = metricIcons[metric.iconKey];
        return (
          <Link key={metric.id} to={metric.target} className="group rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2">
            <Card className="resq-card-interactive relative h-full overflow-hidden group-hover:border-primary/25">
              <div className="pointer-events-none absolute inset-x-6 top-0 h-px bg-gradient-to-l from-transparent via-primary/30 to-transparent" /><div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-muted-foreground">{metric.label}</p>
                  <p className="mt-2 text-3xl font-extrabold tracking-tight text-brown">{typeof metric.value==='number'?metric.value.toLocaleString('ar-SA-u-nu-latn'):metric.value}</p>
                  <p className="mt-2 text-xs leading-5 text-muted-foreground">{metric.context}</p>
                </div>
                <span className={cn('rounded-xl border border-current/10 p-2.5', toneClasses[metric.tone])}><Icon className="size-5" aria-hidden="true" /></span>
              </div>
              <div className="mt-4 flex items-center gap-1 text-xs font-bold text-primary opacity-70 transition-opacity group-hover:opacity-100">
                فتح التفاصيل <ArrowLeft className="size-3.5" aria-hidden="true" />
              </div>
            </Card>
          </Link>
        );
      })}
    </div>
  );
}

function waitingLabel(minutes: number): string {
  if (minutes < 60) return `منذ ${minutes.toLocaleString('ar-SA-u-nu-latn')} دقيقة`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `منذ ${hours.toLocaleString('ar-SA-u-nu-latn')} ساعة`;
  return `منذ ${Math.floor(hours / 24).toLocaleString('ar-SA-u-nu-latn')} يوم`;
}

export function AttentionQueue({ items, loading, error, onRetry }: { items?: AttentionItem[]; loading: boolean; error?: string; onRetry: () => void }) {
  if (error) return <ErrorState title="تعذر تحميل قائمة الإجراءات" description={error} onRetry={onRetry} />;
  return (
    <Card className="border-critical/15 bg-gradient-to-b from-critical/5 via-surface to-surface">
      <SectionHeader title="يحتاج إلى إجراء" description="العناصر التي تستحق انتباه فريق العمليات الآن" />
      <div className="mt-4 space-y-2">
        {loading ? Array.from({ length: 4 }, (_, index) => <Skeleton key={index} className="h-20 w-full" />) : items && items.length > 0 ? items.map((item) => (
          <Link key={item.id} to={item.target} className="resq-card-interactive flex flex-col gap-3 rounded-xl border border-border/80 bg-surface/95 p-4 hover:border-primary/25 sm:flex-row sm:items-center">
            <span className={cn('flex size-10 shrink-0 items-center justify-center rounded-lg', toneClasses[item.severity])}>
              {item.severity === 'critical' ? <AlertTriangle className="size-5" /> : <Clock3 className="size-5" />}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2"><p className="font-bold">{item.title}</p><Badge tone={item.severity}>{waitingLabel(item.waitingMinutes)}</Badge></div>
              <p className="mt-1 text-sm text-muted-foreground">{item.detail}</p>
            </div>
            <span className="inline-flex items-center gap-1 text-sm font-semibold text-primary">{item.actionLabel}<ArrowLeft className="size-4" /></span>
          </Link>
        )) : <EmptyState title="لا توجد إجراءات عاجلة" description="لا توجد عناصر معلقة تتطلب تدخلاً الآن." />}
      </div>
    </Card>
  );
}

const priorityMeta = {
  CRITICAL: { label: 'حرجة', tone: 'critical' as const },
  HIGH: { label: 'عالية', tone: 'pending' as const },
  MEDIUM: { label: 'متوسطة', tone: 'info' as const },
  LOW: { label: 'منخفضة', tone: 'neutral' as const },
};

export function ActiveMissions({ missions }: { missions: ActiveMission[] }) {
  return (
    <Card>
      <SectionHeader title="عمليات الإنقاذ النشطة" description="المهام الجارية وترتيب تقدمها" actions={<Link className="text-sm font-semibold text-primary hover:underline" to="/rescue-missions">عرض الكل</Link>} />
      <div className="mt-4 space-y-3">
        {missions.length === 0 ? <EmptyState title="لا توجد مهام نشطة" description="لا توجد عمليات إنقاذ جارية في الوقت الحالي." /> : missions.map((mission) => (
          <Link key={mission.id} to={`/rescue-missions/${mission.id}`} className="block rounded-lg border p-4 transition hover:border-primary/30 hover:bg-muted/30">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2"><span className="font-bold" dir="ltr">{mission.id}</span><Badge tone={priorityMeta[mission.priority].tone}>{priorityMeta[mission.priority].label}</Badge><StatusBadge status={mission.stage} /></div>
                <p className="mt-1 font-semibold">{mission.animal}</p>
                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground"><span className="inline-flex items-center gap-1"><MapPin className="size-3.5" />{mission.location}</span><span className="inline-flex items-center gap-1"><Building2 className="size-3.5" />{mission.organization}</span><span className="inline-flex items-center gap-1"><Clock3 className="size-3.5" />{waitingLabel(Math.max(1, Math.round((Date.now() - new Date(mission.startedAt).getTime()) / 60_000)))}</span></div>
              </div>
              <div className="w-full lg:w-44">
                <div className="mb-1.5 flex justify-between text-xs text-muted-foreground"><span>تقدم المهمة</span><span>{mission.progress}%</span></div>
                <div className="h-2 overflow-hidden rounded-full bg-muted" role="progressbar" aria-label={`تقدم المهمة ${mission.id}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={mission.progress}><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${mission.progress}%` }} /></div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </Card>
  );
}

export function CriticalReports({ reports }: { reports: CriticalReport[] }) {
  return (
    <Card>
      <SectionHeader title="أحدث البلاغات الحرجة" description="أحدث الحالات ذات الأولوية المرتفعة" actions={<Link className="text-sm font-semibold text-primary hover:underline" to="/reports?severity=CRITICAL">البلاغات الحرجة</Link>} />
      {reports.length === 0 ? <div className="mt-4"><EmptyState title="لا توجد بلاغات حرجة حديثة" /></div> : <div className="mt-4 overflow-x-auto"><table className="w-full min-w-[38rem] text-sm"><thead><tr className="border-b text-muted-foreground"><th className="pb-3 text-start font-semibold">البلاغ</th><th className="pb-3 text-start font-semibold">الحيوان</th><th className="pb-3 text-start font-semibold">الموقع</th><th className="pb-3 text-start font-semibold">الأولوية</th><th className="pb-3 text-start font-semibold">الحالة</th><th className="pb-3 text-start font-semibold">منذ</th></tr></thead><tbody className="divide-y">{reports.map((report) => <tr key={report.id} className="hover:bg-muted/30"><td className="py-3 font-semibold"><Link to={`/reports/${report.id}`} className="hover:text-primary" dir="ltr">{report.id}</Link></td><td className="py-3">{report.animal}</td><td className="py-3 text-muted-foreground">{report.location}</td><td className="py-3"><Badge tone={report.severity === 'CRITICAL' ? 'critical' : 'pending'}>{report.severity === 'CRITICAL' ? 'حرجة' : 'عالية'}</Badge></td><td className="py-3"><StatusBadge status={report.status} /></td><td className="py-3 text-muted-foreground">{waitingLabel(Math.max(1, Math.round((Date.now() - new Date(report.submittedAt).getTime()) / 60_000)))}</td></tr>)}</tbody></table></div>}
    </Card>
  );
}

function WeeklyReportsChartComponent({ data }: { data: WeeklyReportPoint[] }) {
  return (
    <Card>
      <SectionHeader title="اتجاه البلاغات الأسبوعي" description="المستلم مقارنة بما تم إنقاذه أو إغلاقه" />
      <div className="mt-5 h-72" role="img" aria-label="مخطط خطي يقارن البلاغات المستلمة والمغلقة خلال الأسبوع">
        <ResponsiveContainer width="100%" height="100%" debounce={120}><LineChart data={data} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}><CartesianGrid stroke={chartGrid} strokeDasharray="3 3" vertical={false} /><XAxis dataKey="day" tick={{ fill: chartText, fontSize: 12 }} axisLine={false} tickLine={false} /><YAxis tick={{ fill: chartText, fontSize: 12 }} axisLine={false} tickLine={false} /><RechartsTooltip contentStyle={{ borderColor: chartGrid, borderRadius: 12, direction: 'rtl' }} /><Legend /><Line name="البلاغات المستلمة" type="monotone" dataKey="received" stroke={chartPrimary} strokeWidth={3} dot={false} activeDot={{ r: 5 }} /><Line name="تم الإنقاذ/الإغلاق" type="monotone" dataKey="closed" stroke={chartSuccess} strokeWidth={3} dot={false} activeDot={{ r: 5 }} /></LineChart></ResponsiveContainer>
      </div>
    </Card>
  );
}

function OperationalSummaryChartComponent({ data }: { data: OperationalSummaryPoint[] }) {
  return (
    <Card>
      <SectionHeader title="ملخص الإنقاذ والتبني" description="حالة التدفق التشغيلي للحيوانات" />
      <div className="mt-5 h-72" role="img" aria-label="مخطط أعمدة يلخص حالات الإنقاذ والتبني والعلاج">
        <ResponsiveContainer width="100%" height="100%" debounce={120}><BarChart data={data} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}><CartesianGrid stroke={chartGrid} strokeDasharray="3 3" vertical={false} /><XAxis dataKey="label" tick={{ fill: chartText, fontSize: 11 }} axisLine={false} tickLine={false} /><YAxis tick={{ fill: chartText, fontSize: 12 }} axisLine={false} tickLine={false} /><RechartsTooltip contentStyle={{ borderColor: chartGrid, borderRadius: 12, direction: 'rtl' }} /><Bar name="عدد الحالات" dataKey="value" fill={chartInfo} radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer>
      </div>
    </Card>
  );
}

export const WeeklyReportsChart = memo(WeeklyReportsChartComponent);
export const OperationalSummaryChart = memo(OperationalSummaryChartComponent);

const activityIcons = {
  'organization-approved': Building2,
  'mission-assigned': HeartHandshake,
  'mission-completed': CheckCircle2,
  'adoption-approved': UserCheck,
  'advertisement-suspended': MegaphoneOff,
};

export function RecentActivityList({ items, loading, error, onRetry }: { items?: RecentActivity[]; loading: boolean; error?: string; onRetry: () => void }) {
  if (error) return <ErrorState title="تعذر تحميل آخر النشاطات" description={error} onRetry={onRetry} />;
  return (
    <Card>
      <SectionHeader title="آخر النشاطات" description="أحدث التغييرات التشغيلية والإدارية" actions={<Link to="/audit-log" className="text-sm font-semibold text-primary hover:underline">سجل النشاط</Link>} />
      <div className="mt-4 divide-y">
        {loading ? Array.from({ length: 5 }, (_, index) => <div key={index} className="py-3"><Skeleton className="h-12 w-full" /></div>) : items && items.length > 0 ? items.map((item) => {
          const Icon = activityIcons[item.kind];
          const elapsed = Math.max(1, Math.round((Date.now() - new Date(item.occurredAt).getTime()) / 60_000));
          return <Link key={item.id} to={item.target} className="flex gap-3 py-3 transition hover:bg-muted/30"><span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground"><Icon className="size-4" /></span><div className="min-w-0 flex-1"><p className="text-sm"><strong>{item.actor}</strong> {item.action} <span className="font-semibold">{item.resource}</span></p><p className="mt-1 text-xs text-muted-foreground">{waitingLabel(elapsed)}</p></div></Link>;
        }) : <EmptyState title="لا توجد نشاطات حديثة" />}
      </div>
    </Card>
  );
}

export function GeographicPreview({ snapshot, loading, error, onRetry }: { snapshot?: GeographicSnapshot; loading: boolean; error?: string; onRetry: () => void }) {
  const canOpenMap = usePermission('map.read');
  if (error) return <ErrorState title="تعذر تحميل الملخص الجغرافي" description={error} onRetry={onRetry} />;
  return (
    <Card className="overflow-hidden">
      <SectionHeader title="اللقطة الجغرافية" description="لقطة قراءة فقط للحالات والمهام التشغيلية الحالية" actions={canOpenMap?<Link to="/map" className="text-sm font-semibold text-primary hover:underline">فتح الخريطة التشغيلية</Link>:undefined} />
      {loading ? <Skeleton className="mt-4 h-64 w-full" /> : snapshot ? <div className="mt-4 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <div className="relative flex h-64 overflow-hidden rounded-xl border border-border/80 bg-gradient-to-br from-primary/5 via-muted/40 to-info/10 p-6">
          <div className="pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" style={{ backgroundImage: 'radial-gradient(circle at 20% 25%, hsl(var(--color-primary) / 0.28) 0 3px, transparent 4px), radial-gradient(circle at 68% 40%, hsl(var(--color-info) / 0.3) 0 4px, transparent 5px), radial-gradient(circle at 46% 72%, hsl(var(--color-success) / 0.28) 0 3px, transparent 4px)', backgroundSize: '94px 94px, 128px 128px, 112px 112px' }} />
          <div className="relative m-auto max-w-sm text-center">
            <span className="mx-auto flex size-12 items-center justify-center rounded-full border bg-surface/90 text-primary shadow-card"><MapPin className="size-6" /></span>
            <p className="mt-3 text-lg font-bold">{snapshot.coverageLabel}</p>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">معاينة تشغيلية خفيفة بدون تحميل محرك الخرائط داخل لوحة التحكم.</p>
            {canOpenMap && <Link to="/map" className="mt-4 inline-flex items-center gap-1 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">فتح الخريطة الكاملة <ArrowLeft className="size-4" /></Link>}
          </div>
        </div>
        <div className="grid content-start gap-2 sm:grid-cols-2 lg:grid-cols-1">{snapshot.layers.map((layer) => <div key={layer.key} className="resq-card-interactive flex items-center justify-between rounded-xl border border-border/80 bg-surface-subtle p-3 hover:border-primary/20"><div className="flex items-center gap-2"><span className={cn('size-2.5 rounded-full', layer.tone === 'critical' ? 'bg-critical' : layer.tone === 'info' ? 'bg-info' : layer.tone === 'success' ? 'bg-success' : 'bg-pending')} /><span className="text-sm font-medium">{layer.label}</span></div><span className="font-bold">{layer.count.toLocaleString('ar-SA-u-nu-latn')}</span></div>)}</div>
      </div> : <EmptyState title="لا تتوفر بيانات جغرافية" />}
    </Card>
  );
}

export function DashboardSectionSkeleton() {
  return <div className="space-y-7"><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-8">{Array.from({ length: 8 }, (_, index) => <Skeleton key={index} className="h-36" />)}</div><div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]"><Skeleton className="h-96" /><Skeleton className="h-96" /></div><div className="grid gap-6 xl:grid-cols-2"><Skeleton className="h-80" /><Skeleton className="h-80" /></div></div>;
}

export const quickActionIcons = { reports: ShieldAlert, assign: HeartHandshake, organizations: UsersRound, notifications: Activity };
