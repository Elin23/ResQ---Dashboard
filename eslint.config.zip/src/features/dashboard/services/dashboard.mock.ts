import { mockDelay } from '@/services/mock/delay';
import { getReportOperationalSnapshot } from '@/features/reports/services/reports.mock';
import { getMissionDashboardSnapshot } from '@/features/rescue-missions/services/rescue-missions.mock';
import { getAnimalDashboardSnapshot } from '@/features/animals/services/animals.mock';
import { getAdoptionDashboardSnapshot } from '@/features/adoption-requests/services/adoption-requests.mock';
import { getOrganizationDashboardSnapshot } from '@/features/organizations/services/organizations.mock';
import { getDonationSummary } from '@/features/donations/services/donations.mock';
import { formatMoney } from '@/features/donations/utils';
import { getClinicDashboardSnapshot } from '@/features/clinics/services/clinics.mock';
import type {
  AttentionItem,
  DashboardRange,
  DashboardSummary,
  GeographicSnapshot,
  RecentActivity,
} from '../types';

function minutesAgo(minutes: number): string {
  return new Date(Date.now() - minutes * 60_000).toISOString();
}

function hoursAgo(hours: number): string {
  return minutesAgo(hours * 60);
}

const rangeMultiplier: Record<DashboardRange, number> = {
  TODAY: 1,
  '7D': 5.8,
  '30D': 23.4,
};

export async function getDashboardSummary(range: DashboardRange): Promise<DashboardSummary> {
  await mockDelay(220);
  const multiplier = rangeMultiplier[range];
  const [reportSnapshot, missionSnapshot, animalSnapshot, adoptionSnapshot, organizationSnapshot, clinicSnapshot, donationSnapshot] = await Promise.all([getReportOperationalSnapshot(), getMissionDashboardSnapshot(), getAnimalDashboardSnapshot(), getAdoptionDashboardSnapshot(), getOrganizationDashboardSnapshot(), getClinicDashboardSnapshot(), getDonationSummary()]);
  return {
    generatedAt: new Date().toISOString(),
    metrics: [
      { id: 'today-reports', label: 'بلاغات اليوم', value: reportSnapshot.todayCount, context: '↑ 12% مقارنة بأمس', tone: 'info', target: '/reports?range=today', iconKey: 'reports' },
      { id: 'critical', label: 'الحالات الحرجة', value: reportSnapshot.criticalOpenCount, context: '3 منها تجاوزت 45 دقيقة', tone: 'critical', target: '/reports?severity=CRITICAL', iconKey: 'critical' },
      { id: 'waiting-org', label: 'بلاغات بانتظار جمعية', value: reportSnapshot.waitingOrganizationCount, context: 'أقدم بلاغ منذ 52 دقيقة', tone: 'pending', target: '/reports?status=WAITING_FOR_ORGANIZATION', iconKey: 'waiting' },
      { id: 'active-missions', label: 'عمليات الإنقاذ النشطة', value: missionSnapshot.activeCount, context: `${missionSnapshot.overdueCount} مهام تحتاج متابعة زمنية`, tone: 'info', target: '/rescue-missions', iconKey: 'missions' },
      { id: 'animals-adoption', label: 'حيوانات متاحة للتبني', value: animalSnapshot.availableForAdoption, context: 'جاهزة وفق تقييم الرعاية الحالي', tone: 'success', target: '/animals?status=AVAILABLE_FOR_ADOPTION', iconKey: 'animals' },
      { id: 'adoption-pending', label: 'طلبات تبني معلقة', value: adoptionSnapshot.pending, context: `${adoptionSnapshot.underReview} قيد المراجعة حالياً`, tone: 'pending', target: '/adoption-requests?status=PENDING', iconKey: 'adoptions' },
      { id: 'organizations-pending', label: 'جمعيات تنتظر الاعتماد', value: organizationSnapshot.pending, context: 'يتطلب التحقق من المستندات', tone: 'pending', target: '/organizations?status=PENDING_VERIFICATION', iconKey: 'organizations' },
      { id: 'clinics-pending', label: 'عيادات تنتظر الاعتماد', value: clinicSnapshot.pending, context: 'تتطلب مراجعة الترخيص والمستندات', tone: 'pending', target: '/clinics?status=PENDING_VERIFICATION', iconKey: 'clinics' },
      { id: 'donations-month', label: 'تبرعات هذا الشهر', value: donationSnapshot.thisMonth.map((t)=>formatMoney(t.amountMinor,t.currency)).join(' + ') || '0 ل.س', context: `${donationSnapshot.completed} عملية مكتملة في السجل التجريبي`, tone: 'success', target: '/donations', iconKey: 'donations' },
    ],
    activeMissions: missionSnapshot.active.map((mission) => ({ id:mission.id, animal:mission.animal.description ?? mission.animal.type, location:`${mission.location.governorate}${mission.location.city ? ` — ${mission.location.city}` : ''}`, organization:mission.organization.name, stage:`mission:${mission.status}` as const, progress:{ ASSIGNED:12, ACCEPTED:25, ON_THE_WAY:42, ARRIVED:58, RESCUING:72, TRANSPORTING:86, COMPLETED:100, CANCELLED:100 }[mission.status], startedAt:mission.assignedAt, priority:mission.priority })),
    criticalReports: [
      { id: 'RQ-2026-00481', animal: 'كلب', location: 'دمشق — المزة', severity: 'CRITICAL', status: 'report:NEW', submittedAt: minutesAgo(14) },
      { id: 'RQ-2026-00484', animal: 'قطة', location: 'دمشق — باب توما', severity: 'CRITICAL', status: 'report:WAITING_FOR_ORGANIZATION', submittedAt: minutesAgo(27) },
      { id: 'RQ-2026-00486', animal: 'كلب', location: 'حلب — الحمدانية', severity: 'CRITICAL', status: 'report:IN_PROGRESS', submittedAt: minutesAgo(39) },
      { id: 'RQ-2026-00504', animal: 'كلب', location: 'دمشق — برزة', severity: 'CRITICAL', status: 'report:VERIFIED', submittedAt: minutesAgo(51) },
    ],
    weeklyReports: [
      { day: 'السبت', received: 32, closed: 24 },
      { day: 'الأحد', received: 41, closed: 31 },
      { day: 'الاثنين', received: 38, closed: 35 },
      { day: 'الثلاثاء', received: 46, closed: 39 },
      { day: 'الأربعاء', received: 43, closed: 37 },
      { day: 'الخميس', received: 51, closed: 44 },
      { day: 'الجمعة', received: 34, closed: 29 },
    ],
    operationalSummary: [
      { label: 'تم الإنقاذ', value: Math.round(62 * multiplier) },
      { label: 'متاح للتبني', value: animalSnapshot.availableForAdoption },
      { label: 'تم التبني', value: Math.round(29 * multiplier) },
      { label: 'قيد العلاج', value: animalSnapshot.underTreatment },
    ],
  };
}

export async function getAttentionQueue(): Promise<AttentionItem[]> {
  await mockDelay(160);
  const [reportSnapshot, missionSnapshot] = await Promise.all([getReportOperationalSnapshot(), getMissionDashboardSnapshot()]);
  return [
    { id: 'att-1', title: `${reportSnapshot.criticalWaitingCount} حالات حرجة لم تستلمها جمعية`, detail: 'تحتاج إلى إسناد ميداني فوري', severity: 'critical', waitingMinutes: 47, target: '/reports?severity=CRITICAL&status=WAITING_FOR_ORGANIZATION', actionLabel: 'مراجعة الحالات' },
    { id: 'att-2', title: `${missionSnapshot.overdueCount} مهام إنقاذ تجاوزت زمن الوصول المستهدف`, detail: 'تحتاج إلى متابعة التنسيق الميداني', severity: 'critical', waitingMinutes: 64, target: '/rescue-missions?sla=OVERDUE', actionLabel: 'متابعة المهام' },
    { id: 'att-3', title: 'جمعيات تنتظر التحقق', detail: 'طلبات انضمام تحتاج مراجعة مستندات واعتماد', severity: 'pending', waitingMinutes: 185, target: '/organizations?status=PENDING_VERIFICATION', actionLabel: 'بدء المراجعة' },
    { id: 'att-4', title: 'طلبات تبني بانتظار المراجعة', detail: 'تحتاج إلى بدء مراجعة بشرية للحالات الجديدة', severity: 'pending', waitingMinutes: 1_560, target: '/adoption-requests?status=PENDING', actionLabel: 'مراجعة الطلبات' },
  ];
}

export async function getRecentActivity(): Promise<RecentActivity[]> {
  await mockDelay(190);
  return [
    { id: 'act-1', kind: 'mission-assigned', actor: 'أحمد الخطيب', action: 'تابع إسناد مهمة إنقاذ إلى', resource: 'فريق أمان للإنقاذ · MS-2026-00172', occurredAt: minutesAgo(8), target: '/rescue-missions/MS-2026-00172' },
    { id: 'act-2', kind: 'organization-approved', actor: 'محمد السالم', action: 'اعتمد جمعية', resource: 'جمعية أمان للحيوان', occurredAt: minutesAgo(21), target: '/organizations?status=ACTIVE' },
    { id: 'act-3', kind: 'mission-completed', actor: 'جمعية رفق دمشق', action: 'أكملت مهمة', resource: 'MS-2026-00178', occurredAt: minutesAgo(43), target: '/rescue-missions/MS-2026-00178' },
    { id: 'act-4', kind: 'adoption-approved', actor: 'نورة القحطاني', action: 'وافقت على طلب تبني', resource: 'AD-2026-0106', occurredAt: hoursAgo(2), target: '/adoption-requests?status=APPROVED' },
    { id: 'act-5', kind: 'advertisement-suspended', actor: 'فريق المحتوى', action: 'أوقف إعلانًا مؤقتًا', resource: 'ADVT-2026-0025', occurredAt: hoursAgo(3), target: '/advertisements/ADVT-2026-0025' },
  ];
}

export async function getGeographicSnapshot(): Promise<GeographicSnapshot> {
  await mockDelay(140);
  return {
    coverageLabel: 'المحافظات السورية ضمن نطاق التشغيل التجريبي',
    lastSyncedAt: new Date().toISOString(),
    layers: [
      { key: 'critical-reports', label: 'بلاغات حرجة', count: 7, tone: 'critical' },
      { key: 'missions', label: 'مهام إنقاذ', count: 6, tone: 'info' },
      { key: 'organizations', label: 'جمعيات نشطة', count: 18, tone: 'success' },
      { key: 'clinics', label: 'عيادات متاحة', count: 5, tone: 'pending' },
    ],
  };
}
