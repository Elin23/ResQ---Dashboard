import { z } from 'zod';
export const animalNoteSchema=z.object({note:z.string().trim().min(3,'اكتب ملاحظة من 3 أحرف على الأقل').max(800,'الملاحظة طويلة جداً')});
export type AnimalNoteFormValues=z.infer<typeof animalNoteSchema>;
export const animalHealthSchema=z.object({healthStatus:z.enum(['CRITICAL','NEEDS_TREATMENT','STABLE','RECOVERING','HEALTHY']),assessment:z.string().trim().min(3,'أضف ملخصاً للتقييم'),nextFollowUpAt:z.string().optional()});
export type AnimalHealthFormValues=z.infer<typeof animalHealthSchema>;
export const animalStatusSchema=z.object({status:z.enum(['RESCUED','UNDER_TREATMENT','RECOVERING','AVAILABLE_FOR_ADOPTION','RESERVED','ADOPTED','NOT_AVAILABLE','DECEASED']),reason:z.string().trim().max(500).optional()}).superRefine((value,ctx)=>{if(value.status==='DECEASED'&&(!value.reason||value.reason.length<5))ctx.addIssue({code:z.ZodIssueCode.custom,path:['reason'],message:'سبب أو ملاحظة مطلوبة لهذه الحالة الحساسة'});});
export type AnimalStatusFormValues=z.infer<typeof animalStatusSchema>;
export const medicalRecordSchema=z.object({type:z.enum(['EXAMINATION','TREATMENT','VACCINATION','SURGERY','MEDICATION','FOLLOW_UP']),title:z.string().trim().min(3,'العنوان مطلوب'),clinicId:z.string().optional(),veterinarianName:z.string().trim().optional(),notes:z.string().trim().max(1200).optional(),performedAt:z.string().min(1,'تاريخ الإجراء مطلوب'),nextFollowUpAt:z.string().optional()});
export type MedicalRecordFormValues=z.infer<typeof medicalRecordSchema>;
