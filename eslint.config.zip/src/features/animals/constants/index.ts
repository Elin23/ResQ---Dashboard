import type { AnimalHealthStatus, AnimalLifecycleStatus, AnimalSpecies, MedicalRecordType, SterilizationStatus, VaccinationStatus } from '../types';
export const speciesLabels:Record<AnimalSpecies,string>={DOG:'كلب',CAT:'قطة',BIRD:'طائر',OTHER:'أخرى'};
export function getSpeciesLabel(species:AnimalSpecies):string{return speciesLabels[species];}
export const genderLabels={MALE:'ذكر',FEMALE:'أنثى',UNKNOWN:'غير معروف'} as const;
export const lifecycleLabels:Record<AnimalLifecycleStatus,string>={RESCUED:'تم الإنقاذ',UNDER_TREATMENT:'تحت العلاج',RECOVERING:'في التعافي',AVAILABLE_FOR_ADOPTION:'جاهز للتبني',RESERVED:'محجوز',ADOPTED:'تم تبنيه',NOT_AVAILABLE:'غير متاح',DECEASED:'متوفى'};
export const healthLabels:Record<AnimalHealthStatus,string>={CRITICAL:'حرجة',NEEDS_TREATMENT:'يحتاج علاجاً',STABLE:'مستقرة',RECOVERING:'يتعافى',HEALTHY:'سليم'};
export const vaccinationLabels:Record<VaccinationStatus,string>={UNKNOWN:'غير معروف',NOT_VACCINATED:'غير مطعّم',PARTIALLY_VACCINATED:'مطعّم جزئياً',FULLY_VACCINATED:'مطعّم بالكامل'};
export const sterilizationLabels:Record<SterilizationStatus,string>={UNKNOWN:'غير معروف',NOT_STERILIZED:'غير معقم',STERILIZED:'معقم'};
export const medicalRecordLabels:Record<MedicalRecordType,string>={EXAMINATION:'فحص',TREATMENT:'علاج',VACCINATION:'لقاح',SURGERY:'جراحة',MEDICATION:'دواء',FOLLOW_UP:'متابعة'};
export const allowedLifecycleTransitions:Record<AnimalLifecycleStatus,readonly AnimalLifecycleStatus[]>={
 RESCUED:['UNDER_TREATMENT','RECOVERING','NOT_AVAILABLE','DECEASED'], UNDER_TREATMENT:['RECOVERING','NOT_AVAILABLE','DECEASED'], RECOVERING:['UNDER_TREATMENT','AVAILABLE_FOR_ADOPTION','NOT_AVAILABLE','DECEASED'], AVAILABLE_FOR_ADOPTION:['RESERVED','NOT_AVAILABLE','DECEASED'], RESERVED:['AVAILABLE_FOR_ADOPTION','ADOPTED','NOT_AVAILABLE','DECEASED'], ADOPTED:['NOT_AVAILABLE','DECEASED'], NOT_AVAILABLE:['UNDER_TREATMENT','RECOVERING','AVAILABLE_FOR_ADOPTION','DECEASED'], DECEASED:[],
};
export const animalGovernorates=['دمشق','ريف دمشق','حلب','حمص','اللاذقية','طرطوس','درعا'] as const;
