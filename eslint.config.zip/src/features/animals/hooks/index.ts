import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useSession } from '@/features/auth/session';
import { dashboardKeys } from '@/features/dashboard/hooks';
import { missionKeys } from '@/features/rescue-missions/hooks';
import { reportKeys } from '@/features/reports/hooks';
import type { AddMedicalRecordInput, AnimalFilters, AnimalHealthUpdateInput, AnimalStatusUpdateInput } from '../types';
import { addAnimalMedicalRecord, addAnimalNote, getAnimalById, getAnimalByMissionId, getAnimalByReportId, getAnimalOrganizations, getAnimals, getAnimalSummary, updateAnimalHealth, updateAnimalStatus } from '../services/animals.mock';
export const animalKeys={all:['animals'] as const,lists:()=>['animals','list'] as const,list:(filters:AnimalFilters)=>['animals','list',filters] as const,summary:()=>['animals','summary'] as const,details:()=>['animals','detail'] as const,detail:(id:string)=>['animals','detail',id] as const,byMission:(id:string)=>['animals','by-mission',id] as const,byReport:(id:string)=>['animals','by-report',id] as const,organizations:(search:string)=>['animals','organizations',search] as const};
export function useAnimals(filters:AnimalFilters){return useQuery({queryKey:animalKeys.list(filters),queryFn:()=>getAnimals(filters),placeholderData:(previous)=>previous});}
export function useAnimalSummary(){return useQuery({queryKey:animalKeys.summary(),queryFn:getAnimalSummary});}
export function useAnimal(id:string){return useQuery({queryKey:animalKeys.detail(id),queryFn:()=>getAnimalById(id),enabled:Boolean(id)});}
export function useAnimalByMission(id:string){return useQuery({queryKey:animalKeys.byMission(id),queryFn:()=>getAnimalByMissionId(id),enabled:Boolean(id)});}
export function useAnimalByReport(id:string){return useQuery({queryKey:animalKeys.byReport(id),queryFn:()=>getAnimalByReportId(id),enabled:Boolean(id)});}
export function useAnimalOrganizations(search=''){return useQuery({queryKey:animalKeys.organizations(search),queryFn:()=>getAnimalOrganizations(search)});}
function useInvalidateAnimal(id?:string){const client=useQueryClient();return async()=>{await Promise.all([client.invalidateQueries({queryKey:animalKeys.lists()}),client.invalidateQueries({queryKey:animalKeys.summary()}),client.invalidateQueries({queryKey:dashboardKeys.all}),client.invalidateQueries({queryKey:missionKeys.all}),client.invalidateQueries({queryKey:reportKeys.all}),...(id?[client.invalidateQueries({queryKey:animalKeys.detail(id)})]:[])]);};}
export function useUpdateAnimalStatus(id:string){const{session}=useSession();const invalidate=useInvalidateAnimal(id);return useMutation({mutationFn:(input:AnimalStatusUpdateInput)=>{if(!session)throw new Error('SESSION_REQUIRED');return updateAnimalStatus(id,input,session);},onSuccess:invalidate});}
export function useUpdateAnimalHealth(id:string){const{session}=useSession();const invalidate=useInvalidateAnimal(id);return useMutation({mutationFn:(input:AnimalHealthUpdateInput)=>{if(!session)throw new Error('SESSION_REQUIRED');return updateAnimalHealth(id,input,session);},onSuccess:invalidate});}
export function useAddAnimalMedicalRecord(id:string){const{session}=useSession();const invalidate=useInvalidateAnimal(id);return useMutation({mutationFn:(input:AddMedicalRecordInput)=>{if(!session)throw new Error('SESSION_REQUIRED');return addAnimalMedicalRecord(id,input,session);},onSuccess:invalidate});}
export function useAddAnimalNote(id:string){const{session}=useSession();const invalidate=useInvalidateAnimal(id);return useMutation({mutationFn:(note:string)=>{if(!session)throw new Error('SESSION_REQUIRED');return addAnimalNote(id,note,session);},onSuccess:invalidate});}
