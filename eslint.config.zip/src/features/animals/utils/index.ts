import { format, formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';
import type { AnimalFilters } from '../types';
import { safeDate, safeFiniteNumber } from '@/lib/runtime-safety';
export function formatAnimalDate(value:string){const date=safeDate(value);return date?format(date,'d MMMM yyyy، HH:mm',{locale:ar}):'—';}
export function formatAnimalRelative(value:string){const date=safeDate(value);return date?formatDistanceToNow(date,{locale:ar,addSuffix:true}):'—';}
export function formatEstimatedAge(months?:number){if(months===undefined||!Number.isFinite(months)||months<0)return 'غير محدد';months=Math.round(safeFiniteNumber(months));const years=Math.floor(months/12);const remaining=months%12;if(years===0)return `${remaining.toLocaleString('ar-SA-u-nu-latn')} أشهر`;if(remaining===0)return years===1?'سنة واحدة':years===2?'سنتان':`${years.toLocaleString('ar-SA-u-nu-latn')} سنوات`;return `${years===1?'سنة':years===2?'سنتان':`${years.toLocaleString('ar-SA-u-nu-latn')} سنوات`} و${remaining.toLocaleString('ar-SA-u-nu-latn')} أشهر`;}
export function hasAnimalFilters(filters:AnimalFilters){return Boolean(filters.search||filters.species||filters.status||filters.healthStatus||filters.organizationId||filters.clinicId||filters.governorate||filters.vaccinationStatus||filters.sterilizationStatus||filters.adoption||filters.dateFrom||filters.dateTo);}
