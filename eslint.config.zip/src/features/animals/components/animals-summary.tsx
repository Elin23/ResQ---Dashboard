import { HeartHandshake, PawPrint, ShieldCheck, Sparkles, Stethoscope, Users } from 'lucide-react';
import { Card, Skeleton } from '@/components/ui';
import type { AnimalFilters, AnimalSummary } from '../types';
const items=[
 {key:'total',label:'إجمالي الحيوانات المسجلة',icon:PawPrint,patch:{}},
 {key:'underTreatment',label:'تحت العلاج',icon:Stethoscope,patch:{status:'UNDER_TREATMENT'}},
 {key:'recovering',label:'في مرحلة التعافي',icon:Sparkles,patch:{status:'RECOVERING'}},
 {key:'availableForAdoption',label:'جاهزة للتبني',icon:HeartHandshake,patch:{status:'AVAILABLE_FOR_ADOPTION'}},
 {key:'reserved',label:'محجوزة',icon:ShieldCheck,patch:{status:'RESERVED'}},
 {key:'adoptedThisMonth',label:'تم تبنيها هذا الشهر',icon:Users,patch:{status:'ADOPTED'}},
] as const;
export function AnimalsSummaryCards({summary,loading,onFilter}:{summary?:AnimalSummary;loading:boolean;onFilter:(patch:Partial<AnimalFilters>)=>void}){return <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-6">{items.map(({key,label,icon:Icon,patch})=>loading?<div key={key}><Skeleton className="h-28"/></div>:<button key={key} type="button" className="text-start" onClick={()=>onFilter({...patch,page:1})}><Card className="h-full transition hover:border-primary/40 hover:bg-muted/20"><div className="flex items-start justify-between gap-3"><div><p className="text-xs text-muted-foreground">{label}</p><p className="mt-2 text-2xl font-bold">{summary?.[key].toLocaleString('ar-SA-u-nu-latn')??'—'}</p></div><span className="rounded-md bg-primary/10 p-2 text-primary"><Icon className="size-4"/></span></div></Card></button>)}</div>;}
