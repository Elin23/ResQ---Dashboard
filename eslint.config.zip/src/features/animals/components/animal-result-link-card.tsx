import { PawPrint } from 'lucide-react';
import { Link } from 'react-router';
import { Button, Card, SectionHeader } from '@/components/ui';
import { PermissionGuard } from '@/features/auth/rbac';
import { useAnimalByMission, useAnimalByReport } from '../hooks';
import { speciesLabels } from '../constants';
import type { Animal } from '../types';
import { AnimalHealthBadge, AnimalStatusBadge } from './animal-badges';
function Result({animal}:{animal:Animal}){return <Card><SectionHeader title="الحيوان الناتج عن الإنقاذ" description="سجل الرعاية المستمر بعد انتهاء الاستجابة الميدانية."/><div className="mt-4 flex items-center gap-3"><span className="rounded-full bg-primary/10 p-3 text-primary"><PawPrint className="size-5"/></span><div><Link to={`/animals/${animal.id}`} dir="ltr" className="font-bold text-primary hover:underline">{animal.id}</Link><p className="text-sm font-semibold">{animal.name??'بدون اسم'} · {speciesLabels[animal.species]}</p></div></div><div className="mt-3 flex flex-wrap gap-2"><AnimalStatusBadge status={animal.lifecycleStatus}/><AnimalHealthBadge status={animal.healthStatus}/></div><Link to={`/animals/${animal.id}`}><Button className="mt-4" size="sm" variant="secondary">فتح سجل الحيوان</Button></Link></Card>;}
export function MissionResultAnimalCard({missionId}:{missionId:string}){const query=useAnimalByMission(missionId);return <PermissionGuard permission="animals:read">{query.data?<Result animal={query.data}/>:null}</PermissionGuard>;}
export function ReportResultAnimalCard({reportId}:{reportId:string}){const query=useAnimalByReport(reportId);return <PermissionGuard permission="animals:read">{query.data?<Result animal={query.data}/>:null}</PermissionGuard>;}
