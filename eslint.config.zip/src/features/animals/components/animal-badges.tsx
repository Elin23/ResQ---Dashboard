import { Badge, StatusBadge } from '@/components/ui';
import type { SemanticStatus } from '@/lib/statuses';
import type { AnimalHealthStatus, AnimalLifecycleStatus, SterilizationStatus, VaccinationStatus } from '../types';
import { healthLabels, sterilizationLabels, vaccinationLabels } from '../constants';
const lifecycleSemantic:Record<AnimalLifecycleStatus,SemanticStatus>={RESCUED:'animal:RESCUED',UNDER_TREATMENT:'animal:UNDER_TREATMENT',RECOVERING:'animal:RECOVERING',AVAILABLE_FOR_ADOPTION:'animal:AVAILABLE_FOR_ADOPTION',RESERVED:'animal:RESERVED',ADOPTED:'animal:ADOPTED',NOT_AVAILABLE:'animal:NOT_AVAILABLE',DECEASED:'animal:DECEASED'};
const healthSemantic:Record<AnimalHealthStatus,SemanticStatus>={CRITICAL:'animal-health:CRITICAL',NEEDS_TREATMENT:'animal-health:NEEDS_TREATMENT',STABLE:'animal-health:STABLE',RECOVERING:'animal-health:RECOVERING',HEALTHY:'animal-health:HEALTHY'};
export function AnimalStatusBadge({status}:{status:AnimalLifecycleStatus}){return <StatusBadge status={lifecycleSemantic[status]}/>;}
export function AnimalHealthBadge({status}:{status:AnimalHealthStatus}){return <StatusBadge status={healthSemantic[status]}/>;}
export function VaccinationBadge({status}:{status:VaccinationStatus}){return <Badge tone={status==='FULLY_VACCINATED'?'success':status==='PARTIALLY_VACCINATED'?'info':status==='NOT_VACCINATED'?'pending':'neutral'}>{vaccinationLabels[status]}</Badge>;}
export function SterilizationBadge({status}:{status:SterilizationStatus}){return <Badge tone={status==='STERILIZED'?'success':status==='NOT_STERILIZED'?'pending':'neutral'}>{sterilizationLabels[status]}</Badge>;}
export function HealthText({status}:{status:AnimalHealthStatus}){return <span>{healthLabels[status]}</span>;}
