import type { ColumnDef } from '@tanstack/react-table';
import { Copy, ExternalLink, MoreHorizontal } from 'lucide-react';
import { useMemo, type ReactNode } from 'react';
import { useNavigate } from 'react-router';
import { toast } from 'sonner';
import { Avatar, DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, IconButton } from '@/components/ui';
import { DataTable } from '@/components/ui/data-table';
import type { DataTableQueryState } from '@/components/ui/data-table';
import type { Animal, AnimalFilters } from '../types';
import { formatAnimalDate, formatAnimalRelative } from '../utils';
import { getSpeciesLabel } from '../constants';
import { AnimalHealthBadge, AnimalStatusBadge, SterilizationBadge, VaccinationBadge } from './animal-badges';
export function AnimalsTable({animals,total,pageCount,filters,loading,error,onRetry,onQueryChange,emptyState}:{animals:Animal[];total:number;pageCount:number;filters:AnimalFilters;loading:boolean;error?:string;onRetry:()=>void;onQueryChange:(state:DataTableQueryState)=>void;emptyState:ReactNode}){const navigate=useNavigate();const columns=useMemo<Array<ColumnDef<Animal,unknown>>>(()=>[
 {accessorKey:'id',header:'رقم الحيوان',cell:({row})=><div className="flex items-center gap-1"><span dir="ltr" className="font-bold text-primary">{row.original.id}</span><IconButton label={`نسخ رقم الحيوان ${row.original.id}`} className="size-8" onClick={()=>void navigator.clipboard.writeText(row.original.id).then(()=>toast.success('تم نسخ رقم الحيوان'))}><Copy className="size-3.5"/></IconButton></div>},
 {id:'animal',header:'الحيوان',cell:({row})=>{const animal=row.original;const primary=animal.media.find((item)=>item.primary)??animal.media[0];return <div className="flex min-w-44 items-center gap-3">{primary?<img src={primary.thumbnailUrl??primary.url} alt={`صورة ${animal.name??animal.id}`} className="size-10 rounded-md object-cover" loading="lazy"/>:<Avatar name={animal.name??animal.id} size="md"/>}<div><p className="font-semibold">{animal.name??'بدون اسم'}</p><p className="text-xs text-muted-foreground">{getSpeciesLabel(animal.species)}{animal.breed?` — ${animal.breed}`:''}</p></div></div>;}},
 {accessorKey:'lifecycleStatus',header:'الحالة',cell:({row})=><AnimalStatusBadge status={row.original.lifecycleStatus}/>},
 {accessorKey:'healthStatus',header:'الحالة الصحية',cell:({row})=><AnimalHealthBadge status={row.original.healthStatus}/>},
 {id:'organization',header:'الجمعية',cell:({row})=><span className="whitespace-nowrap">{row.original.organization.name}</span>},
 {id:'location',header:'الموقع الحالي',cell:({row})=><div className="min-w-32"><p className="font-medium">{row.original.currentLocation?.name??'غير محدد'}</p><p className="text-xs text-muted-foreground">{row.original.currentLocation?.governorate??row.original.rescueOrigin?.governorate??''}</p></div>},
 {id:'vaccination',header:'التطعيم',cell:({row})=><VaccinationBadge status={row.original.vaccinationStatus}/>},
 {id:'sterilization',header:'التعقيم',cell:({row})=><SterilizationBadge status={row.original.sterilizationStatus}/>},
 {id:'rescuedAt',header:'تاريخ الإنقاذ',cell:({row})=><span title={formatAnimalDate(row.original.rescueOrigin?.rescuedAt??row.original.createdAt)} className="whitespace-nowrap text-xs">{formatAnimalRelative(row.original.rescueOrigin?.rescuedAt??row.original.createdAt)}</span>},
 ],[]);return <DataTable data={animals} columns={columns} getRowId={(animal)=>animal.id} enableSearch={false} loading={loading} error={error} onRetry={onRetry} manualPagination manualSorting manualFiltering pageCount={pageCount} totalCount={total} state={{pageIndex:filters.page-1,pageSize:filters.pageSize,search:filters.search,sorting:filters.sortBy?[{id:filters.sortBy,desc:filters.sortDirection!=='asc'}]:[]}} onStateChange={onQueryChange} onRowClick={(animal)=>navigate(`/animals/${animal.id}`)} rowAriaLabel={(animal)=>`فتح سجل الحيوان ${animal.id}`} rowActions={(animal)=><DropdownMenu><DropdownMenuTrigger asChild><IconButton label={`إجراءات الحيوان ${animal.id}`}><MoreHorizontal className="size-4"/></IconButton></DropdownMenuTrigger><DropdownMenuContent><DropdownMenuItem onSelect={()=>navigate(`/animals/${animal.id}`)}><ExternalLink className="size-4"/>عرض السجل</DropdownMenuItem><DropdownMenuItem onSelect={()=>void navigator.clipboard.writeText(animal.id).then(()=>toast.success('تم نسخ رقم الحيوان'))}><Copy className="size-4"/>نسخ رقم الحيوان</DropdownMenuItem></DropdownMenuContent></DropdownMenu>} emptyState={emptyState}/>;}
