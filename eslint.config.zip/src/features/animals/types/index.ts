export const animalSpecies = ['DOG','CAT','BIRD','OTHER'] as const;
export type AnimalSpecies = (typeof animalSpecies)[number];
export const animalGenders = ['MALE','FEMALE','UNKNOWN'] as const;
export type AnimalGender = (typeof animalGenders)[number];
export const animalLifecycleStatuses = ['RESCUED','UNDER_TREATMENT','RECOVERING','AVAILABLE_FOR_ADOPTION','RESERVED','ADOPTED','NOT_AVAILABLE','DECEASED'] as const;
export type AnimalLifecycleStatus = (typeof animalLifecycleStatuses)[number];
export const animalHealthStatuses = ['CRITICAL','NEEDS_TREATMENT','STABLE','RECOVERING','HEALTHY'] as const;
export type AnimalHealthStatus = (typeof animalHealthStatuses)[number];
export const vaccinationStatuses = ['UNKNOWN','NOT_VACCINATED','PARTIALLY_VACCINATED','FULLY_VACCINATED'] as const;
export type VaccinationStatus = (typeof vaccinationStatuses)[number];
export const sterilizationStatuses = ['UNKNOWN','NOT_STERILIZED','STERILIZED'] as const;
export type SterilizationStatus = (typeof sterilizationStatuses)[number];
export type AnimalMediaType = 'IMAGE' | 'VIDEO';
export type MedicalRecordType = 'EXAMINATION' | 'TREATMENT' | 'VACCINATION' | 'SURGERY' | 'MEDICATION' | 'FOLLOW_UP';

export interface AnimalMedia { id:string; type:AnimalMediaType; url:string; thumbnailUrl?:string; caption?:string; createdAt:string; primary?:boolean; }
export interface AnimalMedicalRecord { id:string; animalId:string; type:MedicalRecordType; clinic?:{id:string;name:string}; veterinarianName?:string; title:string; notes?:string; performedAt:string; nextFollowUpAt?:string; attachments?:AnimalMedia[]; }
export interface AdoptionReadinessCheck { key:string; label:string; completed:boolean; blocking:boolean; }
export interface AdoptionReadiness { eligible:boolean; checks:AdoptionReadinessCheck[]; evaluatedAt:string; }
export interface AnimalTimelineEvent { id:string; action:'CREATED'|'MOVED'|'HEALTH_UPDATED'|'STATUS_UPDATED'|'MEDICAL_RECORD_ADDED'|'VACCINATION_UPDATED'|'NOTE_ADDED'; title:string; actor?:string; timestamp:string; details?:string; tone?:'neutral'|'success'|'pending'|'critical'|'info'; }
export interface AnimalInternalNote { id:string; adminName:string; adminRole:string; createdAt:string; note:string; }
export interface Animal {
 id:string; name?:string; species:AnimalSpecies; breed?:string; gender:AnimalGender; estimatedAgeMonths?:number; color?:string; distinguishingMarks?:string;
 lifecycleStatus:AnimalLifecycleStatus; healthStatus:AnimalHealthStatus; vaccinationStatus:VaccinationStatus; sterilizationStatus:SterilizationStatus; sterilizationRecord?:{performedAt:string;clinic?:{id:string;name:string};notes?:string};
 rescueOrigin?:{reportId?:string;missionId?:string;rescuedAt?:string;governorate?:string;city?:string};
 organization:{id:string;name:string}; currentLocation?:{type:'ORGANIZATION'|'CLINIC'|'FOSTER'|'OTHER';id?:string;name:string;governorate?:string};
 description?:string; media:AnimalMedia[]; createdAt:string; updatedAt:string; latestAssessmentAt?:string; healthAlert?:string;
}
export interface AnimalDetails { animal:Animal; medicalRecords:AnimalMedicalRecord[]; readiness:AdoptionReadiness; timeline:AnimalTimelineEvent[]; notes:AnimalInternalNote[]; }
export interface AnimalFilters { search:string; species?:AnimalSpecies; status?:AnimalLifecycleStatus; healthStatus?:AnimalHealthStatus; organizationId?:string; clinicId?:string; governorate?:string; vaccinationStatus?:VaccinationStatus; sterilizationStatus?:SterilizationStatus; adoption?:'READY'|'NOT_READY'; dateFrom?:string; dateTo?:string; page:number; pageSize:number; sortBy?:'rescuedAt'|'updatedAt'|'status'|'healthStatus'; sortDirection?:'asc'|'desc'; }
export interface AnimalListResult { items:Animal[]; total:number; page:number; pageSize:number; pageCount:number; }
export interface AnimalSummary { total:number; underTreatment:number; recovering:number; availableForAdoption:number; reserved:number; adoptedThisMonth:number; }
export interface AnimalOrganizationOption { id:string; name:string; governorate:string; }
export interface AnimalStatusUpdateInput { status:AnimalLifecycleStatus; reason?:string; }
export interface AnimalHealthUpdateInput { healthStatus:AnimalHealthStatus; assessment:string; nextFollowUpAt?:string; }
export interface AddMedicalRecordInput { type:MedicalRecordType; title:string; clinicId?:string; veterinarianName?:string; notes?:string; performedAt:string; nextFollowUpAt?:string; }
