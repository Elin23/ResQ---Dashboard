import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type PaginationState,
  type RowSelectionState,
  type SortingState,
} from '@tanstack/react-table';
import { ArrowDown, ArrowUp, ChevronsUpDown } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent, type MouseEvent, type ReactNode } from 'react';
import { Button, Checkbox, DebouncedSearchInput, EmptyState, ErrorState, Pagination, Skeleton } from './index';
import { cn } from '@/lib/cn';

export interface DataTableQueryState {
  pageIndex: number;
  pageSize: number;
  search: string;
  sorting: SortingState;
}

export interface DataTableProps<TData> {
  data: TData[];
  columns: Array<ColumnDef<TData, unknown>>;
  getRowId?: (row: TData, index: number) => string;
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  searchPlaceholder?: string;
  searchDebounceMs?: number;
  enableSearch?: boolean;
  enableRowSelection?: boolean;
  rowActions?: (row: TData) => ReactNode;
  onRowClick?: (row: TData) => void;
  rowAriaLabel?: (row: TData) => string;
  onSelectionChange?: (rows: TData[]) => void;
  selectionActions?: (rows: TData[]) => ReactNode;
  emptyState?: ReactNode;
  pageCount?: number;
  totalCount?: number;
  manualPagination?: boolean;
  manualFiltering?: boolean;
  manualSorting?: boolean;
  state?: Partial<DataTableQueryState>;
  onStateChange?: (state: DataTableQueryState) => void;
  pageSizeOptions?: number[];
}

function isInteractiveTarget(target: EventTarget | null): boolean {
  return target instanceof Element && Boolean(target.closest('button,a,input,select,textarea,[role="menuitem"],[role="checkbox"]'));
}

function sameSorting(left: SortingState, right: SortingState): boolean {
  return left.length === right.length && left.every((item, index) => item.id === right[index]?.id && item.desc === right[index]?.desc);
}

export function DataTable<TData>({
  data,
  columns,
  getRowId,
  loading = false,
  error,
  onRetry,
  searchPlaceholder = 'البحث في الجدول…',
  searchDebounceMs = 250,
  enableSearch = true,
  enableRowSelection = false,
  rowActions,
  onRowClick,
  rowAriaLabel,
  onSelectionChange,
  selectionActions,
  emptyState,
  pageCount,
  totalCount,
  manualPagination = false,
  manualFiltering = false,
  manualSorting = false,
  state,
  onStateChange,
  pageSizeOptions = [10, 20, 50],
}: DataTableProps<TData>) {
  const safeData = Array.isArray(data) ? data : [];
  const safePageSizeOptions = pageSizeOptions.filter((size) => Number.isFinite(size) && size > 0);
  const defaultPageSize = safePageSizeOptions[0] ?? 10;
  const [localSearch, setLocalSearch] = useState(state?.search ?? '');
  const [localSorting, setLocalSorting] = useState<SortingState>(state?.sorting ?? []);
  const [localPagination, setLocalPagination] = useState<PaginationState>({
    pageIndex: state?.pageIndex ?? 0,
    pageSize: state?.pageSize && state.pageSize > 0 ? state.pageSize : defaultPageSize,
  });
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const rowActionsRef = useRef(rowActions);
  const getRowIdRef = useRef(getRowId);
  rowActionsRef.current = rowActions;
  getRowIdRef.current = getRowId;
  const stableGetRowId = useCallback((row: TData, index: number) => getRowIdRef.current?.(row, index) ?? String(index), []);

  // A state field supplied by the parent is truly controlled. We do not mirror it
  // back into local state with effects, which previously caused an extra render pass.
  const search = state?.search ?? localSearch;
  const sorting = state?.sorting ?? localSorting;
  const pagination = useMemo<PaginationState>(() => ({
    pageIndex: state?.pageIndex ?? localPagination.pageIndex,
    pageSize: state?.pageSize && state.pageSize > 0 ? state.pageSize : localPagination.pageSize,
  }), [localPagination.pageIndex, localPagination.pageSize, state?.pageIndex, state?.pageSize]);

  const emitState = useCallback((next: DataTableQueryState) => {
    onStateChange?.(next);
  }, [onStateChange]);

  const changeSearch = useCallback((nextSearch: string) => {
    if (nextSearch === search && pagination.pageIndex === 0) return;
    if (state?.search === undefined) setLocalSearch(nextSearch);
    if (state?.pageIndex === undefined) setLocalPagination((current) => current.pageIndex === 0 ? current : { ...current, pageIndex: 0 });
    emitState({ search: nextSearch, sorting, pageIndex: 0, pageSize: pagination.pageSize });
  }, [emitState, pagination.pageIndex, pagination.pageSize, search, sorting, state?.pageIndex, state?.search]);

  const changeSorting = useCallback((updater: SortingState | ((current: SortingState) => SortingState)) => {
    const nextSorting = typeof updater === 'function' ? updater(sorting) : updater;
    if (sameSorting(nextSorting, sorting) && pagination.pageIndex === 0) return;
    if (state?.sorting === undefined) setLocalSorting(nextSorting);
    if (state?.pageIndex === undefined) setLocalPagination((current) => current.pageIndex === 0 ? current : { ...current, pageIndex: 0 });
    emitState({ search, sorting: nextSorting, pageIndex: 0, pageSize: pagination.pageSize });
  }, [emitState, pagination.pageIndex, pagination.pageSize, search, sorting, state?.pageIndex, state?.sorting]);

  const changePagination = useCallback((updater: PaginationState | ((current: PaginationState) => PaginationState)) => {
    const nextPagination = typeof updater === 'function' ? updater(pagination) : updater;
    if (nextPagination.pageIndex === pagination.pageIndex && nextPagination.pageSize === pagination.pageSize) return;
    if (state?.pageIndex === undefined || state?.pageSize === undefined) {
      setLocalPagination((current) => ({
        pageIndex: state?.pageIndex === undefined ? nextPagination.pageIndex : current.pageIndex,
        pageSize: state?.pageSize === undefined ? nextPagination.pageSize : current.pageSize,
      }));
    }
    emitState({ search, sorting, pageIndex: nextPagination.pageIndex, pageSize: nextPagination.pageSize });
  }, [emitState, pagination, search, sorting, state?.pageIndex, state?.pageSize]);

  const enhancedColumns = useMemo<Array<ColumnDef<TData, unknown>>>(() => {
    const result: Array<ColumnDef<TData, unknown>> = [];
    if (enableRowSelection) {
      result.push({
        id: 'selection',
        enableSorting: false,
        header: ({ table }) => <Checkbox ariaLabel="تحديد كل الصفوف الظاهرة" checked={table.getIsAllPageRowsSelected() ? true : table.getIsSomePageRowsSelected() ? 'indeterminate' : false} onCheckedChange={(value) => table.toggleAllPageRowsSelected(value === true)} />,
        cell: ({ row }) => <Checkbox ariaLabel="تحديد الصف" checked={row.getIsSelected()} onCheckedChange={(value) => row.toggleSelected(value === true)} />,
      });
    }
    result.push(...columns);
    if (rowActions) {
      result.push({ id: 'actions', enableSorting: false, header: 'الإجراءات', cell: ({ row }) => <div className="flex justify-end">{rowActionsRef.current?.(row.original)}</div> });
    }
    return result;
  }, [columns, enableRowSelection, Boolean(rowActions)]);

  const table = useReactTable({
    data: safeData,
    columns: enhancedColumns,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: manualFiltering ? undefined : getFilteredRowModel(),
    getSortedRowModel: manualSorting ? undefined : getSortedRowModel(),
    getPaginationRowModel: manualPagination ? undefined : getPaginationRowModel(),
    getRowId: stableGetRowId,
    manualPagination,
    manualFiltering,
    manualSorting,
    pageCount: manualPagination ? pageCount : undefined,
    state: { globalFilter: search, sorting, pagination, rowSelection },
    onGlobalFilterChange: (updater) => changeSearch(String(typeof updater === 'function' ? updater(search) : updater)),
    onSortingChange: changeSorting,
    onPaginationChange: changePagination,
    onRowSelectionChange: setRowSelection,
  });

  const selectedRows = useMemo(() => {
    const selectedIds = new Set(Object.entries(rowSelection).filter(([, selected]) => selected).map(([rowId]) => rowId));
    if (selectedIds.size === 0) return [];
    return safeData.filter((row, index) => selectedIds.has(stableGetRowId(row, index)));
  }, [safeData, rowSelection, stableGetRowId]);

  // Server-side pages replace `data`; drop selection ids that no longer exist so
  // stale selection cannot keep action bars alive after paging/filtering.
  useEffect(() => {
    if (!manualPagination && !manualFiltering) return;
    const visibleIds = new Set(safeData.map((row, index) => stableGetRowId(row, index)));
    setRowSelection((current) => {
      let changed = false;
      const next: RowSelectionState = {};
      for (const [id, selected] of Object.entries(current)) {
        if (selected && visibleIds.has(id)) next[id] = true;
        else if (selected) changed = true;
      }
      return changed ? next : current;
    });
  }, [safeData, manualFiltering, manualPagination, stableGetRowId]);

  const lastSelectionSignature = useRef<string | null>(null);
  useEffect(() => {
    if (!onSelectionChange) return;
    const signature = Object.entries(rowSelection)
      .filter(([, selected]) => selected)
      .map(([rowId]) => rowId)
      .sort()
      .join('|');
    if (signature === lastSelectionSignature.current) return;
    lastSelectionSignature.current = signature;
    onSelectionChange(selectedRows);
  }, [onSelectionChange, rowSelection, selectedRows]);

  if (error) return <ErrorState description={error} onRetry={onRetry} />;
  const visibleRows = table.getRowModel().rows;
  const externalPageCount = Number.isFinite(pageCount) ? Math.max(Math.trunc(pageCount ?? 1), 1) : 1;
  const resolvedPageCount = manualPagination ? externalPageCount : Math.max(table.getPageCount(), 1);

  const activateRow = (row: TData, event: MouseEvent<HTMLTableRowElement> | KeyboardEvent<HTMLTableRowElement>) => {
    if (!onRowClick || isInteractiveTarget(event.target)) return;
    if ('key' in event && event.key !== 'Enter' && event.key !== ' ') return;
    if ('key' in event) event.preventDefault();
    onRowClick(row);
  };

  return <div className="space-y-3.5">
    <div className="flex flex-col justify-between gap-3 rounded-2xl border border-border/70 bg-surface/90 p-3 shadow-sm sm:flex-row sm:items-center sm:p-3.5">
      {enableSearch ? <DebouncedSearchInput value={search} onValueChange={changeSearch} debounceMs={searchDebounceMs} placeholder={searchPlaceholder} className="w-full sm:max-w-md" /> : <span />}
      <div className="min-h-6 shrink-0 text-sm font-medium text-muted-foreground">{enableRowSelection && selectedRows.length > 0 ? `${selectedRows.length} محدد` : totalCount !== undefined ? `${totalCount} عنصر` : null}</div>
    </div>
    {selectedRows.length > 0 && selectionActions ? <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-primary/15 bg-primary/5 px-4 py-3 shadow-sm"><span className="text-sm font-semibold">تم تحديد {selectedRows.length} من العناصر في الصفحة الحالية</span><div className="flex flex-wrap gap-2">{selectionActions(selectedRows)}</div></div> : null}
    <div className="overflow-hidden rounded-2xl border border-border/80 bg-surface shadow-card"><div className="resq-scroll-region overflow-x-auto"><table className="w-full min-w-[42rem] border-separate sm:min-w-[48rem] border-spacing-0 text-start text-sm">
      <thead className="sticky top-0 z-10 bg-surface-subtle/95 text-muted-foreground shadow-[0_1px_0_hsl(var(--color-border))]">{table.getHeaderGroups().map((headerGroup) => <tr key={headerGroup.id}>{headerGroup.headers.map((header) => <th key={header.id} scope="col" className="whitespace-nowrap px-4 py-3.5 text-start text-xs font-bold tracking-wide">{header.isPlaceholder ? null : header.column.getCanSort() ? <Button variant="ghost" size="sm" className="-mx-2 h-8 px-2 text-xs" onClick={header.column.getToggleSortingHandler()}>{flexRender(header.column.columnDef.header, header.getContext())}{header.column.getIsSorted() === 'asc' ? <ArrowUp className="size-3.5" /> : header.column.getIsSorted() === 'desc' ? <ArrowDown className="size-3.5" /> : <ChevronsUpDown className="size-3.5 opacity-60" />}</Button> : flexRender(header.column.columnDef.header, header.getContext())}</th>)}</tr>)}</thead>
      <tbody>{loading ? Array.from({ length: 5 }, (_, rowIndex) => <tr key={`skeleton-${rowIndex}`}>{enhancedColumns.map((column, cellIndex) => <td key={`skeleton-${String(column.id ?? cellIndex)}-${rowIndex}`} className="border-b border-border/60 px-4 py-4"><Skeleton className="h-4 w-4/5" /></td>)}</tr>) : visibleRows.map((row) => <tr key={row.id} tabIndex={onRowClick ? 0 : undefined} aria-label={rowAriaLabel?.(row.original)} onClick={(event) => activateRow(row.original, event)} onKeyDown={(event) => activateRow(row.original, event)} className={cn('group border-b border-border/60 transition-colors duration-100 last:border-b-0 hover:bg-primary/[0.035]' , onRowClick && 'cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary', row.getIsSelected() && 'bg-primary/[0.065] hover:bg-primary/[0.085]')}>{row.getVisibleCells().map((cell) => <td key={cell.id} className="border-b border-border/60 px-4 py-3.5 align-middle group-last:border-b-0">{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>)}</tr>)}</tbody>
    </table></div>{!loading && visibleRows.length === 0 && <div className="p-6 sm:p-8">{emptyState ?? <EmptyState />}</div>}</div>
    <div className="flex flex-col justify-between gap-3 rounded-xl bg-muted/30 px-3 py-2.5 md:flex-row md:items-center"><label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">عدد الصفوف<select className="h-9 rounded-lg border border-border/90 bg-surface px-2.5 font-semibold text-foreground shadow-sm outline-none focus-visible:ring-2 focus-visible:ring-primary/70" value={pagination.pageSize} onChange={(event) => changePagination({ pageIndex: 0, pageSize: Number(event.target.value) })}>{safePageSizeOptions.map((size) => <option key={size} value={size}>{size}</option>)}</select></label><Pagination page={pagination.pageIndex + 1} pageCount={resolvedPageCount} onPageChange={(page) => changePagination((current) => ({ ...current, pageIndex: page - 1 }))} /></div>
  </div>;
}
