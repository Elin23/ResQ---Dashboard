import { Bell, LogOut, Menu, Volume2, VolumeX } from 'lucide-react';
import { useState } from 'react';
import { Link, useLocation } from 'react-router';
import { Avatar, Badge, IconButton } from '@/components/ui';
import { usePermission } from '@/features/auth/rbac';
import { useSession } from '@/features/auth/session';
import { allModuleRoutes } from '@/routes/module-routes';
import { isNotificationSoundEnabled, playNotificationChime, setNotificationSoundEnabled } from '@/features/notifications/services/notification-sound';

function resolveCurrentRoute(pathname: string) {
  return allModuleRoutes
    .filter((route) => pathname === route.path || pathname.startsWith(`${route.path}/`))
    .sort((a, b) => b.path.length - a.path.length)[0];
}

export function Header({ onOpenSidebar }: { onOpenSidebar: () => void }) {
  const location = useLocation();
  const { session, logout } = useSession();
  const canReadNotifications = usePermission('notifications.read');
  const current = resolveCurrentRoute(location.pathname);
  const [soundEnabled, setSoundEnabled] = useState(() => isNotificationSoundEnabled());
  const toggleSound = () => { const next = !soundEnabled; setNotificationSoundEnabled(next); setSoundEnabled(next); if (next) playNotificationChime(); };

  return <header className="sticky top-0 z-30 flex h-header min-w-0 items-center gap-1.5 border-b border-border/70 bg-surface/98 px-2.5 shadow-[0_1px_0_hsl(var(--color-border)/0.35)] sm:gap-2.5 sm:px-4 md:gap-3 md:px-6">
    <IconButton label="فتح القائمة" className="lg:hidden" onClick={onOpenSidebar}><Menu className="size-5" /></IconButton>
    <div className="min-w-0 border-s-2 border-primary/20 ps-3"><p className="truncate text-sm font-extrabold text-brown">{current?.label ?? 'لوحة ResQ'}</p><p className="hidden truncate text-xs text-muted-foreground sm:block">{current?.description ?? 'الإدارة المركزية للمنصة'}</p></div>
    <div className="ms-auto" />
    {canReadNotifications && <IconButton className="hidden sm:inline-flex" label={soundEnabled?'كتم نغمة الإشعارات':'تفعيل نغمة الإشعارات'} onClick={toggleSound}>{soundEnabled?<Volume2 className="size-5"/>:<VolumeX className="size-5"/>}</IconButton>}
    {canReadNotifications && <Link to="/notifications" onClick={playNotificationChime} aria-label="فتح الإشعارات" className="rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"><span className="relative inline-flex size-10 items-center justify-center rounded-lg text-muted-foreground transition hover:bg-muted hover:text-foreground"><Bell className="size-5"/><span className="absolute end-1 top-1 size-2 rounded-full bg-critical ring-2 ring-surface" aria-hidden="true"/></span></Link>}
    {session && <div className="hidden items-center gap-2 rounded-xl sm:flex border border-transparent p-1.5 transition-colors hover:border-border/70 hover:bg-background/70" aria-label={`الحساب الإداري: ${session.name}`}><Avatar name={session.name} src={session.avatarUrl}/><span className="hidden lg:block"><span className="block text-sm font-semibold">{session.name}</span><Badge className="mt-0.5">{session.roleLabel}</Badge></span></div>}
    {session && <IconButton label="تسجيل الخروج" onClick={logout}><LogOut className="size-5"/></IconButton>}
  </header>;
}
