import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { NavLink } from 'react-router';
import { IconButton, Tooltip } from '@/components/ui';
import { routeGroups } from '@/routes/module-routes';
import { rolePermissions } from '@/features/auth/permissions';
import { useSession } from '@/features/auth/session';
import { cn } from '@/lib/cn';

function SidebarLink({ item, collapsed, onNavigate }: { item: (typeof routeGroups)[number]['items'][number]; collapsed: boolean; onNavigate?: () => void }) {
  const content = (
    <NavLink
      to={item.path}
      end={item.path === '/'}
      onClick={onNavigate}
      className={({ isActive }) => cn(
        'group relative flex h-11 w-full items-center gap-3 overflow-hidden rounded-xl px-3 text-sm font-semibold transition-[background-color,color,transform] duration-150 ease-out',
        isActive ? 'active bg-primary/10 text-primary shadow-sm after:absolute after:inset-y-2 after:start-0 after:w-0.5 after:rounded-full after:bg-primary' : 'text-muted-foreground hover:translate-x-[-1px] hover:bg-muted/80 hover:text-foreground',
        collapsed && 'mx-auto size-10 justify-center gap-0 px-0',
      )}
    >
      <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted/60 transition-colors group-hover:bg-surface group-[.active]:bg-primary group-[.active]:text-white group-[.active]:shadow-sm"><item.icon className="size-[1.1rem] shrink-0" aria-hidden="true" /></span>
      {!collapsed && <span className="min-w-0 flex-1 truncate">{item.label}</span>}
    </NavLink>
  );
  return collapsed ? <Tooltip content={item.label}>{content}</Tooltip> : content;
}

export function Sidebar({ collapsed, onToggleCollapsed, mobileOpen, onMobileOpenChange }: { collapsed: boolean; onToggleCollapsed: () => void; mobileOpen: boolean; onMobileOpenChange: (open: boolean) => void }) {
  const { session } = useSession();
  const visibleGroups = routeGroups
    .map((group) => ({ ...group, items: group.items.filter((item) => !item.permission || Boolean(session && rolePermissions[session.role].has(item.permission))) }))
    .filter((group) => group.items.length > 0);

  const aside = (mobile: boolean) => (
    <aside className={cn('flex h-dvh flex-col border-s border-border/70 bg-surface/98 shadow-[8px_0_32px_hsl(var(--color-foreground)/0.035)] transition-[width] duration-200 ease-out', !mobile && (collapsed ? 'w-sidebar-collapsed' : 'w-sidebar'), mobile && 'w-[min(86vw,18rem)]')}>
      <div className="flex h-header items-center border-b px-4">
        <div className={cn('flex items-center gap-3', collapsed && !mobile && 'mx-auto')}>
          <span className="relative flex size-10 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-primary to-primary/80 text-lg font-extrabold text-white shadow-md shadow-primary/15"><span className="absolute inset-x-1 top-0 h-px bg-white/50" />R</span>
          {(!collapsed || mobile) && <div><div className="text-[1.05rem] font-extrabold tracking-tight text-brown">ResQ</div><div className="text-[0.7rem] font-medium text-muted-foreground">لوحة الإدارة</div></div>}
        </div>
        {mobile && <IconButton label="إغلاق القائمة" className="ms-auto" onClick={() => onMobileOpenChange(false)}><X className="size-5" /></IconButton>}
      </div>
      <nav aria-label="التنقل الرئيسي" className={cn('resq-scroll-region min-h-0 flex-1 overflow-y-auto py-4', collapsed && !mobile ? 'px-2' : 'px-3')}>
        {visibleGroups.map((group, groupIndex) => {
          const visibleItems = group.items;
          return <div key={group.label} className={cn(groupIndex < visibleGroups.length - 1 && 'mb-4')}>
            {(!collapsed || mobile) && <h2 className="mb-2 px-3 text-[0.68rem] font-bold tracking-wide text-muted-foreground/80">{group.label}</h2>}
            <div className="space-y-1">{visibleItems.map((item) => <SidebarLink key={item.path} item={item} collapsed={collapsed && !mobile} onNavigate={mobile ? () => onMobileOpenChange(false) : undefined} />)}</div>
          </div>;
        })}
      </nav>
      {!mobile && <div className={cn('border-t', collapsed ? 'p-2' : 'p-3')}><button type="button" onClick={onToggleCollapsed} className={cn('mx-auto flex h-10 items-center justify-center rounded-xl text-sm font-semibold text-muted-foreground transition-colors duration-150 ease-out hover:bg-muted hover:text-foreground', collapsed ? 'w-10 gap-0' : 'w-full gap-2')}>{collapsed ? <ChevronLeft className="size-4" /> : <><ChevronRight className="size-4" /><span>طي القائمة</span></>}</button></div>}
    </aside>
  );

  return <>
    <div className="hidden h-dvh shrink-0 lg:block">{aside(false)}</div>
    {mobileOpen && <div className="resq-mobile-nav fixed inset-0 z-50 lg:hidden"><button aria-label="إغلاق القائمة" className="resq-mobile-nav-overlay absolute inset-0 bg-brown/40" onClick={() => onMobileOpenChange(false)} /><div className="resq-mobile-nav-panel absolute inset-y-0 end-0 shadow-overlay">{aside(true)}</div></div>}
  </>;
}
