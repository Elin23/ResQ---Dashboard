# Package 03 — Map + Dashboard + Charts

## Goal
Reduce the largest remaining sources of visible UI lag without reintroducing the route-transition blank-screen regression fixed in Package 01.

## Implemented

### Dashboard
- Removed `MapCanvas`, `MapProvider`, `useOperationalMapData`, and Leaflet-backed marker rendering from the dashboard geographic preview.
- The dashboard now renders a lightweight geographic summary from the already-loaded `GeographicSnapshot`.
- This also removes the operational map query/refetch interval from the dashboard lifecycle.
- The full interactive map remains available at `/map` for authorized users.

### Leaflet map runtime
- `MapMarker` is memoized.
- `L.divIcon(...)` is memoized and is no longer recreated on every unrelated render.
- Marker event handler objects are memoized.
- The operations map now passes a stable `onSelect` callback to the marker tree.
- Viewport fitting is driven by a serialized coordinate signature rather than the `entities` array reference itself.
- `fitBounds` therefore does not run merely because an equivalent array was recreated.
- Map focus dependencies use coordinate primitives to avoid effect churn from object identity changes.
- Added `ResizeObserver` + `requestAnimationFrame`-batched `map.invalidateSize({ animate: false })` so sidebar/layout width changes do not leave stale Leaflet dimensions or gray/partial tiles.
- Window resize fallback is retained and all observers/listeners/frames are cleaned up.
- TileLayer event handler object is stable.

### Recharts
- Dashboard chart components are memoized.
- Analytics chart components are memoized.
- Donation analytics chart is memoized.
- `ResponsiveContainer` resize handling is debounced at 120ms across dashboard, analytics, and donations charts to avoid rapid SVG recalculation during sidebar/layout resizing.
- Donation `Intl.NumberFormat` is created once at module scope instead of inside tooltip formatting work.
- Donation line chart dots are disabled to reduce SVG nodes.

### Regression coverage
Added tests ensuring:
1. Leaflet does not return to the dashboard preview.
2. Map viewport work uses a geometry signature, `ResizeObserver`, and `invalidateSize()`.
3. Heavy chart groups keep resize debounce + memoization.

## Verification
- `npm test`: **29/29 passing**.
- Full `typecheck`, `lint`, and `build` were not run because this package does not contain an installed `node_modules` tree and local `tsc`/`eslint` executables are unavailable in the execution environment.
- No stale `dist` output is included as a substitute for a verified build.

## Expected impact
- Dashboard no longer pays the runtime cost of Leaflet, map markers, map tile requests, or the 60-second operational-map refetch solely for a small preview.
- Selecting a map entity no longer recreates every marker icon solely because the parent callback identity changed.
- Sidebar/layout resizing should produce fewer chart redraws and correct Leaflet sizing.
- Equivalent map datasets no longer trigger unnecessary `fitBounds` just because an array reference changed.

## Deferred
- Route-level chunk splitting remains deferred because the repository contains a regression contract that forbids the previous lazy/Suspense route fallback behavior. A later production-bundle package should implement splitting without replacing the current route during pending navigation.
- Marker clustering/virtualized geospatial rendering should be considered if production datasets reach hundreds/thousands of simultaneous map entities.
