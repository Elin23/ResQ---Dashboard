# Package 02 — Performance Core + DataTable

## Scope

This package focuses on render churn, URL/filter search pressure, DataTable state ownership, stale selection, and unstable function references. It intentionally does not introduce route-level lazy loading because the repository contains an explicit regression guard against navigation fallbacks replacing the current route.

## Implemented changes

### 1. DataTable state model simplified

- Removed prop-to-local synchronization effects for search, sorting, and pagination.
- Each field is now controlled directly by the parent when that field is supplied in `state`.
- Local state is used only for fields the parent does not control.
- State changes remain event-driven through `onStateChange`.
- Page resets for search/sort no longer require a second synchronization render.

Primary file: `src/components/ui/data-table.tsx`.

### 2. Shared debounced search input

Added `DebouncedSearchInput` in `src/components/ui/index.tsx`.

- Local typing remains immediate.
- Expensive URL/query/filter updates happen after a 300ms default debounce.
- Callback identity is stored in a ref to avoid restarting the timer solely because a parent callback received a new function identity.
- External value changes remain synchronized back into the draft input.

Applied to major search surfaces including:

- reports
- animals
- rescue missions
- adoption requests
- users
- organizations
- clinics
- donations
- feeding points
- advertisements
- notifications
- support
- audit log
- map controls
- DataTable's built-in search

This directly reduces URL writes, query-key changes, mock/API filtering, table recalculation, and map filtering while typing.

### 3. Stable DataTable action/id function handling

`rowActions` and `getRowId` are frequently supplied as inline functions by feature tables. The DataTable now keeps the latest implementations in refs while exposing stable internal callbacks.

This prevents the enhanced column model from being rebuilt merely because a parent produced a new function object during an unrelated render.

### 4. Server-side selection hardening

When server/manual pagination or filtering replaces the current data page, row-selection IDs that are no longer present are pruned.

This prevents stale selections from:

- leaving the selection action bar visible on a different page;
- reporting a selection count that no longer corresponds to visible data;
- retaining references to rows from old filters/pages.

### 5. Stable URL-derived filter objects

The high-traffic list pages now memoize their parsed `URLSearchParams` filters rather than reconstructing a new filter object during every unrelated render.

Updated high-traffic pages include:

- users
- organizations
- animals
- rescue missions
- clinics
- adoption requests

`feeding-points` and `support` already had equivalent memoization.

This also stabilizes callbacks whose dependency arrays include the filter object.

### 6. Lighter table hover paint

Changed table-row transition behavior from a broad `transition` to `transition-colors duration-100`, avoiding unnecessary transition tracking for non-color properties.

## Regression tests

Three package-specific regression tests were added to `tests/final-qa.test.mjs`:

1. DataTable controlled state remains event-driven and does not reintroduce prop-mirroring effects.
2. Heavy list/map search surfaces use the shared debounced search input.
3. Server-side selection pruning and memoized URL filter parsing remain present.

Current test result:

- **26/26 passing**

Command used:

```bash
npm test
```

## Typecheck/build verification note

A clean dependency installation could not be completed in this execution environment. `npm ci` left a partial `node_modules` tree whose `@types/*` directories were incomplete, so `npm run typecheck` stops at missing type-definition packages such as React, Node, Leaflet and D3 before it can provide a meaningful project typecheck.

This package therefore does **not** claim a successful production build in this environment. The static regression suite passes, and the source changes were checked directly, but a local `npm ci && npm run check` should still be run in a normal development environment before production deployment.

## Deferred to next packages

The following performance areas remain intentionally deferred:

- Leaflet marker/icon memoization and viewport invalidation.
- Dashboard map removal/lightweight preview.
- Recharts render/resize optimization.
- Safe route/chunk splitting without reintroducing navigation blank screens.
- broader dashboard/component memoization after profiling.
- UI/typography/grid redesign (Tajawal package).

