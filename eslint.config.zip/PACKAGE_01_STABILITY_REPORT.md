# Package 01 — Stability, Navigation & Blank-Screen Hardening

## Scope
This package targets application stability, the reported blank/app-colored transition surface with an unexplained dark frame, route-level render failures, unsafe persisted session rendering, and RTL modal positioning.

## Changes completed

### 1. Route-local render recovery
- Added `src/routes/route-boundary.tsx`.
- Wrapped the routed `<Outlet />` inside `RouteRenderBoundary` in `AppShell`.
- A render crash in a page now shows a local recovery state while keeping the sidebar/header/application shell mounted.
- The boundary resets automatically after pathname/search changes.
- Development builds log route render errors with component stack information.

### 2. Full-screen splash no longer competes with the application
- `AppRouter` is no longer mounted underneath the full-screen splash.
- Splash duration reduced from 1700ms + 450ms fade to 520ms + 180ms fade.
- Removed `blur-3xl` GPU filter layers from the full-screen splash to reduce compositor artifacts on browsers/devices where the issue can differ from Preview.

### 3. Blank/dark-frame surface hardening
- Explicitly removes border/outline/box-shadow from `html`, `body`, and `#root`.
- Keeps the same application background across document/root surfaces.
- Adds `overscroll-behavior: none` where supported to avoid exposing an outer scroll surface during boundary overscroll.
- Removes non-visible focus outlines while preserving the explicit `:focus-visible` accessibility styling already present.

### 4. RTL modal centering correction
- Replaced logical `start-1/2` with physical `left-1/2` while retaining `-translate-x-1/2`.
- This prevents RTL logical positioning from conflicting with a physical X transform.

### 5. Persisted session validation
- Added Zod validation for persisted session payloads.
- Invalid/unknown roles now clear stored state instead of entering the render tree.
- `roleLabel` is derived from the validated role rather than trusted from storage.
- RBAC permission lookups now fail closed if they receive an invalid role.

### 6. AppShell callback stability
- Sidebar/header callbacks that can be stable are now `useCallback` references.
- Added a stable `main-content` landmark id for future navigation/focus work.

## Important routing decision
The existing project has a regression test explicitly preventing route-level `lazy()`/Suspense fallback behavior because replacing the current route during chunk loading had already been associated with unstable transitions. Package 01 therefore does **not** reintroduce that pattern.

Safe code splitting remains planned for the performance package, but must preserve the current page during pending navigation rather than replacing it with a viewport fallback.

## Black-frame causes covered by this package
- Full-screen splash overlay mounted simultaneously with the real application.
- GPU-heavy blur layers on a fullscreen composited surface.
- Root/document outer border, outline, or shadow leakage.
- Overscroll exposing an outer document/browser surface where supported.
- Route render exception escalating to the root application boundary.
- Corrupt persisted role causing RBAC render exceptions.
- RTL modal centering mismatch between logical position and physical transform.

## Remaining suspects to verify in later packages / real-device testing
- Browser/WebView-specific compositor bugs during transforms/opacity transitions.
- A stale Radix portal/overlay triggered by a specific workflow.
- Map/Chart resize/compositing interaction during navigation.
- Mobile browser viewport chrome / safe-area behavior.
- A production-only asset/chunk failure (requires a rebuilt production bundle and runtime test).

## Verification
- `npm test`: **23/23 passing** after adding four regression tests for this package.
- Added: `tests/stability-package.test.mjs`.
- Full `npm ci` could not complete in the execution environment before the command limit, so a fresh `typecheck`, `lint`, and production `build` could not be completed here.
- `dist/` is intentionally omitted from the delivered package because the original compiled output would be stale relative to the modified source.

## Files changed/added
- `src/app/app.tsx`
- `src/components/feedback/app-splash.tsx`
- `src/components/layout/app-shell.tsx`
- `src/components/ui/index.tsx`
- `src/features/auth/session.tsx`
- `src/features/auth/rbac.tsx`
- `src/index.css`
- `src/routes/route-boundary.tsx` (new)
- `tests/stability-package.test.mjs` (new)
