# Package 04 — UI Design System / Tajawal / Grid / Cards

## Scope
This package upgrades the visual foundation without changing the routing strategy or reintroducing heavy dashboard map rendering.

## Implemented
- Added Tajawal from Google Fonts with 400/500/600/700/800 weights and kept it first in the application font stack.
- Expanded design tokens for surface hierarchy, radii, card/hover shadows, and motion timing.
- Added a reusable 12-column `.resq-page-grid` primitive and a subtle background grid treatment for the main content surface.
- Added reusable `.resq-card-interactive` micro-interaction with transform/shadow limited to hover-capable devices.
- Added global `prefers-reduced-motion: reduce` safeguards.
- Upgraded Card, MetricCard, Button, IconButton, Input, Textarea, Select, Dropdown, Modal, FilterBar, PageHeader and SectionHeader styling.
- Refined AppShell spacing and maximum content width for large displays.
- Refined Header visual hierarchy while preserving the prior GPU-sensitive blur regression guard.
- Redesigned Sidebar navigation hierarchy, brand block, active icon treatment and rounded interactive targets.
- Reworked dashboard layout toward a 12-column hierarchy for high-priority operational sections.
- Expanded dashboard KPI density on very wide screens and improved visual hierarchy of KPI values/icons.
- Improved quick actions, attention queue items and geographic snapshot surfaces with restrained micro-interactions.

## Performance / stability constraints intentionally preserved
- No React.lazy/Suspense route fallback was introduced.
- Leaflet remains out of the dashboard preview.
- Header does not use backdrop blur because an existing regression test explicitly guards against GPU-sensitive shell blur.
- General interaction transitions remain restrained at 160ms.
- Motion is disabled/reduced when the operating system requests reduced motion.

## Verification
- `npm test`: 32/32 passing.
- Added 3 Package 04 regression tests covering Tajawal, design system/grid/motion, and dashboard hierarchy.
- Full TypeScript/lint/build verification was not available in this execution environment because local `node_modules/.bin/tsc` and `node_modules/.bin/eslint` are absent.

## Key changed files
- `index.html`
- `tailwind.config.ts`
- `src/index.css`
- `src/components/ui/index.tsx`
- `src/components/layout/app-shell.tsx`
- `src/components/layout/header.tsx`
- `src/components/layout/sidebar.tsx`
- `src/features/dashboard/dashboard-page.tsx`
- `src/features/dashboard/components/dashboard-sections.tsx`
- `tests/final-qa.test.mjs`
