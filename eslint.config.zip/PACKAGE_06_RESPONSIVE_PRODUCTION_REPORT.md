# Package 06 — Responsive + Production Optimization + Final Integration

## Scope
This package integrates the visual/performance work from packages 01–05 and hardens the application for narrow mobile screens, tablets, desktop layouts, browser safe areas, long content, and production builds.

## Changes

### Responsive app shell
- Reduced mobile page gutters to 12px and progressively restores spacing at sm/md/xl breakpoints.
- Replaced the remaining decorative `blur-3xl` shell glow with a radial gradient so the visual treatment does not require a large GPU blur surface.
- Reduced decorative grid intensity on phones.
- Keeps `AppShell` and route-local error recovery intact.

### Header on narrow screens
- Reduced header gaps and padding below the `sm` breakpoint.
- Notification sound control is hidden on the narrowest screens while remaining available from `sm` upward.
- Full account identity chip is hidden on phones to protect the route title and critical navigation actions from overflow.
- Notification and logout actions remain available.

### Mobile / tablet grid behavior
- Reusable `.resq-page-grid` now resolves to 1 column on phones, 6 columns on tablets, 8 columns on small desktop, and the original 12-column system above that.
- Long Arabic text, identifiers and table values receive overflow-safe wrapping.
- Mobile hover lift is disabled where hover does not add value.

### Safe areas and touch behavior
- Added support for device safe-area insets.
- Mobile navigation panel respects bottom safe-area.
- Coarse pointers use `touch-action: manipulation` for actionable controls.

### Tables and dialogs
- Mobile DataTable minimum width reduced from 48rem to 42rem while retaining 48rem at `sm+`; horizontal scrolling remains explicit rather than compressing columns until unusable.
- Pagination controls stack until the `md` breakpoint.
- Modal footer actions stack vertically on phones and become horizontal from `sm` upward.
- PageHeader actions can occupy the full mobile width instead of forcing title/action collisions.

### Production build configuration
`vite.config.ts` now explicitly defines:
- `target: 'es2022'`
- CSS code splitting enabled
- production sourcemaps disabled
- compressed size reporting enabled
- a deliberate chunk warning budget

No unsafe route-level lazy fallback was introduced. Existing navigation stability regression coverage remains active.

## Verification
- `node --test tests/*.test.mjs`: **38/38 passed**.
- Added 3 package-specific regression tests covering mobile shell/header behavior, responsive/safe-area behavior, and dialog/table/build configuration.
- Full `typecheck`, `lint`, and Vite production build were not runnable in this execution environment because the package does not contain an installed local toolchain (`node_modules/.bin/tsc` / eslint / vite). This is an environment limitation, not reported as a successful build.

## Preserved guarantees
- No full-screen route Suspense fallback was reintroduced.
- The black-frame/navigation stability fixes from Package 01 remain intact.
- DataTable controlled-state and debounce improvements remain intact.
- Leaflet remains out of the Dashboard preview.
- Chart resize debounce and map viewport stability remain intact.
- Tajawal and the design-system tokens remain active.
- Reduced-motion support remains active.
