# Package 07 — Final Runtime Hardening & Regression QA

## Scope
This package hardens the application against malformed runtime/API values and preserves the stability/performance/UI improvements from packages 01–06.

## Changes

### Shared runtime safety
- Added `src/lib/runtime-safety.ts` with defensive helpers for display text, finite numbers, dates, date formatting, and geographic coordinates.
- Unknown semantic statuses now fall back to a neutral `غير معروف` badge instead of assuming the registry always contains the API value.

### Avatar/media resilience
- `Avatar` now tolerates null/empty names.
- Broken avatar image URLs fall back to initials instead of leaving a broken image UI.

### Session/runtime storage hardening
- localStorage/sessionStorage reads, writes, and deletes are wrapped in safe guards for browsers/privacy contexts where storage can throw.
- Login now fails safely if a session cannot be persisted.
- Session state synchronizes across tabs via the `storage` event.
- Existing Zod schema validation remains in place before RBAC rendering.

### Map crash prevention
- Invalid latitude/longitude values are filtered before they reach Leaflet.
- Invalid focused coordinates are ignored.
- Invalid map rows produce an in-context status message instead of crashing the map.
- Existing memoization, `invalidateSize`, and geometry-key viewport optimizations remain intact.

### DataTable runtime guards
- Non-array data is treated as an empty dataset at runtime.
- Invalid/non-positive page-size options are removed.
- Invalid external page counts collapse to a safe page count of 1.
- Existing event-driven controlled state and debounced search behavior remain intact.

### Date/number formatter hardening
Defensive date guards were applied to shared formatters used by:
- reports
- rescue missions
- animals
- adoption requests
- users
- organizations
- clinics
- feeding points
- donations
- advertisements
- support
- notifications
- settings
- content
- audit log

Malformed dates now return a visual fallback rather than allowing `Intl.DateTimeFormat`, `date-fns`, or `new Date(...)` consumers to throw into the route boundary.

### Advertisement table
- Unknown placement values now render a safe fallback label.
- Updated-at rendering uses the hardened advertisement date formatter.

## Regression QA
`npm test` result after the package:

- 43 tests
- 43 passed
- 0 failed

Five new regression tests cover:
1. shared runtime guards,
2. malformed status/avatar values,
3. invalid Leaflet coordinates,
4. storage failures + cross-tab session synchronization,
5. DataTable pagination/data sanitation.

## Build verification limitation
The supplied package does not contain installed project dependencies (`node_modules/.bin/tsc`, `eslint`, and `vite` are absent), so a local TypeScript/lint/production-build verification could not be executed in this environment.

Recommended final local command after installing dependencies:

```bash
npm ci
npm run check
```

## Preserved invariants
- No lazy/Suspense route fallback was introduced, preserving the navigation black-frame fix.
- No heavy Leaflet dashboard preview was reintroduced.
- No GPU-heavy shell blur was reintroduced.
- Tajawal/design-system/responsive improvements from earlier packages remain intact.
